<?php

class Register extends BaseController
{
	
	public function index()
	{	
		$validationErrors = array();
		
		if(isset($_POST['register'])) {
			
			$this->load_model("RegisterModel");
			
			if($this->registermodel->insert($_POST['register'])) {

				$this->load_model("LoginModel");
				
				if($this->loginmodel->authenticate($this->registermodel->data['inputUserName'], $this->registermodel->data['inputPassword'])) {
					$this->redirect('home/index');
				} 
			
			} else {
				// insert fail due to some validation errors
				$validationErrors = $this->registermodel->getErrors();	
			}
		
		}	
		
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        
        $this->load_view('header', $cat);  
		$this->load_view('user/register', array('validationErrors'=>$validationErrors));
		
		$this->load_model("FooterModel");

        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
	}
}
