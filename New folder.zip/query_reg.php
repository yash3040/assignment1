<?php require 'database_conn.php'; require 'functions.php';
	if (isset($_POST['regsubmit'])) {
		$username = $_POST['inputUserName'];
		$gender = $_POST['gender'];
		$password = MD5($_POST['inputPassword']);
		$email = $_POST['inputEmail'];
		$fname = $_POST['inputFname'];
		$mobile = $_POST['inputMobNo'];
		$lname = $_POST['inputLname'];
		$phone = $_POST['inputPhone'];

		$uni_uname = "SELECT username FROM user WHERE username = '$username'";
		$uniresult1 = $conn->query($uni_uname);

		$uni_email = "SELECT email FROM user WHERE email = '$email'";
		$uniresult2 = $conn->query($uni_email);

		if(!$uniresult1->num_rows == 0){
			echo "<script>alert('Username Already Exists. Please Retry');window.location.href='register.php'</script>";			
		}else if(!$uniresult2->num_rows == 0){
			echo "<script>alert('Email Already Exists. Please Retry');window.location.href='register.php'</script>";			
		}else{
			$sql = "INSERT INTO user(username, password, firstname, lastname, gender, email, mobile_number, phone_number)
					VALUES ('$username', '$password', '$fname', '$lname', '$gender', '$email', '$mobile', '$phone');";

			if($conn->query($sql) == TRUE){
				if(NewUserMail($email, $fname, $lname)){
					echo "<script>alert('Your have been Registered');window.location.href='index.php'</script>";
				}else{
					echo "<script>alert('Error Occured. Please Retry');window.location.href='register.php'</script>";	
				}
				
			}else{
				echo "<script>alert('Error Occured. Please Retry');window.location.href='register.php'</script>";	
			}		
		}		
	}
	$conn->close(); 
	
?>