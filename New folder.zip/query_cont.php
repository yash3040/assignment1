<?php require 'database_conn.php';
	if (isset($_POST['cont_sub'])) {
		$name = $_POST['inputConName'];
		$con_email = $_POST['inputConEmail'];
		$sub = $_POST['inputSubject'];
		$msg = $_POST['inputMessage'];

		$get_admin = "SELECT email FROM user WHERE username = 'eshop__admin'";
		$result=mysqli_query($conn,$get_admin);
		$row=mysqli_fetch_array($result);

		$admin_mail = $row['email'];

		require 'functions.php';

		if($result->num_rows == 1){
			if(ContactMail($admin_mail, $name, $con_email, $sub, $msg)){
				echo "<script>alert('Your Message has been Submitted');window.location.href='contact.php'</script>";
			}else{
				echo "<script>alert('Error Occured. Please Retry');window.location.href='contact.php'</script>";	
			}
		}else{
			echo "<script>alert('Error Occured. Please Retry');window.location.href='contact.php'</script>";	
		}				
	}
	$conn->close(); 
	
?>