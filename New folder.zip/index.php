<!DOCTYPE html>
<html lang="en">
	<head>
	    <title>Home Page</title>
	    <link rel="shortcut icon" href="images/favicon.ico">
	    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
	 	<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
		<link rel="stylesheet" type="text/css" href="css/owl.theme.green.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/media.css">
	</head>
	<body>
		
		
		<?php require 'header.php';?>

		
		<section class="container-fluid">
			<section class="row topban">
				<div id="jssor_1">
			        <div data-u="slides" class="jssordiv">
			            <div data-p="225.00">
			                <img data-u="image" class="img-responsive" src="images/banner.jpg" />
			            </div>
			            <div data-p="225.00">
			                <img data-u="image" class="img-responsive" src="images/banner1.jpg" />
			            </div>
			            <div data-p="225.00">
			                <img data-u="image" class="img-responsive" src="images/banner2.jpg" />
			            </div>
			        </div>
			        <!-- Arrow Navigator -->
			        <div data-u="arrowleft" class="jssora051 arrleft" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
			            <svg width="30" height="30">
			                <image width="30" height="30" href="images/pre-arrow.svg" />
			            </svg>
			        </div>
			        <div data-u="arrowright" class="jssora051 arrrght" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
			            <svg width="30" height="30">
			                <image width="30" height="30" href="images/next-arrow.svg" />
			            </svg>
			        </div>
			    </div>
			</section>
		</section>	
	
		<section class="container background">
			<section class="row">
				<section class="col-sm-4">
					<div class="media">
					  <div class="media-left">
					    <a class="media-object sprite1"></a> 
					  </div>
					  <div class="media-body">
					    <h4 class="media-heading sevicetext">Free Delivery Worldwide</h4>
					    <p>At vero eos et accusamus et iusto odio</p>
					  </div>
					</div>
				</section>
				<section class="col-sm-4">
					<div class="media">
					  <div class="media-left">
					    <a class="media-object sprite2"></a> 
					  </div>
					  <div class="media-body">
					    <h4 class="media-heading sevicetext">Free Return For 90 Day</h4>
					    <p>At vero eos et accusamus et iusto odio</p>
					  </div>
					</div>			
				</section>
				<section class="col-sm-4">
					<div class="media">
					  <div class="media-left">
					    <a class="media-object sprite3"></a> 
					  </div>
					  <div class="media-body">
					    <h4 class="media-heading sevicetext">Discount on Order Gift</h4>
					    <p>At vero eos et accusamus et iusto odio</p>
					  </div>
					</div>				
				</section>
			</section>
		</section>	
		<section class="container background">	
			<section class="row">
				<section class="col-sm-12">
					<center><p class="text2">Trending Product</p></center>

					<?php require 'functions.php';
						TrendingItems();						
					 ?>						
						
					<center><button type="button" id="more" name="more" class="btn btn-default btnd">More Products</button></center></br></br>			
				</section>
			</section>				
		</section>
		<section class="container-fluid">
			<section class="row posrel">
				<img src="images/px.jpg" class="img-responsive padmarg0">	
				<p class="botban">
					<b>GET THE </b>LATEST<br> <b>WOMENS</b> FASHION<br>
					<button type="button" class="btn btn-default btnr1">Get Exclusive Collection For Women</button>
				</p>		
			</section>
		</section>	

		<section class="container testimonial">
			<center><p class="text2">Testimonial</p></center>
			<div class="owl-carousel owl-theme">
			      <div class="item">
			        <section class="row testrow">
					<section class="col-sm-2">	
						<div class="media">
						  <div class="media-left">
						    <a class="media-object" href="">
						    	<img src="images/testimonial_3.jpg">
						    </a> 
						  </div>
						  <div class="media-body">
						    <h5 class="media-heading addwish">John Clay</h5>
						    <p>Cyclist</p>
						  </div>
						</div>		
					</section>
					<section class="col-sm-10">
						<p>&quot;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.&quot;</p>
					</section>
			      </div>
			      <div class="item">
			        <section class="row testrow">
					<section class="col-sm-2">	
						<div class="media">
						  <div class="media-left">
						    <a class="media-object" href="">
						    	<img src="images/testimonial_3.jpg">
						    </a> 
						  </div>
						  <div class="media-body">
						    <h5 class="media-heading addwish">John Clay</h5>
						    <p>Cyclist</p>
						  </div>
						</div>		
					</section>
					<section class="col-sm-10">
						<p>&quot;Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus.&quot;</p>
					</section>
			      </div>
			      <div class="item">
			        <section class="row testrow">
					<section class="col-sm-2">	
						<div class="media">
						  <div class="media-left">
						    <a class="media-object" href="">
						    	<img src="images/testimonial_3.jpg">
						    </a> 
						  </div>
						  <div class="media-body">
						    <h5 class="media-heading addwish">John Clay</h5>
						    <p>Cyclist</p>
						  </div>
						</div>		
					</section>
					<section class="col-sm-10">
						<p>&quot;Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit.&quot;</p>
					</section>
			      </div>
			      <div class="item">
			        <section class="row testrow">
					<section class="col-sm-2">	
						<div class="media">
						  <div class="media-left">
						    <a class="media-object" href="">
						    	<img src="images/testimonial_3.jpg">
						    </a> 
						  </div>
						  <div class="media-body">
						    <h5 class="media-heading addwish">John Clay</h5>
						    <p>Cyclist</p>
						  </div>
						</div>		
					</section>
					<section class="col-sm-10">
						<p>&quot;Fusce convallis metus id felis luctus adipiscing. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Quisque id mi. Ut tincidunt tincidunt erat. Etiam feugiat lorem non metus.&quot;</p>
					</section>
					</section>
			      </div>
			  </div>
		</section>

		<?php require 'footer.php'; ?>
		
		<script>

			$(document).ready(function(){				

				$('.owl-carousel').owlCarousel({
				    items:1,
				    lazyLoad:true,
				    loop:true,
				    margin:10,
				    autoplay:true,
				    autoplayTimeout:4000,
				});

	            var jssor_1_SlideoTransitions = [
	          	  {$Duration:200,x:-1,y:1,$Delay:50,$Cols:10,$Rows:5,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Left:$Jease$.$InQuart,$Top:$Jease$.$InQuart,$Opacity:$Jease$.$Linear},$Opacity:2},
	              {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationZigZag,$Easing:$Jease$.$OutQuad,$Opacity:2},
	              {$Duration:500,x:1,y:-1,$Delay:40,$Cols:10,$Rows:5,$SlideOut:true,$ChessMode:{$Column:3,$Row:12},$Easing:{$Left:$Jease$.$InCubic,$Top:$Jease$.$InCubic,$Opacity:$Jease$.$OutQuad},$Opacity:2},
	              {$Duration:1600,y:-1,$Delay:40,$Cols:24,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:$Jease$.$OutJump,$Round:{$Top:1.5}},
	              {$Duration:600,$Delay:20,$Cols:8,$Rows:4,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Assembly:2050,$Opacity:2},
	              {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:$Jease$.$OutQuad,$Opacity:2,$Assembly:2049},
	              {$Duration:1000,x:-0.2,$Delay:20,$Cols:16,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:{$Left:$Jease$.$InOutExpo,$Opacity:$Jease$.$InOutQuad},$Assembly:260,$Opacity:2,$Outside:true,$Round:{$Top:0.5}},
	              {$Duration:600,$Delay:40,$Rows:10,$Clip:8,$Move:true,$Formation:$JssorSlideshowFormations$.$FormationCircle,$Easing:$Jease$.$InBounce,$Assembly:264},
	              {$Duration:800,x:1,$Delay:40,$Cols:6,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:{$Left:$Jease$.$InOutQuart,$Opacity:$Jease$.$Linear},$Opacity:2,$ZIndex:-10,$Brother:{$Duration:800,x:1,$Delay:40,$Cols:6,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:{$Left:$Jease$.$InOutQuart,$Opacity:$Jease$.$Linear},$Opacity:2,$ZIndex:-10,$Shift:-60}},	              
	              {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationSwirl,$Easing:$Jease$.$OutQuad,$Opacity:2},
	              {$Duration:400,$Delay:50,$Rows:7,$Clip:4,$Formation:$JssorSlideshowFormations$.$FormationStraight},
	              {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Clip:$Jease$.$InSine},$Opacity:2,$Assembly:2050},
	              {$Duration:500,x:-1,$Delay:40,$Cols:10,$Rows:5,$SlideOut:true,$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$OutQuad},$Opacity:2},
	              {$Duration:500,$Delay:40,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Easing:$Jease$.$OutQuad,$Opacity:2},
	              {$Duration:600,y:-1,$Cols:12,$Formation:$JssorSlideshowFormations$.$FormationStraight,$ChessMode:{$Column:12},$Easing:$Jease$.$InCubic,$Opacity:2},
	              {$Duration:600,$Delay:40,$Cols:16,$Clip:1,$Move:true,$Formation:$JssorSlideshowFormations$.$FormationCircle,$Easing:$Jease$.$InBounce,$Assembly:264},
	              {$Duration:200,x:-1,y:1,$Delay:50,$Cols:10,$Rows:5,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Left:$Jease$.$InQuart,$Top:$Jease$.$InQuart,$Opacity:$Jease$.$Linear},$Opacity:2},	
	            ];

	            var jssor_1_options = {
	              $AutoPlay: 1,
	              $SlideDuration: 800,
	              $SlideEasing: $Jease$.$OutQuint,
	              $Cols: 1,
	              $Align: 0,
	              $CaptionSliderOptions: {
	                $Class: $JssorCaptionSlideo$,
	                $Transitions: jssor_1_SlideoTransitions
	              },
	              $ArrowNavigatorOptions: {
	                $Class: $JssorArrowNavigator$
	              },
	              $SlideshowOptions: {
                    $Class: $JssorSlideshowRunner$,
                    $Transitions: jssor_1_SlideoTransitions,
                    $TransitionsOrder: 0,
               	  }
	            };

	            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

	            /*#region responsive code begin*/

	            var MAX_WIDTH = 3000;

	            function ScaleSlider() {
	                var containerElement = jssor_1_slider.$Elmt.parentNode;
	                var containerWidth = containerElement.clientWidth;

	                if (containerWidth) {

	                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);

	                    jssor_1_slider.$ScaleWidth(expectedWidth);
	                }
	                else {
	                    window.setTimeout(ScaleSlider, 30);
	                }
	            }

	            ScaleSlider();

	            $(window).bind("load", ScaleSlider);
	            $(window).bind("resize", ScaleSlider);
	            $(window).bind("orientationchange", ScaleSlider);
	            /*#endregion responsive code end*/
	        });
			
		</script>
		<script src="js/valid.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/owl.navigation.js"></script>
		<script src="js/owl.autoplay.js"></script>
		<script src="js/jssor.slider-26.9.0.min.js"></script>

	</body>
</html>