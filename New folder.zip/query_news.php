<?php require 'database_conn.php';
	if (isset($_POST['news_submit'])) {
		$news_email = $_POST['inputNewsEmail'];

		$get_admin = "SELECT email FROM user WHERE username = 'eshop__admin'";
		$result=mysqli_query($conn,$get_admin);
		$row=mysqli_fetch_array($result);

		$admin_mail = $row['email'];

		$sql = "INSERT INTO newsletter_subscriber(email) VALUES ('$news_email');";

		require 'functions.php';

		if($result->num_rows == 1 && mysqli_query($conn,$sql)){
			if(NewsMail($admin_mail, $news_email)){
				echo "<script>window.history.go(-1);</script>";
			}else{
				echo "<script>alert('Error1 Occured. Please Retry');window.history.go(-1);</script>";	
			}
		}else{
			echo "<script>alert('Error Occured. Please Retry');window.history.go(-1);</script>";	
		}				
	}
	$conn->close(); 
	
?>