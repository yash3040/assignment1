<a href="" class="topbut">
	<svg width="50" height="50">
     	<image width="30" height="30" href="images/up-arrow-white.svg" />
	</svg>	
</a>
		
<footer class="footback">
	<section class="container">
		<section class="row">
			<section class="col-sm-12">
				<center>
				<form class="form-inline" id="NewsletterForm" method="post" onsubmit="return newsvalid();">
				  <div class="form-group">
				    <p class="addwish" id="newsmailp"></p>	 	
				    <label for="inputNewsEmail" class="subscribe">Subscribe for Newsletter</label>	
				    <input type="email" class="form-control formbot" id="inputNewsEmail" name="inputNewsEmail" placeholder="Enter your email address">	  
				  <button type="submit" id="news_submit" name="news_submit" class="btn btn-default btnr2">SIGN UP</button>

				  <?php require 'database_conn.php';
					if (isset($_POST['news_submit'])) {
						$news_email = $_POST['inputNewsEmail'];

						$sql = "INSERT INTO newsletter_subscriber(email) VALUES ('$news_email');";
						mysqli_query($conn,$sql);

						require 'functions.php';
						NewsMail($news_email);				
					}
				  ?>
				  </div>
				</form>
				<div class="menu-outer">
				  <div class="table">
				   	<ul id="horizontal-list">
					  <li class="forhov"><a href="index">Home</a></li>
					  <li class="forhov"><a href="about_us">About Us</a></li>
					  <li class="forhov"><a href="register">Register</a></li>
					  <li class="forhov"><a href="contact">Contact Us</a></li>
				    </ul>
				  </div>
				  <p class="textlast">
				  	&copy; 2017 eShopper online store.All rights reserved.
				  </p>
				</div>
			</center>
			</section>
		</section>
	</section>
</footer>	