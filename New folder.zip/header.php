<?php require 'database_conn.php';
	session_start();

	$sql1 = "SELECT name FROM category WHERE parent_id = 0";
	$result1 = $conn->query($sql1);

	if ($result1->num_rows > 0) {			   
		$category = mysqli_fetch_all($result1);			    
	}else{
		echo "No Categories";
	}  

	$sql2 = "SELECT B.name FROM category A, category B WHERE A.id = B.parent_id AND A.name = 'MEN'";
	$result2 = $conn->query($sql2);

	if ($result2->num_rows > 0) {			   
		$subcategory = mysqli_fetch_all($result2);			    
	}else{
		echo "No Categories";
	} 
?>
<header>
			<nav class="navbar navbar-default navdef">
			  <div class="container">
			    <!-- Brand and toggle get grouped for better mobile display -->
				<section class="row">
					<section class="col-sm-1">
					    <div class="navbar-header">
					      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
					        <span class="sr-only">Toggle navigation</span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					        <span class="icon-bar"></span>
					      </button>

					      <a class="navbar-brand elogo" href="#">
						        <svg height="50" width="50">
								  	<image height="50" width="50"  href="images/logo.svg" />
							    </svg>
						  </a>		

					    </div>
					</section> 
					<!-- Collect the nav links, forms, and other content for toggling -->
					<section class="col-sm-5 col-xs-12 sec">
						<div class="collapse navbar-collapse abs" id="bs-example-navbar-collapse-1">					     
					      <ul class="nav navbar-nav headul">
					        <li class="htext"><a class="headtext" href="index">HOME</a></li>
					        <li class="dropdown htext mentxt"><a href="#" class="dropdown-toggle headtext" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
					        	<?php
					        		echo implode("",$category[0]);
					        	?></a>
					         <ul class="dropdown-menu dmenu">
					            <?php
					            	echo '<li class="lihov"><a class="topa" href="#">'.implode("",$subcategory[0]).'</a></li>';
					            	for ($i=1; $i < $result2->num_rows; $i++) { 
					            		echo '<li class="lihov"><a href="#">'.implode("",$subcategory[$i]).'</a></li>';
					            	}
					            ?>
					          </ul>
					        </li>
					        <?php
				            	for ($j=1; $j < $result1->num_rows; $j++) { 
				            		echo '<li class="htext"><a class="headtext" href="#">'.implode("",$category[$j]).'</a></li>';
				            	}
					        ?>
					      </ul>							
						</div><!-- /.navbar-collapse -->				  
					</section>						
					<section class="col-sm-6 col-xs-12 rightsec">
						<ul class="nav navbar-nav navbar-right text-center">
                            
                            	<?php
                            		if (isset($_SESSION['logged'])) {
                            			echo '<li class="inline"><a href="#" class="botpad0 rightbor">Welcome, '.$_SESSION["fname"].'</a></li>';
                            			echo '<li class="inline"><a href="profile" class="botpad0 rightbor">Profile</a></li>';
                            			echo '<li class="inline"><a href="logout.php" class="botpad0 login rightbor">Logout</a></li>';
                            		}
                            		else{
                            			echo '<li class="inline"><a href="#" class="botpad0 login" data-toggle="modal" data-target="#loginmodal">Login</a></li>';
                            		}
                            	?>
                            

                            <!--Cart-->
                            <li class="dropdown inline licrt">
								    <a class="dropdown-toggle botpad0" id="menu1" data-toggle="dropdown">
								    
								    <div class="cart inline"></div></a>

								    <!--Cart Dropdown-->
								    <ul class="dropdown-menu ulddcart" role="menu" aria-labelledby="menu1">
								      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">Recently Added Item(s)</a></li>
								      <li role="presentation"><a role="menuitem" tabindex="-1" href="#">

								      	<div class="table-responsive">          
										  <table class="table">
										    <tbody class="tdbord0">
										      <tr>
										        <td><img src="images/new-thumb-01.jpg" class="img-responsive crtimg" alt="cart-img01"></td>
										        <td>U.S. Polo Assn. <br>Full Sleeve Plain <br>T-Shirt for Men
										        	<p class="text4 crtp">&dollar;120.00</p>
										        	<p class="crtp">Qty: 1</p>	
										        	<p class="crtp">Size: Medium/Large</p>		        	
										        </td>
										        <td>
										        	<svg height="14" width="20">
											  			<image height="14" width="15"  href="images/edit-dark.svg" />
													</svg>
												</td>										       
										        <td>
										        	<svg height="14" width="20">
											  			<image height="14" width="15"  href="images/cross-dark.svg" />
													</svg>
										        </td>
										      </tr>	
										      <tr>
										        <td><img src="images/new-thumb-02.jpg" class="img-responsive crtimg" alt="cart-img01"></td>
										        <td>U.S. Polo Assn. <br>Full Sleeve Plain <br>T-Shirt for Men
										        	<p class="text4 crtp">&dollar;120.00</p>
										        	<p class="crtp">Qty: 1</p>	
										        	<p class="crtp">Size: Medium/Large</p>		        	
										        </td>
										        <td>
										        	<svg height="14" width="20">
											  			<image height="14" width="15"  href="images/edit-dark.svg" />
													</svg>
												</td>										       
										        <td>
										        	<svg height="14" width="20">
											  			<image height="14" width="15"  href="images/cross-dark.svg" />
													</svg>
										        </td>
										      </tr>		
										      <tr>
										        <td><p>Cart Subtotal :</p></td>
										        <td><p class="text4">&dollar;120.00</p></td>
										      </tr>	
										      <tr>
										      	<td></td>
										        <td><button type="button" class="btn btn-default btnr2">View Cart</button></td>
										      </tr>			      
										    </tbody>
										  </table>
										</div>

								      </a></li>
								     
								    </ul><!--/Cart Dropdown--> 
								</li> <!--/Cart-->
							

                            <li class="inline lisrch">    
								<input class="search" type="search" placeholder="Search" />
							    <button class="icon" aria-label="Left Align">						
							  		<svg width="20" height="25">
		                               	<image width="20" height="25" href="images/search.svg" />
		                       		</svg>	
								</button>                    	
                            </li> 
                        </ul>				
					</section>				
				</section>
			  </div><!-- /.container-fluid -->
			</nav>	
		</header>

		<!--Login Modal-->
			<div class="modal fade" id="loginmodal" tabindex="-1" role="dialog" aria-labelledby="gridSystemModalLabel">
			  <div class="modal-dialog" role="document">
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			        <h4 class="modal-title text-center" id="gridSystemModalLabel">eShopper Login</h4>
			      </div>
			      	<form id="loginform" action="login.php" method="post" onsubmit="return loginvalid();" enctype="multipart/form-data">
				      <div class="modal-body">
				        <div class="row">
				          <div class="col-sm-12">
							  	<div class="form-group">
								    <label for="inputLogUserName">Username</label>
								    <input type="text" class="form-control" id="inputLogUserName" name="inputLogUserName" placeholder="Please enter your username">
								    <p id="logunamep" class="addwish"></p>
								</div>
								<div class="form-group">
								    <label for="inputLogPassword">Password</label>
								    <input type="password" class="form-control" id="inputLogPassword" name="inputLogPassword" placeholder="Please enter your password">
								    <p id="logpassp" class="addwish"></p>
								</div>
				     	  </div>			     	 			          
				        </div>
				      </div>
				      <div class="modal-footer row">
				         <div class="col-sm-6">
				         	<div class="pull-left">
				     	  		<button type="submit" id="logsubmit" name="logsubmit" class="btn btn-default btnr2">Login</button>
				     	  	</div>	
				     	  </div>
				     	  <div class="col-sm-6">
				     	  		<div class="pull-right">
									Not a Member&quest;<a href="register" class="reg">Register</a>							
								</div>
				     	  </div>
				      </div>
					</form>
			    </div><!-- /.modal-content -->
			  </div><!-- /.modal-dialog -->
			</div><!-- /.modal -->