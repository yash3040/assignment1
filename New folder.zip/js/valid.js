var $uname = $('#inputUserName');
var $pass = $('#inputPassword');
var $pass2 = $('#inputPassword2');
var $loguname = $('#inputLogUserName');
var $logpass = $('#inputLogPassword');
var $gndr = $('[name=gender]');
var $mail = $('#inputEmail');
var $fname = $('#inputFname');
var $mob = $('#inputMobNo');
var $phone = $('#inputPhone');
var $all = $('#all');
var $opt1 = $('#opt1');
var $opt2 = $('#opt2');
var $opt3 = $('#opt3');
var $optoth = $('#optoth');
var $checktxt = $('#checktxt');
var $term = $('#term');
var $strt = $('#inputStreet');
var $cty = $('#inputCity');
var $cntry = $('#inputCountry');
var $stt = $('#inputState');
var $sameadd = $('#sameadd');
var $strt2 = $('#inputStreet2');
var $cty2 = $('#inputCity2');
var $cntry2 = $('#inputCountry2');
var $stt2 = $('#inputState2');
var $con_name = $('#inputConName');
var $con_mail = $('#inputConEmail');
var $subject = $('#inputSubject');
var $message = $('#inputMessage');
var $news_email = $('#inputNewsEmail');
var $unameregex = /^[a-z0-9_-]{8,}$/i;
var $passregex = /^(?=.*[a-z])(?=(?:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/;
var $passregex2 = /^[a-f0-9]{32}$/i;
var $mailregex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var $fnameregex = /^[A-Za-z]+$/;
var $mobregex = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
var $phoneregex = /^\d{10}$/;

function valid() {  
    
    //validation for username
    if($uname.val() == "") {
        $('#unamep').text('Enter a username');
        $uname.focus();
        $flag = 1;
    }
    else if(!$unameregex.test($uname.val())) {
        $('#unamep').text('Enter a valid Username');
        $uname.focus();
        $flag = 1;
    }
    else{
        $('#unamep').text("");                  
    }

    //validation for password and confirm password
    if($pass.val() == ""){
        $('#passp').text('Enter a password');
        $pass.focus();
        $flag = 1;
    }
    else if(!$passregex.test($pass.val()) && !$passregex2.test($pass.val())){
        $('#passp').text('Enter a valid password');
        $pass.focus();
        $flag = 1;
    }
    else{        
        $('#passp').text("");
    } 

    if(!($pass.val() == $pass2.val())){
        $('#passp2').text('Please Enter Same as Password');
        $pass2.focus();
        $flag = 1;
    }
    else{
        $('#passp2').text("");
    }

    //validation for gender
    if(!$gndr[0].checked && !$gndr[1].checked){
        $('#gndrp').text('Please select gender.');
        $flag = 1;
    }
    else{
        $('#gndrp').text("");
    }

    //validation for email
    if($mail.val() == ""){
        $('#mailp').text('Enter a email');
        $mail.focus();
        $flag = 1;
    }
    else if(!$mailregex.test($mail.val())){
        $('#mailp').text('Enter a valid email');
        $mail.focus();
        $flag = 1;
    }
    else{
        $('#mailp').text("");
    }

    //validation for first name
    if($fname.val() == ""){
        $('#fnamep').text('Enter First Name');
        $fname.focus();
        $flag = 1;
    }
    else if(!$fnameregex.test($fname.val())){
        $('#fnamep').text('Enter a valid name');
        $fname.focus();
        $flag = 1;
    }
    else{
        $('#fnamep').text("");
    }

    //validation for mobile number in US format
    if($mob.val() == ""){
        $('#mobp').text('Enter a mobile number');
        $mob.focus();
        $flag = 1;
    }
    else if(!$mobregex.test($mob.val())){
        $('#mobp').text('Enter a valid number');
        $mob.focus();
        $flag = 1;
    }
    else{
        $('#mobp').text("");
    }

    //validation for phone number
    if($phone.val() == ""){
        $('#phonep').text("");
    }
    else if(!$phoneregex.test($phone.val())){
        $('#phonep').text('Enter a valid number');
        $phone.focus();
        $flag = 1;
    }
    else{
        $('#phonep').text("");
    }

    //for checkboxes
    if(!$opt1.is(':checked')){
        if (!$opt2.is(':checked')) {
            if (!$opt3.is(':checked')) {
                if (!$optoth.is(':checked')) {
                    $('#checkp').text('Please select any one');
                    $flag = 1;
                }               
                else{
                    $('#checkp').text("");
                }
            }
            else{
                $('#checkp').text("");
            }
        }
        else{
            $('#checkp').text("");
        }       
    }
    else{
        $('#checkp').text("");
    }

    //for other textbox
    if ($optoth.is(':checked')) {
        if ($checktxt.val() == "") {
            $('#checkp').text('Enter your interest');
            $flag = 1;
        } else {
            $('#checkp').text("");
        }
    }

    if ($flag == 0) {
        return true;
    }
    else{
        return false;
    }
}       

function termfunc(){
    //For terms and conditions
    if(!$term.is(':checked')){
        $('#termsp').text('Please Accept terms and conditions.');
        $flag = 1;
    }   
    else{
        $('#termsp').text("");
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    }
    else{
        return false;
    }
}

//for address collapse
function prfl(){
   
    if ($strt.val() == "") {
        $('#strtp').text('Please Enter Street');
        $flag = 1;
    }
    else{
        $('#strtp').text("");
    }

    if ($cty.val() == "") {
        $('#ctyp').text('Please Enter City');
        $flag = 1;
    }
    else{
        $('#ctyp').text("");
    }

    if ($strt2.val() == "") {
        $('#strt2p').text('Please Enter Street');
        $flag = 1;
    }
    else{
        $('#strt2p').text("");
    }

    if ($cty2.val() == "") {
        $('#cty2p').text('Please Enter City');
        $flag = 1;
    }
    else{
        $('#cty2p').text("");
    }

    if ($cntry.val() == "") {
        $('#cntryp').text('Please Select Country');
        $flag = 1;
    }
    else{
        $('#cntryp').text("");
    }

    if ($cntry2.val() == "") {
        $('#cntry2p').text('Please Select Country');
        $flag = 1;
    }
    else{
        $('#cntry2p').text("");
    }

    if ($stt.val() == "") {
        $('#sttp').text('Please Select State');
        $flag = 1;
    }
    else{
        $('#sttp').text("");
    }

    if ($stt2.val() == "") {
        $('#stt2p').text('Please Select State');
        $flag = 1;
    }
    else{
        $('#stt2p').text("");
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    }
    else{
        return false;
    }
}


function contactvalid() {    
    
    //validation for name
    if($con_name.val() == "") {
        $('#namep').text('Enter a Name');
        $con_name.focus();
        $flag = 1;
    }
    else if(!$fnameregex.test($con_name.val())) {
        $('#namep').text('Enter a valid Name');
        $con_name.focus();
        $flag = 1;
    }
    else{
        $('#namep').text("");  
    }

   //validation for email
    if($con_mail.val() == ""){
        $('#conmailp').text('Enter a Email');
        $con_mail.focus();
        $flag = 1;
    }
    else if(!$mailregex.test($con_mail.val())){
        $('#conmailp').text('Enter a valid Email');
        $con_mail.focus();
        $flag = 1;
    }
    else{
        $('#conmailp').text("");
    }

    //validation for subject
    if($subject.val() == ""){
        $('#subp').text('Enter a Subject');
        $subject.focus();
        $flag = 1;
    }
    else{
        $('#subp').text("");
    }

    //validation for message
    if($message.val() == ""){
        $('#msgp').text('Enter a Message');
        $message.focus();
        $flag = 1;
    }
    else{
        $('#msgp').text("");
    }

    if ($flag == 0) {
        return true;
    }
    else{
        return false;
    }
}   


function newsvalid() {    

   //validation for email
    if($news_email.val() == ""){
        $('#newsmailp').text('Enter a Email');
        $news_email.focus();
        $flag = 1;
    }
    else if(!$mailregex.test($news_email.val())){
        $('#newsmailp').text('Enter a valid Email');
        $news_email.focus();
        $flag = 1;
    }
    else{
        $('#newsmailp').text("Thank You For Subscription");
        $('#newsmailp').addClass("news");
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    }
    else{
        return false;
    }
}   


function loginvalid() {    
    
    //validation for username
    if($loguname.val() == "") {
        $('#logunamep').text('Enter a username');
        $loguname.focus();
        $flag = 1;
    }
    else if(!$unameregex.test($loguname.val())) {
        $('#logunamep').text('Enter a valid Username');
        $loguname.focus();
        $flag = 1;
    }
    else{
        $('#logunamep').text("");  
    }

    //validation for password
    if($logpass.val() == ""){
        $('#logpassp').text('Enter a password');
        $logpass.focus();
        $flag = 1;
    }
    else if(!$passregex.test($logpass.val())){
        $('#logpassp').text('Enter a valid password');
        $logpass.focus();
        $flag = 1;
    }
    else{
        $('#logpassp').text("");
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    }
    else{
        return false;
    }
}  


//For checkboxes
function allcheck() {
    
    if ($all.is(':checked')){
        $opt1.prop('checked', true);
        $opt2.prop('checked', true);
        $opt3.prop('checked', true);
    } 
    else{
        $opt1.prop('checked', false);
        $opt2.prop('checked', false);
        $opt3.prop('checked', false);
    }
}    

function indicheck() {
        
    if(!$opt1.is(':checked') || !$opt2.is(':checked') || !$opt3.is(':checked')){
        $all.prop('checked', false);
    }
   
    if($opt1.is(':checked') && $opt2.is(':checked') && $opt3.is(':checked')){
        $all.prop('checked', true);
    }

    if($optoth.is(':checked')){
        $checktxt.prop('readonly', false);
    }
    else{
        $checktxt.prop('readonly', true);
        $checktxt.val("");
    }
}


function cpyadd() { 


    if($sameadd.is(':checked')){

        $strt2.val($strt.val());
        $cty2.val($cty.val());
        $cntry2.val($cntry.val());

        var $cpystt = $("#inputState > option").clone(); 
        $stt2.empty();
        $stt2.append($cpystt);
        $stt2.val($stt.val());     
        
        $strt2.prop('readonly', true);
        $cty2.prop('readonly', true);
        $cntry2.prop('disabled', true);
        $stt2.prop('disabled', true);  

        $strt.on('input',function() {
            window.setTimeout(function() {
               $strt2.val($strt.val());
            }, 0);
        });  

        $cty.on('input',function() {
            window.setTimeout(function() {
               $cty2.val($cty.val());
            }, 0);
        });

        $cntry.on('input',function() {
            window.setTimeout(function() {
               $cntry2.val($cntry.val());
            }, 0);
        });

        $stt.on('input',function() {
            window.setTimeout(function() {
                var $cpystt = $("#inputState > option").clone(); 
                $stt2.empty();
                $stt2.append($cpystt);
                $stt2.val($stt.val());     
            }, 0);
        });
    }
    else{
        $strt2.prop('readonly', false);
        $cty2.prop('readonly', false);
        $cntry2.prop('disabled', false);
        $stt2.prop('disabled', false);
        $strt.off();
        $cty.off();
        $cntry.off();
        $stt.off();
    }
}

function clr() {
    if (confirm("Are you sure you want to clear the form")) {
        $('#form1')[0].reset();
    }   
}


$(document).ready(function(){

    $strt.on('input',function() {
            window.setTimeout(function() {
               $strt2.val($strt.val());
            }, 0);
        });  

        $cty.on('input',function() {
            window.setTimeout(function() {
               $cty2.val($cty.val());
            }, 0);
        });

        $cntry.on('input',function() {
            window.setTimeout(function() {
               $cntry2.val($cntry.val());
            }, 0);
        });

        $stt.on('input',function() {
            window.setTimeout(function() {
                var $cpystt = $("#inputState > option").clone(); 
                $stt2.empty();
                $stt2.append($cpystt);
                $stt2.val($stt.val());     
            }, 0);
        });

    //for search bar.
    $('.icon').click(function () {
        $('.search').toggleClass('expanded');
    });
    
    
    //for profile address
    var id=$("#inputCountry").val();
    var dataString = 'id='+ id;
    $("#inputState").find('option').remove();
    
    $.ajax
    ({
      type: "POST",
      url: "state.php",
      data: dataString,
      cache: false,
      success: function(html)
      {
        
        $("#inputState").html(html);
      } 
    });

    var id=$("#inputCountry2").val();
    var dataString = 'id='+ id;
    $("#inputState2").find('option').remove();
    
    $.ajax
    ({
      type: "POST",
      url: "state2.php",
      data: dataString,
      cache: false,
      success: function(html)
      {
        
        $("#inputState2").html(html);
      } 
    });

 $("#inputCountry").change(function(){
    
    var id=$(this).val();
    var dataString = 'id='+ id;
    $("#inputState").find('option').remove();
    
    $.ajax
    ({
      type: "POST",
      url: "state.php",
      data: dataString,
      cache: false,
      success: function(html)
      {
        
        $("#inputState").html(html);
      } 
    });
  });

  $("#inputCountry2").change(function(){
    
    var id=$(this).val();
    var dataString = 'id='+ id;
    $("#inputState2").find('option').remove();
    
    $.ajax
    ({
      type: "POST",
      url: "state2.php",
      data: dataString,
      cache: false,
      success: function(html)
      {
        
        $("#inputState2").html(html);
      } 
    });
  });  


    //for cart dropdown
    $("#menu1").click(function(){
        $(".ulddcart").slideToggle();
    })  


    //for go to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.topbut').fadeIn();
        } else {
            $('.topbut').fadeOut();
        }
    });

    $('.topbut').click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });
})        

 
