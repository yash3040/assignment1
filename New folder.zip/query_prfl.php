<?php require 'database_conn.php';
	if (isset($_POST['update'])) {
		$username = $_POST['inputUserName'];
		$gender = $_POST['gender'];
		$email = $_POST['inputEmail'];
		$fname = $_POST['inputFname'];
		$mobile = $_POST['inputMobNo'];
		$lname = $_POST['inputLname'];
		$phone = $_POST['inputPhone'];
		$street=$_POST['inputStreet'];
		$city=$_POST['inputCity'];
		$state=$_POST['inputState'];
		if(isset($_POST['sameadd'])){
			$street2=$street;
			$city2=$city;
			$state2=$state;
		}
		else{
			$street2=$_POST['inputStreet2'];
			$city2=$_POST['inputCity2'];
			$state2=$_POST['inputState2'];
		}

		$uni_email1 = "SELECT email FROM user WHERE username != '$username' AND email = '$email'";
		$uniresult1 = $conn->query($uni_email1);

		if($uniresult1->num_rows == 0){

			$sql1="SELECT billing_add_id, shipping_add_id FROM user WHERE username = '$username'";
			$result1=mysqli_query($conn,$sql1);
			$row1=mysqli_fetch_array($result1);

			if( is_null($row1['billing_add_id'])){

				$sql2="INSERT INTO address(street, city, state_id) VALUES('$street','$city','$state')";	

	         	if ($conn->query($sql2) == TRUE) {
	         		$bill_id=mysqli_insert_id($conn);
	         		$sql1 = "UPDATE user SET billing_add_id = '$bill_id' WHERE username = '$username'";
			        $conn->query($sql1);
	    		}
			}
			else{
				$bil_id=$row1['billing_add_id'];
				$sql1 = "UPDATE address SET street = '$street', city = '$city', state_id = '$state' WHERE id = '$bil_id'";
			    $conn->query($sql1);	    		
			}
			if(is_null($row1['shipping_add_id'])){

				$sql2="INSERT INTO address(street, city, state_id) VALUES ('$street2', '$city2', '$state2')";	

	         	if ($conn->query($sql2) == TRUE) {
	         		$ship_id=mysqli_insert_id($conn);
	         		$sql1 = "UPDATE user SET shipping_add_id = '$ship_id' WHERE username = '$username'";
			        $conn->query($sql1);
	    		}				
			}
			else{
				$shi_id=$row1['shipping_add_id'];
				$sql1 = "UPDATE address SET street = '$street2', city = '$city2', state_id = '$state2' WHERE id = '$shi_id'";
			    $conn->query($sql1);
	    		
			}		

			$sql = "UPDATE user SET gender = '$gender', email = '$email', firstname = '$fname', mobile_number = '$mobile', lastname = '$lname', phone_number = '$phone' WHERE username = '$username';";	

			if($conn->query($sql) == TRUE){
				header("location: index.php");
			}
			else{
				echo "<script>alert('Error occured. Please Retry');window.location.href='profile.php'</script>";
			}	

		}
		else{
			echo "<script>alert('Email is already registered');window.location.href='profile.php'</script>";
		}		
	}
	$conn->close(); 
	
?>