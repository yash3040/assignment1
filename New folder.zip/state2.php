<?php require 'database_conn.php';
	session_start();
	if($_POST['id'])
	{
		$id=$_POST['id'];
		$sql="SELECT * FROM state WHERE country_id = '$id'";
	    $result=$conn->query($sql);
	    
		?><option selected>Select State</option>
		<?php
		$id1 = $_SESSION['id'];
		$sql1 = "SELECT * FROM user WHERE id = '$id1'";
  		$result1=$conn->query($sql1);
		$row=mysqli_fetch_object($result1);
		$ship_id = $row->shipping_add_id;
    	$shipsql = "SELECT street, city, state_id, country_id, state.name AS state, country.name AS country FROM user INNER JOIN address ON user.shipping_add_id = address.id INNER JOIN state ON address.state_id = state.id INNER JOIN country ON state.country_id = country.id WHERE shipping_add_id = '$ship_id'";
		$shipresult = mysqli_query($conn,$shipsql);
		$shiprow=mysqli_fetch_object($shipresult);
		
		while($row2=mysqli_fetch_object($result))
	    {
	    	if(isset($shiprow->state) && $row2->id == $shiprow->state_id){
      			echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
      		}
      		else{				                
               	echo "<option value='".$row2->id."'>".$row2->name."</option>";
            } 
		}
	}
?>