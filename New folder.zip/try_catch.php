<?php
    class customException extends Exception {

        public $arr = array();
        public $username, $password, $password2, $email, $firstname, $mobile, $phone, $othtxt;
        public $unameregex, $passregex, $mailregex, $fnameregex, $mobregex, $phoneregex;
        public $street1, $city1, $country1, $state1, $street2, $city2, $country2, $state2;

        function __construct() {
            $this->username = $this->test_input($_POST['inputUserName']);
            $this->password = $this->test_input($_POST['inputPassword']);
            $this->password2 = $this->test_input($_POST['inputPassword2']);
            $this->email = $this->test_input($_POST['inputEmail']);
            $this->firstname = $this->test_input($_POST['inputFname']);
            $this->mobile = $this->test_input($_POST['inputMobNo']);
            $this->phone = $this->test_input($_POST['inputPhone']);
            $this->othtxt = $this->test_input($_POST['checktxt']);
            $this->street1 = $this->test_input($_POST['inputStreet']);
            $this->city1 = $this->test_input($_POST['inputCity']);
            $this->street2 = $this->test_input($_POST['inputStreet2']);
            $this->city2 = $this->test_input($_POST['inputCity2']);
            $this->unameregex = "/^[a-zA-Z0-9_-]{8,}$/";
            $this->passregex = "/^(?=.*[a-z])(?=(?:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/";
            $this->passregex2 = "/^[a-f0-9]{32}$/i";            
            $this->mailregex = '/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/';
            $this->fnameregex = "/^[A-Za-z]+$/";
            $this->mobregex = "/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/";
            $this->phoneregex = "/^\d{10}$/";
        }

        function test_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        function error() {
            try {
                if (!preg_match($this->unameregex, $this->username)) {
                    $this->arr['username'] = "Enter a valid username";
                }
                if (!isset($_POST['gender'])) {
                    $this->arr['gender'] = "Please Select your gender";
                }
                if (!preg_match($this->passregex, $this->password) && !preg_match($this->passregex2, $this->password)) {
                    $this->arr['password'] = "Enter a valid password";
                }
                if (!($this->password2 == $this->password)) {
                    $this->arr['password2'] = "Enter same as password";
                }
                if (!preg_match($this->mailregex, $this->email)) {
                    $this->arr['email'] = "Enter a valid email";
                }
                if (!preg_match($this->fnameregex, $this->firstname)) {
                    $this->arr['firstname'] = "Only alphabets";
                }
                if (!preg_match($this->mobregex, $this->mobile)) {
                    $this->arr['mobile'] = "US format, with or without dashes";
                }
                if (!empty($this->phone) && !preg_match($this->phoneregex, $this->phone)) {
                    $this->arr['phone'] = "Please enter valid number";
                }
                if (!isset($_POST['all']) && !isset($_POST['opt1']) && !isset($_POST['opt2']) && !isset($_POST['opt3']) && !isset($_POST['optoth']))
                {
                    $this->arr['interest'] = "Please select anyone";
                }
                if (isset($_POST['optoth']) && empty($this->othtxt)) {
                    $this->arr['interest'] = "Please enter your interest";
                }                    
                if ($this->arr) {
                    $this->arr['inputUserVal'] = $this->username;
                    if(isset($_POST['gender'])){
                        $this->arr['genderVal'] = $_POST['gender'];
                    }
                    $this->arr['inputPassVal'] = $this->password;
                    $this->arr['inputPass2Val'] = $this->password2;
                    $this->arr['inputEmailVal'] = $this->email;
                    $this->arr['inputMobVal'] = $this->mobile;
                    $this->arr['inputFnameVal'] = $this->firstname;
                    $this->arr['inputPhoneVal'] = $this->phone;
                    if(isset($_POST['inputLname'])){
                        $this->arr['inputLnameVal'] = $_POST['inputLname'];
                    }
                    if(isset($_POST['all'])){
                    $this->arr['inputAllVal'] = isset($_POST['all']);
                    }
                    if(isset($_POST['opt1'])){
                    $this->arr['inputOneVal'] = isset($_POST['opt1']);
                    }
                    if(isset($_POST['opt2'])){
                    $this->arr['inputTwoVal'] = isset($_POST['opt2']);
                    }
                    if(isset($_POST['opt3'])){
                    $this->arr['inputThreeVal'] = isset($_POST['opt3']);
                    }
                    if(isset($_POST['optoth'])){
                    $this->arr['inputOtherVal'] = isset($_POST['optoth']);
                    }
                    $this->arr['inputOthTxtVal'] = $this->othtxt;
                    throw new customException();
                } 
            } catch (customException $ex) {
                $err = json_encode($this->arr);
                $second = time() + 1;
                setcookie('error', $err, $second);
            }
        }

        function term() {
            try {
                if (!isset($_POST['term'])) {
                    $this->arr['terms'] = "Please accept terms and conditions";
                }
                if ($this->arr) {
                    if(isset($_POST['term'])){
                        $this->arr['inputTermVal'] = isset($_POST['term']);
                    }
                    throw new customException();
                } else {
                    require 'query_reg.php';
                }
            } catch (customException $ex) {
                $err = json_encode($this->arr);
                $second = time() + 1;
                setcookie('error', $err, $second);
                header("location:register");
            }
        }

        function address() {
            try {
                if (empty($this->street1)) {
                    $this->arr['street1'] = "Please Enter Street";
                }
                if (empty($this->street2)) {
                    $this->arr['street2'] = "Please Enter Street";
                }
                if (empty($this->city1)) {
                    $this->arr['city1'] = "Please Enter city";
                }
                if (empty($this->city2)) {
                    $this->arr['city2'] = "Please Enter city";
                }
                if (!isset($_POST['inputCountry'])) {
                    $this->arr['country1'] = "Please Select Country";
                }
                
                if (!isset($_POST['inputState'])) {
                    $this->arr['state1'] = "Please Select state";
                }
                if(!isset($_POST['sameadd'])){
                    if (!isset($_POST['inputCountry2'])) {
                        $this->arr['country2'] = "Please Select Country";
                    }
                    if (!isset($_POST['inputState2'])) {
                        $this->arr['state2'] = "Please Select state";
                    }
                }
                if ($this->arr) {
                    throw new customException();
                } else {
                    require 'query_prfl.php';
                }
            } catch (customException $ex) {
                $err = json_encode($this->arr);
                $second = time() + 1;
                setcookie('error', $err, $second);
                header("location:profile");  
            }
        }

    }

    if (isset($_POST['regsubmit'])) {
        $reg = new customException();
        $reg->error();
        $reg->term();
    }

    if (isset($_POST['update'])) {
        $prfl = new customException();
        $prfl->error();
        $prfl->address();
    }
?>