<!DOCTYPE html>
<html lang="en">
	<head>
	    <title>Register</title>
	    <link rel="shortcut icon" href="images/favicon.ico">
	    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
	 	<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/media.css">
	</head>
	<body>

		<?php require 'header.php'; ?>

		<section class="container-fluid banpad">
			<section class="row">
				<img src="images/inner-banner.jpg" class="abtban img-responsive">	
			</section>
		</section>	

		<section class="container">						
			<h2 class="crt">Register</h2>			
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb brdcrmb">
			    <li class="breadcrumb-item"><a href="index">Home</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Register</li>
			  </ol>
			</nav>
		</section>

		<form id="form1" action="try_catch" method="post" onsubmit="return !!(valid() & termfunc());">	

			<?php
                if (isset($_COOKIE['error'])) {
                    $error = $_COOKIE['error'];
                    $error = json_decode($error, TRUE);                
                }
            ?>

			<section class="container bordbot">			
				<h2 class="regh2">New Customers</h2>
				<p>By creating an account with our store, you will be able to move to the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputUserName">Username</label>
						    <input type="text" class="form-control" id="inputUserName" name="inputUserName" placeholder="Please enter your username" title="minimum 8 charcters and alphanumeric and - _ allowed" value="<?php if(isset($error['inputUserVal'])){ echo $error['inputUserVal'];} ?>">
						    <p id="unamep" class="addwish"><?php if(isset($error['username'])){echo $error['username'];} ?></p>
						</div>
					</div>

					<div class="col-sm-6">
						<b>Gender</b></br>
					    <label class="radio-inline">
					      <input type="radio" name="gender" id="male" value="Male" <?php if(isset($error['genderVal']) && $error['genderVal'] == 'Male'){ echo "checked";}?>>Male
					    </label>
					    <label class="radio-inline">
					      <input type="radio" name="gender" id="female" value="Female" <?php if(isset($error['genderVal']) && $error['genderVal'] == 'Female'){ echo "checked";}?>>Female
					    </label>
					    <p class="addwish" id="gndrp"><?php if(isset($error['gender'])){echo $error['gender'];} ?></p>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputPassword">Password</label>
						    <input type="password" class="form-control" id="inputPassword" name="inputPassword" placeholder="Please enter your password" title="at least one number,special,lowercase character and 2 uppercase characters" value="<?php if(isset($error['inputPassVal'])){ echo $error['inputPassVal'];} ?>">
						    <p class="addwish" id="passp"><?php if(isset($error['password'])){echo $error['password'];} ?></p>
						</div>
					</div>
					
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputPassword2">Confirm Password</label>
						    <input type="password" class="form-control" id="inputPassword2" name="inputPassword2" placeholder="Please confirm yopur password" title="same as your password" value="<?php if(isset($error['inputPass2Val'])){ echo $error['inputPass2Val'];} ?>">
						    <p class="addwish" id="passp2"><?php if(isset($error['password2'])){echo $error['password2'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputEmail">Email</label>
						    <input type="email" class="form-control" id="inputEmail" name="inputEmail" placeholder="Please enter valid email" title="standard email" value="<?php if(isset($error['inputEmailVal'])){ echo $error['inputEmailVal'];} ?>">
						    <p class="addwish" id="mailp"><?php if(isset($error['email'])){echo $error['email'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputFname">First Name</label>
						    <input type="text" class="form-control" id="inputFname" name="inputFname" placeholder="Please enter your first name" title="Only alphabets" value="<?php if(isset($error['inputFnameVal'])){ echo $error['inputFnameVal'];} ?>">
						    <p class="addwish" id="fnamep"><?php if(isset($error['firstname'])){echo $error['firstname'];} ?></p>
						</div>
					</div>
					
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputMobNo">Mobile No.</label>
						    <input type="text" class="form-control" id="inputMobNo" name="inputMobNo" placeholder="Please enter your mobile no." title="US format, with or without dashes" value="<?php if(isset($error['inputMobVal'])){ echo $error['inputMobVal'];} ?>">
						    <p class="addwish" id="mobp"><?php if(isset($error['mobile'])){echo $error['mobile'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputLname">Last Name</label>
						    <input type="text" class="form-control" id="inputLname" name="inputLname" placeholder="Please enter your last name"" title="Only alphabets" value="<?php if(isset($error['inputLnameVal'])){ echo $error['inputLnameVal'];} ?>">
						    <p class="addwish" id="lnamep"></p>
						</div>
					</div>
					
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputPhone">Phone</label>
						    <input type="text" class="form-control" id="inputPhone" name="inputPhone" placeholder="Please enter your phone" title="Only 10 digits" value="<?php if(isset($error['inputPhoneVal'])){ echo $error['inputPhoneVal'];} ?>">
						    <p class="addwish" id="phonep"><?php if(isset($error['phone'])){echo $error['phone'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-12">
						<b>Interests</b>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="all" name="all" <?php if(isset($error['inputAllVal'])){ echo "checked";}?> onclick="allcheck()">Select All</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="opt1" name="opt1" <?php if(isset($error['inputOneVal'])){ echo "checked";}?> onclick="indicheck()">Option 1</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="opt2" name="opt2" <?php if(isset($error['inputTwoVal'])){ echo "checked";}?> onclick="indicheck()">Option 2</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="opt3" name="opt3" <?php if(isset($error['inputThreeVal'])){ echo "checked";}?> onclick="indicheck()">Option 3</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="optoth" name="optoth" <?php if(isset($error['inputOtherVal'])){ echo "checked";}?> onclick="indicheck()">Other
					      		 <input type="text" value="" id="checktxt" name="checktxt" value="<?php if(isset($error['inputOthTxtVal'])){ echo $error['inputOthTxtVal'];} ?>" readonly>
					      </label>
					      <p class="addwish" id="checkp"><?php if(isset($error['interest'])){echo $error['interest'];} ?></p>
					    </div>
					</div>
				</div>			

			</section>	

			<section class="container toppad">
				<div class="row botpad">
					<div class="col-sm-6">
						<div class="checkbox">
						    <label><input type="checkbox" value="" id="term" name="term" <?php if(isset($error['inputTermVal'])){ echo "checked";}?>>I Agree with Terms &amp; Conditions.</label>
						    <p class="addwish" id="termsp"><?php if(isset($error['terms'])){echo $error['terms'];} ?></p>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="pull-right">
							<button type="submit" name="regsubmit" id="regsubmit" class="btn btn-default btnr2">Submit</button>
							<button type="button" class="btn btn-default btnd" onclick="clr();">Clear</button>
						</div>
					</div>
				</div>
			</section>
		</form>

		<?php require 'footer.php'; ?>

	 	<script src="js/valid.js"></script>

	</body>
</html>