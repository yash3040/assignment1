<?php

	function NewUserMail($email, $fname, $lname)
	{
		$to = $email;
		$subject = "Welcome to eShop";
		$txt = "Hello, ".$fname." ".$lname."\nWelcome to eShop. The world's biggest online store for clothing and accessories";
		$headers = "From: no-reply@eshop.com" . "\r\n";

		if(mail($to,$subject,$txt,$headers)){
			return true;
		}
		else{
			return false;
		}
	}

	function ContactMail($admin_mail, $name, $mail, $sub, $msg)
	{
		$to = $admin_mail;
		$subject = $sub;
		$message = "<html><body><p>Hi I am ".$name.",</p><p>".$msg."</p></body></html>";
		$message = wordwrap($message,70);
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= "From: $mail" . "\r\n";

		if(mail($to,$subject,$message,$headers)){
			return true;
		}
		else{
			return false;
		}
	}

	function NewsMail($user_mail)
	{	
		require 'database_conn.php';
		$get_admin = "SELECT email FROM user WHERE username = 'eshop__admin'";
		$result=mysqli_query($conn,$get_admin);
		$row=mysqli_fetch_array($result);
		$admin = $row["email"];

		$to = $user_mail;
		$subject = "New Subscriber";
		$message = "Thank You for Subscription.";
		$headers = "From: no-reply@eShop.com" . "\r\n";

		mail($to,$subject,$message,$headers);

		$to1 = $admin;
		$subject1 = "New Subscriber";
		$message1 = "";
		$headers1 = "From: $user_mail" . "\r\n";

		mail($to1,$subject1,$message1,$headers1);
	}

	function TrendingItems()
	{
		require 'database_conn.php';
		$sql = "SELECT item.id, item_image_url, name, price FROM item INNER JOIN item_images ON item.id = item_images.item_id WHERE is_trending = '1'ORDER BY item.id ASC LIMIT 8;";
		$result = mysqli_query($conn,$sql);
		$total = mysqli_num_rows($result) / 4;		
		$tempMod = ($total - (int)$total) * 4;
			
		if (mysqli_num_rows($result) < 5) {
			if ($tempMod == 0) {
				echo '<section class="row">';
				for ($i=0; $i < 4 ; $i++) { 
					$row = mysqli_fetch_object($result);
						echo '  <section class="col-sm-3">
									<div class="thumbnail">
									    <a>
									    <div class="imgcont"> 	
									   	 <img class="imghvr img-responsive" src="images/'.$row->item_image_url.'" alt="product'.$row->id.'">								   	
									   	 <div class="hvrbut">
											<a href="product_detail" class="but btn btn-default">ADD TO CART</a>
										 </div>
										</div>
									     <div class="caption">
									     	<p class="text3">'.$row->name.'</p>
										 	<p class="text4">$'.$row->price.'</p>									 	
									     </div>
									    </a>
									</div>
								</section>';		
				}
				echo '</section>';
			}
			else{
				echo '<section class="row">';
				for ($i=0; $i < $tempMod; $i++) { 
					$row = mysqli_fetch_object($result);
						echo '  <section class="col-sm-3">
									<div class="thumbnail">
									    <a>
									    <div class="imgcont"> 	
									   	 <img class="imghvr img-responsive" src="images/'.$row->item_image_url.'" alt="product'.$row->id.'">								   	
									   	 <div class="hvrbut">
											<a href="product_detail" class="but btn btn-default">ADD TO CART</a>
										 </div>
										</div>
									     <div class="caption">
									     	<p class="text3">'.$row->name.'</p>
										 	<p class="text4">$'.$row->price.'</p>									 	
									     </div>
									    </a>
									</div>
								</section>';		
				}
				echo '</section>';
			}	
		}
		else{
			for ($i=0; $i < $total--; $i++) { 
				echo '<section class="row">';
				for ($j=0; $j < 4 ; $j++) { 
					$row = mysqli_fetch_object($result);
						echo '  <section class="col-sm-3">
									<div class="thumbnail">
									    <a>
									    <div class="imgcont"> 	
									   	 <img class="imghvr img-responsive" src="images/'.$row->item_image_url.'" alt="product'.$row->id.'">								   	
									   	 <div class="hvrbut">
											<a href="product_detail" class="but btn btn-default">ADD TO CART</a>
										 </div>
										</div>
									     <div class="caption">
									     	<p class="text3">'.$row->name.'</p>
										 	<p class="text4">$'.$row->price.'</p>									 	
									     </div>
									    </a>
									</div>
								</section>';		
				}
				echo '</section>';
			}
			if ($tempMod == 0) {
				echo '<section class="row">';
				for ($i=0; $i < 4 ; $i++) { 
					$row = mysqli_fetch_object($result);
						echo '  <section class="col-sm-3">
									<div class="thumbnail">
									    <a>
									    <div class="imgcont"> 	
									   	 <img class="imghvr img-responsive" src="images/'.$row->item_image_url.'" alt="product'.$row->id.'">								   	
									   	 <div class="hvrbut">
											<a href="product_detail" class="but btn btn-default">ADD TO CART</a>
										 </div>
										</div>
									     <div class="caption">
									     	<p class="text3">'.$row->name.'</p>
										 	<p class="text4">$'.$row->price.'</p>									 	
									     </div>
									    </a>
									</div>
								</section>';		
				}
				echo '</section>';
			}
			else{
				echo '<section class="row">';
				for ($i=0; $i < $tempMod; $i++) { 
					$row = mysqli_fetch_object($result);
						echo '  <section class="col-sm-3">
									<div class="thumbnail">
									    <a>
									    <div class="imgcont"> 	
									   	 <img class="imghvr img-responsive" src="images/'.$row->item_image_url.'" alt="product'.$row->id.'">								   	
									   	 <div class="hvrbut">
											<a href="product_detail" class="but btn btn-default">ADD TO CART</a>
										 </div>
										</div>
									     <div class="caption">
									     	<p class="text3">'.$row->name.'</p>
										 	<p class="text4">$'.$row->price.'</p>									 	
									     </div>
									    </a>
									</div>
								</section>';		
				}
				echo '</section>';
			}	
		}
	}
?>