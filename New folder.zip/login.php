<?php require 'database_conn.php';
	session_start();
	if (isset($_POST['logsubmit'])) {
		if (isset($_POST['inputLogUserName'])) {
	    	$logusername = $_POST['inputLogUserName'];
			if (isset($_POST['inputLogPassword'])) {
				$logpassword = MD5($_POST['inputLogPassword']);

				$query = $conn->query("SELECT * FROM user WHERE username = '$logusername' AND password = '$logpassword'");
				$rows = $query->num_rows;
				if ($rows == 1) {
					$row = mysqli_fetch_object($query);
					$_SESSION['uname'] = $row->username;
					$_SESSION['fname'] = $row->firstname;
					$_SESSION['lname'] = $row->lastname;
					$_SESSION['id'] = $row->id;
					$_SESSION['logged']=true; 
					header("location: index.php");
				} 
				else {
					echo "<script>alert('Username or Password is Invalid. Please Retry');window.location.href='index.php'</script>";
				}
			}
		}
	}
	$conn->close(); 
?>