<!DOCTYPE html>
<html lang="en">
	<head>
	    <title>Product Details</title>
	    <link rel="shortcut icon" href="images/favicon.ico">
	    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
	 	<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/media.css">
	</head>
	<body>
		
		<?php require 'header.php'; ?>
		
		<section class="container-fluid banpad">
			<section class="row">
				<img src="images/inner-banner.jpg" class="abtban img-responsive">		
			</section>
		</section>	

		<section class="container">						
			<h2 class="crt">T-Shirts</h2>			
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb brdcrmb">
			    <li class="breadcrumb-item"><a href="index">Home</a></li>
			    <li class="breadcrumb-item"><a href="#">Men</a></li>
			    <li class="breadcrumb-item"><a href="#">T-Shirts</a></li>
			    <li class="breadcrumb-item active" aria-current="page">U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men.</li>
			  </ol>
			</nav>
		</section>	

		<section class="container">
			<div class="alert alert-success alert-dismissible alrtsuc collapse" id="alrt" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<svg height="14" width="20">
				  	<image height="14" width="15"  href="images/success.svg" />
				</svg>
				  U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men was added to your shopping cart.
			</div>
			<section class="row">
				<section class="col-sm-5">
					<img src="images/new-thumb-01-big.jpg" id="largeImage" class="img-responsive">
				    <div class="row thumb">
				        <div class="col-sm-12">
				          <div class="row">

				         	<div class="col-xs-1 leftarr">
				          		<a class="left" href="#myCarousel" data-slide="prev"><img src="images/im.png" class="leftcurosal"></a>
				       		</div>

				        	<div class="col-xs-10" id="thumbs">
				         		<div class="carousel detail slide" id="myCarousel">
								  <div class="carousel-inner">

								    <div class="item active">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-01-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-02-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-03-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-04-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-05-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-06-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-07-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								    <div class="item">
								      <div class="col-xs-3">
								      	<a><img src="images/new-thumb-08-big.jpg" class="img-responsive"></a>
								      </div>
								    </div>

								  </div> 								  
								</div>
							</div>
							
							<div class="col-xs-1 rightarr">
							  <a class="right" href="#myCarousel" data-slide="next"><img src="images/im.png" class="rightcuosal"></a>
							</div>

						  </div>
						</div>
					</div>
				</section>
				
				<section class="col-sm-7">
					
					<p class="dtlpghd" id="prdtnm">U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men.</p>

					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

					<p>SKU: 
						<span class="mag209">mag209_prod1</span>
					</p>

					<p>Availibility: 
						<span class="badge stck">In Stock</span> 
						<span class="badge notstck">Not Available</span>
					</p>

					<p class="text4big">&dollar;120.00</p>

					<form>
						<div class="form-group">
					      <label for="inputSize"><span class="error">*</span>Size</label>
					      <span class="error pull-right">* Required Fields</span>
					      <select id="inputSize" class="form-control">
					        <option selected>--- Please Select ---</option>
					        <option>...</option>
					      </select>
					    </div>
					</form>

					<form class="form-inline">
						<div class="form-group">
						    <label for="inputqty">Qty</label>		 
						   		<select id="inputqty" class="form-control" onchange="total()">
					       		 <option selected>1</option>
					       		 <option>2</option>
					       		 <option>3</option>
					       		 <option>4</option>
					       		 <option>5</option>
					        	</select>
					    </div>
					    <button type="button" class="btn btn-default addcrt" onclick="cnfrm()">
						  <div class="cartsprt inline" aria-hidden="true"></div> <div class="inline">ADD TO CART</div>
						</button>
						<p id="rslt"></p>
					</form><br>

					<p id="ttl" class="text4big">Total: &dollar;120.00</p>

					<a href="#alrt" class="addwish" data-toggle="collapse">Add to Wishlist</a>

					<div>

					  <!-- Nav tabs -->
					  <ul class="nav nav-pills" role="tablist">
					    <li role="presentation" class="active"><a href="#delivery" aria-controls="delivery" role="tab" data-toggle="tab">Delivery</a></li>
					    <li role="presentation"><a href="#shipping" aria-controls="shipping" role="tab" data-toggle="tab">Shipping</a></li>
					    <li role="presentation"><a href="#sizeguide" aria-controls="sizeguide" role="tab" data-toggle="tab">Sizeguide</a></li>
					  </ul>

					  <!-- Tab panes -->
					  <div class="tab-content">
					    <div role="tabpanel" class="tab-pane in active" id="delivery">We offer the following delivery options for 24 hours over the world. Deliveries are not made on Saturdays, Sundays or on public holidays. A specific time slot cannot be specified with any of our delivery options. Please refer to the Terms and Conditions of sale.</div>
					    <div role="tabpanel" class="tab-pane" id="shipping">Shipping</div>
					    <div role="tabpanel" class="tab-pane" id="sizeguide">
					    	<div class="table-responsive">          
							  <table class="table tbldtl">
							    <thead>
							      <tr>
							        <th>Size</th>
							        <th>S</th>
							        <th>M</th>
							        <th>L</th>
							        <th>XL</th>
							      </tr>
							    </thead>
							    <tbody>
							      <tr>
							        <td>Men</td>
							        <td>7-10</td>
							        <td>10-13</td>
							        <td>13-15</td>
							        <td>15-17</td>
							      </tr>
							      <tr>
							        <td>Women</td>
							        <td>7-9</td>
							        <td>10-12</td>
							        <td>13-14</td>
							        <td>15-16</td>
							      </tr>
							    </tbody>
							  </table>
							</div>
					    </div>
					  </div>

					</div>

				</section>
			</section><br><br>

			<div>

			  <!-- Nav tabs -->
			  <ul class="nav nav-pills" role="tablist">
			    <li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Product Description</a></li>
			    <li role="presentation"><a href="#review" aria-controls="review" role="tab" data-toggle="tab">Product's Review</a></li>
			    <li role="presentation"><a href="#cms" aria-controls="cms" role="tab" data-toggle="tab">CMS Tab</a></li>
			  </ul>

			  <!-- Tab panes -->
			  <div class="tab-content">
			    <div role="tabpanel" class="tab-pane in active" id="description">
				    <label>Sample Lorem Ipsum Text</label>
				    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum..
				    </p>	
				    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum..
				    </p>
			    </div>
			    <div role="tabpanel" class="tab-pane" id="review">
			    	<div class="rev"><a href="#wrtrev" data-toggle="collapse">Write a review</a></div>
			    	<div class="collapse" id="wrtrev">
			    		<div class="starRating">
                            <input id="rating5" type="radio" name="rating" value="5">
                            <label for="rating5">5</label>
                            <input id="rating4" type="radio" name="rating" value="4">
                            <label for="rating4">4</label>
                            <input id="rating3" type="radio" name="rating" value="3">
                            <label for="rating3">3</label>
                            <input id="rating2" type="radio" name="rating" value="2">
                            <label for="rating2">2</label>
                            <input id="rating1" type="radio" name="rating" value="1">
                            <label for="rating1">1</label>
         			    </div>
			    		<textarea class="form-control" id="inputreview" rows="5" placeholder="Write a review."></textarea><br>
			    		<button type="submit" class="btn btn-default btnr2">Submit</button>
			    	</div><br>
			    	<label>Yash, 20/01/2018 writes</label>
				    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum..
				    </p>
			    </div>
			    <div role="tabpanel" class="tab-pane" id="cms">CMS Tab</div>
			  </div>

			</div>

		</section><br><br>

		<?php require 'footer.php'; ?>

		<script type="text/javascript" src="js/valid.js"></script>
		<script>
			
			$(document).ready(function(){			

				if (document.documentElement.clientWidth > 767) {
					$('.detail .item').each(function(){
					  var next = $(this).next();
					  if (!next.length) {
					    next = $(this).siblings(':first');
					  }
					  next.children(':first-child').clone().appendTo($(this));
					  
					  for (var i=0;i<2;i++) {
					    next=next.next();
					    if (!next.length) {
					      next = $(this).siblings(':first');
					    }
					    
					    next.children(':first-child').clone().appendTo($(this));
					  }
					});

					$('#thumbs img').click(function(){
					    $('#largeImage').attr('src',$(this).attr('src'));
					    $('#description').html($(this).attr('alt'));
					});
				}else {
					$(".item div").toggleClass("col-xs-3");
					$(".item div").toggleClass("col-xs-4");
					$('.detail .item').each(function(){
					  var next = $(this).next();
					  if (!next.length) {
					    next = $(this).siblings(':first');
					  }
					  next.children(':first-child').clone().appendTo($(this));
					  
					  for (var i=0;i<1;i++) {
					    next=next.next();
					    if (!next.length) {
					      next = $(this).siblings(':first');
					    }
					    
					    next.children(':first-child').clone().appendTo($(this));
					  }
					});
					$('#thumbs img').click(function(){
					    $('#largeImage').attr('src',$(this).attr('src'));
					    $('#description').html($(this).attr('alt'));
					});
				}

				$(window).resize(function() {

				window.location=window.location;

				});

			})	

			

				function total(){
					var x = document.getElementById("inputqty").selectedIndex;
			  	    var y = document.getElementById("inputqty").options;
				    var txt = y[x].text;
				    var ttl = 120*txt;
				    document.getElementById("ttl").innerHTML = "Total: &dollar;"+ ttl +".00";
				} 

				function cnfrm() {
				    
				    var x = document.getElementById("inputqty").selectedIndex;
			  	    var y = document.getElementById("inputqty").options;
				    var txt = y[x].text;
				    var ttl = 120*txt;
				    var txt2;
				    if (confirm("Are you sure you want to purchase this product? \nYour total bill amount is " + ttl)) {
				        txt2 = "Added to Cart";
				    } else {
				        txt2 = "Cancelled";
				    }
				    document.getElementById("rslt").innerHTML = txt2;
				}
		</script>

	</body>
</html>