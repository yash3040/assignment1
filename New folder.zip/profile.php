<?php require 'check_session.php' ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	    <title>Profile</title>
	    <link rel="shortcut icon" href="images/favicon.ico">
	    <meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script>
	 	<script src="js/bootstrap.min.js"></script>
		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/media.css">
	</head>
	<body>
		<?php require 'header.php';?>

		<section class="container-fluid banpad">
			<section class="row">
				<img src="images/inner-banner.jpg" class="abtban img-responsive">
			</section>
		</section>	

		<section class="container">						
			<h2 class="crt">Update Profile</h2>			
			<nav aria-label="breadcrumb">
			  <ol class="breadcrumb brdcrmb">
			    <li class="breadcrumb-item"><a href="index">Home</a></li>
			    <li class="breadcrumb-item active" aria-current="page">Profile</li>
			  </ol>
			</nav>
		</section>	

		<form id="prflform" action="try_catch" method="post" onsubmit="return !!(valid() & prfl());">
			<?php 
			  $id = $_SESSION['id'];
			  $sql = "SELECT * FROM user WHERE id = '$id'";
			  $result=$conn->query($sql);
			  $row=mysqli_fetch_object($result);
			?>
			<?php
                if (isset($_COOKIE['error'])) {
                    $error = $_COOKIE['error'];
                    $error = json_decode($error, TRUE);                
                }
            ?>

			<section class="container bordbot">			
				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputUserName">Username</label>
						    <input type="text" class="form-control" id="inputUserName" name="inputUserName" value="<?php echo $_SESSION['uname'];?>" title="minimum 8 charcters and alphanumeric and - _ allowed" readonly>
						    <p id="unamep" class="addwish"><?php if(isset($error['username'])){echo $error['username'];} ?></p>
						</div>
					</div>

					<div class="col-sm-6">
						<b>Gender</b></br>
					    <label class="radio-inline">
					      <input type="radio" name="gender" id="male" value="Male" <?php if($row->gender == 'Male'){echo 'checked';}?> >Male
					    </label>
					    <label class="radio-inline">
					      <input type="radio" name="gender" id="female" value="Female" <?php if($row->gender == 'Female'){echo 'checked';}?> >Female
					    </label>
					    <p class="addwish" id="gndrp"><?php if(isset($error['gender'])){echo $error['gender'];} ?></p>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputPassword">Password</label>
						    <input type="password" class="form-control" id="inputPassword" name="inputPassword" value="<?php echo $row->password;?>" title="at least one number,special,lowercase character and 2 uppercase characters" readonly>
						    <p class="addwish" id="passp"><?php if(isset($error['password'])){echo $error['password'];} ?></p>
						</div>
					</div>
					
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputPassword2">Confirm Password</label>
						    <input type="password" class="form-control" id="inputPassword2" name="inputPassword2" value="<?php echo $row->password;?>" title="same as your password" readonly>
						    <p class="addwish" id="passp2"><?php if(isset($error['password2'])){echo $error['password2'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputEmail">Email</label>
						    <input type="email" class="form-control" id="inputEmail" name="inputEmail" value="<?php echo $row->email;?>" title="standard email">
						    <p class="addwish" id="mailp"><?php if(isset($error['email'])){echo $error['email'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputFname">First Name</label>
						    <input type="text" class="form-control" id="inputFname" name="inputFname" value="<?php echo $row->firstname;?>" title="Only alphabets">
						    <p class="addwish" id="fnamep"><?php if(isset($error['firstname'])){echo $error['firstname'];} ?></p>
						</div>
					</div>
					
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputMobNo">Mobile No.</label>
						    <input type="text" class="form-control" id="inputMobNo" name="inputMobNo" value="<?php echo $row->mobile_number;?>" title="US format, with or without dashes">
						    <p class="addwish" id="mobp"><?php if(isset($error['mobile'])){echo $error['mobile'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputLname">Last Name</label>
						    <input type="text" class="form-control" id="inputLname" name="inputLname" value="<?php echo $row->lastname;?>" title="Only alphabets">
						    <p class="addwish" id="lnamep"></p>
						</div>
					</div>
					
					<div class="col-sm-6">
					  	<div class="form-group">
						    <label for="inputPhone">Phone</label>
						    <input type="text" class="form-control" id="inputPhone" name="inputPhone" value="<?php echo $row->phone_number;?>" title="Only 10 digits">
						    <p class="addwish" id="phonep"><?php if(isset($error['phone'])){echo $error['phone'];} ?></p>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col-sm-12">
						<b>Interests</b>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="all" name="all" onclick="allcheck()">Select All</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="opt1" name="opt1" onclick="indicheck()">Option 1</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="opt2" name="opt2" onclick="indicheck()" checked>Option 2</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="opt3" name="opt3" onclick="indicheck()">Option 3</label>
					    </div>
					    <div class="checkbox">
					      <label><input type="checkbox" value="" id="optoth" name="optoth" onclick="indicheck()">Other
					      		 <input type="text" value="" id="checktxt" name="checktxt" readonly>
					      </label>
					      <p class="addwish" id="checkp"><?php if(isset($error['interest'])){echo $error['interest'];} ?></p>
					    </div>
					</div>
				</div>

				<?php
			    	$bill_id = $row->billing_add_id;
			    	$billsql = "SELECT street, city, state_id, country_id, state.name AS state, country.name AS country FROM user INNER JOIN address ON user.billing_add_id = address.id INNER JOIN state ON address.state_id = state.id INNER JOIN country ON state.country_id = country.id WHERE billing_add_id = '$bill_id'";
					$billresult = mysqli_query($conn,$billsql);
					$billrow=mysqli_fetch_object($billresult);	
			    ?>
				
				<section class="row">
					<div class="col-sm-6">
						<button class="btn btn-default btnd" type="button" data-toggle="collapse" data-target="#billcollapse" aria-expanded="<?php if(isset($billrow->street)){echo 'true';}else{echo 'false';}?>" aria-controls="shipcollapse">
						  Edit Billing Address
						</button>
						<div class="collapse <?php if(isset($billrow->street)){echo 'in';}else{echo '';}?>" id="billcollapse" aria-expanded="<?php if(isset($billrow->street)){echo 'true';}else{echo 'false';}?>">
						  <div class="well">
						  	<div class="form-group">
							    <label for="inputStreet">Street</label>							    
							    <input type="text" class="form-control" id="inputStreet" name="inputStreet" value="<?php echo $billrow->street;?>" placeholder="Please enter your Street">
							    <p class="addwish" id="strtp"><?php if(isset($error['street1'])){echo $error['street1'];} ?></p>
							</div>
						 	<div class="form-group">
							    <label for="inputCity">City</label>
							    <input type="text" class="form-control" id="inputCity" name="inputCity" value="<?php echo $billrow->city;?>" placeholder="Please enter your City">
							    <p class="addwish" id="ctyp"><?php if(isset($error['city1'])){echo $error['city1'];} ?></p>
						  	</div>
						  	<div class="form-group">
						      <label for="inputCountry">Country</label>
						      <select id="inputCountry" name="inputCountry" class="form-control">
						      	<?php 
				                  	$sql2="SELECT * FROM country";
				                    $result2=$conn->query($sql2);
			        				echo '<option value="">Select Country</option>';
				                    while($row2=mysqli_fetch_object($result2)){
				                
						                if(isset($billrow->country) && $row2->id == $billrow->country_id){
							      			echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
							      		}
							      		else{				                
							               	echo "<option value='".$row2->id."'>".$row2->name."</option>";
							            }
					                }
				                ?>		
						      </select>
						      <p class="addwish" id="cntryp"><?php if(isset($error['country1'])){echo $error['country1'];} ?></p>
						    </div>
						    <div class="form-group">
						      <label for="inputState">State</label>
						      <select id="inputState" name="inputState" class="form-control">
						      	
						      </select>
						      <p class="addwish" id="sttp"><?php if(isset($error['state1'])){echo $error['state1'];} ?></p>
						    </div>
						  </div>
						</div>
					</div>
					
					<?php
				    	$ship_id = $row->shipping_add_id;
				    	$shipsql = "SELECT street, city, state_id, country_id, state.name AS state, country.name AS country FROM user INNER JOIN address ON user.shipping_add_id = address.id INNER JOIN state ON address.state_id = state.id INNER JOIN country ON state.country_id = country.id WHERE shipping_add_id = '$ship_id'";
						$shipresult = mysqli_query($conn,$shipsql);
						$shiprow=mysqli_fetch_object($shipresult);	
				    ?>

					<div class="col-sm-6">
						<button class="btn btn-default btnd" type="button" data-toggle="collapse" data-target="#shipcollapse" aria-expanded="<?php if(isset($shiprow->street)){echo 'true';}else{echo 'false';}?>" aria-controls="billcollapse">
						  Edit Shipping Address
						</button>
						<label class="chekbill"><input type="checkbox" id="sameadd" name="sameadd" onclick="cpyadd()" <?php if(isset($billrow->street) && $billrow->street == $shiprow->street && $billrow->city == $shiprow->city){echo "checked";}else{echo "";}?>>Same as Billing Address</label>
						<div class="collapse <?php if(isset($shiprow->street)){echo 'in';}else{echo '';}?>" id="shipcollapse" aria-expanded="<?php if(isset($shiprow->street)){echo 'true';}else{echo 'false';}?>">
						  <div class="well">
						  	<div class="form-group">
							    <label for="inputStreet2">Street</label>
							    <input type="text" class="form-control" id="inputStreet2" name="inputStreet2" value="<?php echo $shiprow->street;?>" placeholder="Please enter your Street" <?php if(isset($billrow->street) && $billrow->street == $shiprow->street && $billrow->city == $shiprow->city){echo "readonly";}else{echo "";}?>>
							    <p class="addwish" id="strt2p"><?php if(isset($error['street2'])){echo $error['street2'];} ?></p>
							</div>
						 	<div class="form-group">
							    <label for="inputCity2">City</label>
							    <input type="text" class="form-control" id="inputCity2" name="inputCity2" value="<?php echo $shiprow->city;?>" placeholder="Please enter your City" <?php if(isset($billrow->street) && $billrow->street == $shiprow->street && $billrow->city == $shiprow->city){echo "readonly";}else{echo "";}?>>
							    <p class="addwish" id="cty2p"><?php if(isset($error['city2'])){echo $error['city2'];} ?></p>
						  	</div>
							<div class="form-group">
						      <label for="inputCountry2">Country</label>
						     <select id="inputCountry2" name="inputCountry2" class="form-control" <?php if(isset($billrow->street) && $billrow->street == $shiprow->street && $billrow->city == $shiprow->city){echo "disabled";}else{echo "";}?>>
						      	<?php 
				                  	$sql2="SELECT * FROM country";
				                    $result2=$conn->query($sql2);
			        				echo '<option value="">Select Country</option>';
				                    while($row2=mysqli_fetch_object($result2)){
				                
						               if(isset($shiprow->country) && $row2->id == $shiprow->country_id){
							      			echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
							      		}							      	
							      		else{				                
							                echo "<option value='".$row2->id."'>".$row2->name."</option>";
							            }
					                }
				                ?>
						      </select>
						      <p class="addwish" id="cntry2p"><?php if(isset($error['country2'])){echo $error['country2'];} ?></p>
						    </div>
						    <div class="form-group">
						      <label for="inputState2">State</label>
						      <select id="inputState2" name="inputState2" class="form-control" <?php if(isset($billrow->street) && $billrow->street == $shiprow->street && $billrow->city == $shiprow->city){echo "disabled";}else{echo "";}?>></select>
						      <p class="addwish" id="stt2p"><?php if(isset($error['state2'])){echo $error['state2'];} ?></p>
						    </div>
						  </div>
						</div>					
					</div>
				</section>			

			</section>	

			<section class="container toppad">
				<section class="row botpad">
					<div class="col-sm-12">
						<div class="pull-right">
							<button type="submit" id="update" name="update" class="btn btn-default btnr2">Update</button>		
						</div>
					</div>
				</section>
			</section>

		</form>	

		<?php require 'footer.php'; ?>	
	
		<script src="js/valid.js"></script>

	</body>
</html>