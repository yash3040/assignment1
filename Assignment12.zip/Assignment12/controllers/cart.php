<?php

class cart extends BaseController {
    

    public function index() {
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();

        $this->load_view('header', $cat);    
        $this->load_view('user/cart');
        
        $this->load_model("FooterModel");

        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
    }

    public function updateCart()
    {
        if(checkIfLogin()){
            $id = $_POST['id'];
            $qty = $_POST['qty'];
            $size = $_POST['size'];
            $this->load_model("CartModel");
            $result = $this->cartmodel->updateSubtotal($id, $qty, $size);
            if($result == true){
                echo 1;
            }
            else{
                echo "error";
            }
        }else{
            echo 3;
        } 
    }

    public function clear()
    {
        if (isset($_SESSION['item'])) {
            unset($_SESSION['item']);
            echo 1;
        }else{
            echo 2;
        }
    }
}
