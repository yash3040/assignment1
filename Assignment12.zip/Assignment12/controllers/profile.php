<?php

class Profile extends BaseController
{
	
	public function index()
	{	
		if(checkIfLogin()){
			$validationErrors = array();		

			$this->load_model("ProfileModel");	
			$data['user'] = $this->profilemodel->getUserDetails($_SESSION['id']);
			$data['address'] = $this->profilemodel->getUserAddress($_SESSION['id']);
			$data['country'] = $this->profilemodel->getCountry();
				
			if (isset($_POST['profile'])) {
				
				if($this->profilemodel->insert($_POST['profile'])) {

					$this->redirect('profile');
				
				} else {
					// insert fail due to some validation errors
					$validationErrors = $this->profilemodel->getErrors();	
					$data['validationErrors'] = $validationErrors; 
				}
			}			
			
	        $this->load_model("HeaderModel");
	        $cat['cat'] = $this->headermodel->getParCategories();
	        
	        $this->load_view('header', $cat);  
			$this->load_view('user/profile', $data);
			
			$this->load_model("FooterModel");

	        if (isset($_POST['news_submit'])) {
	            $mail = $_POST['inputNewsEmail'];
	            $flag = $this->footermodel->NewsSubscriber($mail);          
	            $this->load_view('footer', $flag);
	        }else{              
	            $this->load_view('footer');
	        }  
	    }else{
	    	echo "<script>alert('Please Login First');window.location.href='".SITE_URL."'</script>"; 
	    }    
	}

	public function state1(){		
		$this->load_model("ProfileModel");	
		$this->profilemodel->getState1();
	}

	public function state2(){		
		$this->load_model("ProfileModel");	
		$this->profilemodel->getState2();
	}
}
