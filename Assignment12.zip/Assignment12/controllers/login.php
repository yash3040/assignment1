<?php

class Login extends BaseController {

    
    public function index() {

        $this->load_model("LoginModel");

        if ($this->loginmodel->authenticate($_POST['inputLogUserName'], $_POST['inputLogPassword'])) {
            
            header("location: ".SITE_URL);
            } else {

                echo "<script>alert('Username or Password is Invalid. Please Retry');window.location.href='".SITE_URL."'</script>";
            }
        
    }

}
