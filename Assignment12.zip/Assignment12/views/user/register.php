<?php
$assets_url = SITE_URL . '/public/';
?>
<!----content start------>
<section class="container-fluid banpad">
    <section class="row">
        <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">   
    </section>
</section>  

<section class="container">                     
    <h2 class="crt">Register</h2>           
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb brdcrmb">
        <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Register</li>
      </ol>
    </nav>
</section>

<form id="form1" action="" method="post" onsubmit="return !!(valid() & termfunc())">  

    <section class="container bordbot">         
        <h2 class="regh2">New Customers</h2>
        <p>By creating an account with our store, you will be able to move to the checkout process faster, store multiple shipping addresses, view and track your orders in your account and more.</p>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputUserName">Username</label>
                    <input type="text" class="form-control" id="inputUserName" name="register[inputUserName]" placeholder="Please enter your username" title="minimum 8 charcters and alphanumeric and - _ allowed" value="<?php echo (isset($_POST['register']['inputUserName'])) ? $_POST['register']['inputUserName'] : ''; ?>">
                    <p id="unamep" class="addwish"><?php echo (isset($validationErrors['username'])) ? $validationErrors['username'] : ''; ?></p>
                </div>
            </div>

            <div class="col-sm-6">
                <b>Gender</b></br>
                <label class="radio-inline">
                  <input type="radio" name="register[gender]" id="male" value="Male" checked>Male
                </label>
                <label class="radio-inline">
                  <input type="radio" name="register[gender]" id="female" value="Female">Female
                </label>
                <p class="addwish" id="gndrp"><?php echo (isset($validationErrors['gender'])) ? $validationErrors['gender'] : ''; ?></p>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputPassword">Password</label>
                    <input type="password" class="form-control" id="inputPassword" name="register[inputPassword]" placeholder="Please enter your password" title="at least one number,special,lowercase character and 2 uppercase characters" value="<?php echo (isset($_POST['register']['inputPassword'])) ? $_POST['register']['inputPassword'] : ''; ?>">
                    <p class="addwish" id="passp"><?php echo (isset($validationErrors['password'])) ? $validationErrors['password'] : ''; ?></p>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputPassword2">Confirm Password</label>
                    <input type="password" class="form-control" id="inputPassword2" name="register[inputPassword2]" placeholder="Please confirm yopur password" title="same as your password" value="<?php echo (isset($_POST['register']['inputPassword2'])) ? $_POST['register']['inputPassword2'] : ''; ?>">
                    <p class="addwish" id="passp2"><?php echo (isset($validationErrors['password2'])) ? $validationErrors['password2'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputEmail">Email</label>
                    <input type="email" class="form-control" id="inputEmail" name="register[inputEmail]" placeholder="Please enter valid email" title="standard email" value="<?php echo (isset($_POST['register']['inputEmail'])) ? $_POST['register']['inputEmail'] : ''; ?>">
                    <p class="addwish" id="mailp"><?php echo (isset($validationErrors['email'])) ? $validationErrors['email'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputFname">First Name</label>
                    <input type="text" class="form-control" id="inputFname" name="register[inputFname]" placeholder="Please enter your first name" title="Only alphabets" value="<?php echo (isset($_POST['register']['inputFname'])) ? $_POST['register']['inputFname'] : ''; ?>">
                    <p class="addwish" id="fnamep"><?php echo (isset($validationErrors['firstname'])) ? $validationErrors['firstname'] : ''; ?></p>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputMobNo">Mobile No.</label>
                    <input type="text" class="form-control" id="inputMobNo" name="register[inputMobNo]" placeholder="Please enter your mobile no." title="US format, with or without dashes" value="<?php echo (isset($_POST['register']['inputMobNo'])) ? $_POST['register']['inputMobNo'] : ''; ?>">
                    <p class="addwish" id="mobp"><?php echo (isset($validationErrors['mobileno'])) ? $validationErrors['mobileno'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputLname">Last Name</label>
                    <input type="text" class="form-control" id="inputLname" name="register[inputLname]" placeholder="Please enter your last name"" title="Only alphabets" value="<?php echo (isset($_POST['register']['inputLname'])) ? $_POST['register']['inputLname'] : ''; ?>">
                    <p class="addwish" id="lnamep"></p>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputPhone">Phone</label>
                    <input type="text" class="form-control" id="inputPhone" name="register[inputPhone]" placeholder="Please enter your phone" title="Only 10 digits" value="<?php echo (isset($_POST['register']['inputPhone'])) ? $_POST['register']['inputPhone'] : ''; ?>">
                    <p class="addwish" id="phonep"><?php echo (isset($validationErrors['phone'])) ? $validationErrors['phone'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <b>Interests</b>
                <div class="checkbox">
                  <label><input type="checkbox" value="" id="all" name="all" <?php if(isset($validationErrors['inputAllVal'])){ echo "checked";}?> onclick="allcheck()">Select All</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="" id="opt1" name="opt1" <?php if(isset($validationErrors['inputOneVal'])){ echo "checked";}?> onclick="indicheck()">Option 1</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="" id="opt2" name="opt2" <?php if(isset($validationErrors['inputTwoVal'])){ echo "checked";}?> onclick="indicheck()">Option 2</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="" id="opt3" name="opt3" <?php if(isset($validationErrors['inputThreeVal'])){ echo "checked";}?> onclick="indicheck()">Option 3</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="" id="optoth" name="optoth" <?php if(isset($validationErrors['inputOtherVal'])){ echo "checked";}?> onclick="indicheck()">Other
                         <input type="text" value="" id="checktxt" name="register[checktxt]" value="<?php echo (isset($_POST['register']['checktxt'])) ? $_POST['register']['checktxt'] : ''; ?>" readonly>
                  </label>
                  <p class="addwish" id="checkp"><?php if(isset($validationErrors['interest'])){echo $validationErrors['interest'];} ?></p>
                </div>
            </div>
        </div>          

    </section>  

    <section class="container toppad">
        <div class="row botpad">
            <div class="col-sm-6">
                <div class="checkbox">
                    <label><input type="checkbox" value="" id="term" name="register[is_agree]" <?php echo (isset($_POST['register']['is_agree']) && !empty($_POST['register']['is_agree'])) ? "checked" : ''; ?>>I Agree with Terms &amp; Conditions.</label>
                    <p class="addwish" id="termsp"><?php echo (isset($validationErrors['is_agree'])) ? $validationErrors['is_agree'] : ''; ?></p>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="pull-right">
                    <button type="submit" name="regsubmit" id="regsubmit" class="btn btn-default btnr2">Submit</button>
                    <button type="button" class="btn btn-default btnd" onclick="clr();">Clear</button>
                </div>
            </div>
        </div>
    </section>
</form>
<!----content end------>