<?php
$assets_url = SITE_URL . '/public/';
?>
<!----content start------>
<section class="container-fluid banpad">
    <section class="row">
        <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">   
    </section>
</section>  

<section class="container">                     
    <h2 class="crt">Contact Us</h2>         
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb brdcrmb">
        <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
      </ol>
    </nav>
</section>  

<section class="container">
    <section class="row">
        <section class="col-sm-9">

            <form id="con_form" action="" method="post" onsubmit="return contactvalid()">

                <section class="row">
                    <section class="col-sm-6">
                        <div class="form-group">
                            <label for="inputConName">Name</label>
                            <input type="text" class="form-control" id="inputConName" name="contact[inputConName]" placeholder="Please enter your name" value="<?php echo (isset($_POST['contact']['inputConName'])) ? $_POST['contact']['inputConName'] : ''; ?>">
                            <p class="addwish" id="namep"><?php echo (isset($validationErrors['name'])) ? $validationErrors['name'] : ''; ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputConEmail">Email</label>
                            <input type="email" class="form-control" id="inputConEmail" name="contact[inputConEmail]" placeholder="Please enter valid email" value="<?php echo (isset($_POST['contact']['inputConEmail'])) ? $_POST['contact']['inputConEmail'] : ''; ?>">
                            <p class="addwish" id="conmailp"><?php echo (isset($validationErrors['email'])) ? $validationErrors['email'] : ''; ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputSubject">Subject</label>
                            <input type="text" class="form-control" id="inputSubject" name="contact[inputSubject]" placeholder="Please enter subject" value="<?php echo (isset($_POST['contact']['inputSubject'])) ? $_POST['contact']['inputSubject'] : ''; ?>">
                            <p class="addwish" id="subp"><?php echo (isset($validationErrors['subject'])) ? $validationErrors['subject'] : ''; ?></p>
                        </div>
                    </section>
                    <section class="col-sm-6">                  
                        <div class="form-group">
                            <label for="inputMessage">Message</label>
                            <textarea class="form-control" id="inputMessage" name="contact[inputMessage]" rows="9" placeholder="Your message here"><?php echo (isset($_POST['contact']['inputMessage'])) ? $_POST['contact']['inputMessage'] : ''; ?></textarea>
                            <p class="addwish" id="msgp"><?php echo (isset($validationErrors['message'])) ? $validationErrors['message'] : ''; ?></p>
                        </div>
                    </section>
                </section>

                <section class="row">
                    <section class="col-sm-12">
                        <button type="submit" id="cont_sub" name="cont_sub" class="btn btn-default btnr2 pull-right">Submit</button>
                    </section>
                </section></br></br>

            </form>

            <section class="row">
                <section class="col-sm-8">
                    <div class="embed-responsive embed-responsive-16by9">
                      <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14686.781365591463!2d72.500399!3d23.0349558!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xdc9d4dae36889fb9!2sTatvaSoft!5e0!3m2!1sen!2sin!4v1516258106980"></iframe>
                    </div>
                </section>
                <section class="col-sm-4">
                    <h3>Get in touch</h3>
                    <p class="add">TatvaSoft House, Rajpath Club Road, Near Shivalik Business Center, Opp. Golf Academy, Off S G Road, PRL Colony, Thaltej, Ahmedabad, Gujarat 380054</p>
                    <p>Phone:<span class="text4"> (03)555 55555</span></p>
                    <p>Email:<span class="text4"> info@tatvasoft.com</span></p>
                </section>
            </section>
            
        </section>

        <aside class="col-sm-3">                
            <figure>
                <img class="img-responsive" src="<?php echo $assets_url;?>images/promo1.jpg" alt="promo1">
            </figure>
                
            <figure>
                <img class="marg30 botpad img-responsive" src="<?php echo $assets_url;?>images/promo2.jpg" alt="promo2">
            </figure>               
        </aside>
    </section>
</section>  
<!----content end------>