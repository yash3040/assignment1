<?php
    $assets_url = ASSETS_URL;
?>
<section class="container-fluid">
    <section class="row topban">
        <div id="jssor_1">
            <div data-u="slides" class="jssordiv">
                <div data-p="225.00">
                    <img data-u="image" class="img-responsive" src="<?php echo $assets_url;?>/images/banner.jpg" />
                </div>
                <div data-p="225.00">
                    <img data-u="image" class="img-responsive" src="<?php echo $assets_url;?>/images/banner1.jpg" />
                </div>
                <div data-p="225.00">
                    <img data-u="image" class="img-responsive" src="<?php echo $assets_url;?>/images/banner2.jpg" />
                </div>
            </div>
            <!-- Arrow Navigator -->
            <div data-u="arrowleft" class="jssora051 arrleft" data-autocenter="2" data-scale="0.75" data-scale-left="0.75">
                <svg width="30" height="30">
                    <image width="30" height="30" href="<?php echo $assets_url;?>/images/pre-arrow.svg" />
                </svg>
            </div>
            <div data-u="arrowright" class="jssora051 arrrght" data-autocenter="2" data-scale="0.75" data-scale-right="0.75">
                <svg width="30" height="30">
                    <image width="30" height="30" href="<?php echo $assets_url;?>/images/next-arrow.svg" />
                </svg>
            </div>
        </div>
    </section>
</section>  

<section class="container background">
    <section class="row">
        <section class="col-sm-4">
            <div class="media">
              <div class="media-left">
                <a class="media-object sprite1" href=""></a> 
              </div>
              <div class="media-body">
                <h4 class="media-heading sevicetext">Free Delivery Worldwide</h4>
                <p>At vero eos et accusamus et iusto odio</p>
              </div>
            </div>
        </section>
        <section class="col-sm-4">
            <div class="media">
              <div class="media-left">
                <a class="media-object sprite2" href=""></a> 
              </div>
              <div class="media-body">
                <h4 class="media-heading sevicetext">Free Return For 90 Day</h4>
                <p>At vero eos et accusamus et iusto odio</p>
              </div>
            </div>          
        </section>
        <section class="col-sm-4">
            <div class="media">
              <div class="media-left">
                <a class="media-object sprite3" href=""></a> 
              </div>
              <div class="media-body">
                <h4 class="media-heading sevicetext">Discount on Order Gift</h4>
                <p>At vero eos et accusamus et iusto odio</p>
              </div>
            </div>              
        </section>
    </section>
</section>  
<section class="container background">  
    <section class="row">
        <section class="col-sm-12">
            <center><p class="text2">Trending Product</p></center>
                <?php
                  while($row = mysqli_fetch_object($result)){
                    echo '<section class="col-sm-3">
                            <div class="thumbnail itembox">
                              <div class="imgcont">   
                                <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                                 <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                                 <div class="hvrbut">
                                </a>
                                <button class="but btn btn-default" onclick="cnfrm('.$row->id.')">ADD TO CART</button>
                                <input type="hidden" id="inputSize'.$row->id.'" value="'.$row->value.'">
                                <input type="hidden" id="inputqty'.$row->id.'" value="1">
                                <input type="hidden" id="price'.$row->id.'" value="'.$row->price.'">
                               </div>
                              </div>
                              <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                               <div class="caption">
                                <p class="text3">'.$row->name.'</p>
                                <p class="text4">$'.$row->price.'</p>                   
                               </div>
                              </a>
                            </div>
                          </section>';  
                  }             
                ?>
            <div class="text-center"><button type="button" class="btn btn-default btnd">More Products</button></div></br></br>            
        </section>
    </section>              
</section>
<section class="container-fluid">
    <section class="row posrel">
        <img src="<?php echo $assets_url;?>/images/px.jpg" class="img-responsive padmarg0">   
        <p class="botban">
            <b>GET THE </b>LATEST<br> <b>WOMENS</b> FASHION<br>
            <button type="button" class="btn btn-default btnr1">Get Exclusive Collection For Women</button>
        </p>        
    </section>
</section>  

<section class="container testimonial">
    <center><p class="text2">Testimonial</p></center>
    <div class="owl-carousel owl-theme">
          <div class="item">
            <section class="row testrow">
            <section class="col-sm-2">  
                <div class="media">
                  <div class="media-left">
                    <a class="media-object" href="">
                        <img src="<?php echo $assets_url;?>/images/testimonial_3.jpg">
                    </a> 
                  </div>
                  <div class="media-body">
                    <h5 class="media-heading addwish">John Clay</h5>
                    <p>Cyclist</p>
                  </div>
                </div>      
            </section>
            <section class="col-sm-10">
                <p>&quot;Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.&quot;</p>
            </section>
          </div>
          <div class="item">
            <section class="row testrow">
            <section class="col-sm-2">  
                <div class="media">
                  <div class="media-left">
                    <a class="media-object" href="">
                        <img src="<?php echo $assets_url;?>/images/testimonial_3.jpg">
                    </a> 
                  </div>
                  <div class="media-body">
                    <h5 class="media-heading addwish">John Clay</h5>
                    <p>Cyclist</p>
                  </div>
                </div>      
            </section>
            <section class="col-sm-10">
                <p>&quot;Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus.&quot;</p>
            </section>
          </div>
          <div class="item">
            <section class="row testrow">
            <section class="col-sm-2">  
                <div class="media">
                  <div class="media-left">
                    <a class="media-object" href="">
                        <img src="<?php echo $assets_url;?>/images/testimonial_3.jpg">
                    </a> 
                  </div>
                  <div class="media-body">
                    <h5 class="media-heading addwish">John Clay</h5>
                    <p>Cyclist</p>
                  </div>
                </div>      
            </section>
            <section class="col-sm-10">
                <p>&quot;Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit.&quot;</p>
            </section>
          </div>
          <div class="item">
            <section class="row testrow">
            <section class="col-sm-2">  
                <div class="media">
                  <div class="media-left">
                    <a class="media-object" href="">
                        <img src="<?php echo $assets_url;?>/images/testimonial_3.jpg">
                    </a> 
                  </div>
                  <div class="media-body">
                    <h5 class="media-heading addwish">John Clay</h5>
                    <p>Cyclist</p>
                  </div>
                </div>      
            </section>
            <section class="col-sm-10">
                <p>&quot;Fusce convallis metus id felis luctus adipiscing. Pellentesque egestas, neque sit amet convallis pulvinar, justo nulla eleifend augue, ac auctor orci leo non est. Quisque id mi. Ut tincidunt tincidunt erat. Etiam feugiat lorem non metus.&quot;</p>
            </section>
            </section>
          </div>
      </div>
</section>