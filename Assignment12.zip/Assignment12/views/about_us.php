<?php
    $assets_url = ASSETS_URL;
?>
<section class="container-fluid banpad">
  <section class="row">
    <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">    
  </section>
</section>  

<section class="container">           
  <h2 class="crt">About Us</h2>     
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb brdcrmb">
      <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
      <li class="breadcrumb-item active" aria-current="page">About Us</li>
    </ol>
  </nav>
</section>  

<section class="container">
  <section class="row">
    <section class="col-sm-9">
      <article>
      <h1 class="h1cust">&lt;h1&gt; display style</h1>
      <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </p>  
      </article>  
      <section> 
        <h2 class="h2cust">&lt;h2&gt;  display style</h2>
        <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <section class="row">
          <section class="col-sm-6">
            <figure>
              <video controls>
                <source class="img-responsive" src="<?php echo $assets_url;?>images/video.mp4" type="video/mp4">
              </video> 
              <figcaption>      
                <h3 class="h3cust">&lt;h3&gt;  display style</h3>
                <ul>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                </ul>
              </figcaption>
            </figure> 
          </section>
          <section class="col-sm-6">
            <figure>
              <img class="img-responsive" src="<?php echo $assets_url;?>images/cms-img2.jpg" alt="cms-img2">
              <figcaption>
                <h3 class="h3cust">&lt;h3&gt;  display style</h3>
                <ul>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                </ul>
              </figcaption>
            </figure>
          </section>
        </section>
      </section>  
      <section> 
        <h2 class="h2cust">&lt;h2&gt;  display style</h2>
        <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <section class="row">
          <section class="col-sm-4">
            <figure>
              <img class="img-responsive" src="<?php echo $assets_url;?>images/cms-img3.jpg" alt="cms-img3">
              <figcaption>      
                <h4 class="h4cust">&lt;h4&gt;  display style</h4>
                <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>                   
              </figcaption>
            </figure> 
          </section>
          <section class="col-sm-4">
            <figure>
              <img class="img-responsive" src="<?php echo $assets_url;?>images/cms-img4.jpg" alt="cms-img4">
              <figcaption>
                <h4 class="h4cust">&lt;h4&gt;  display style</h4>
                <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
              </figcaption>
            </figure>
          </section>
          <section class="col-sm-4">
            <figure>
              <img class="img-responsive" src="<?php echo $assets_url;?>images/cms-img5.jpg" alt="cms-img5">
              <figcaption>
                <h4 class="h4cust">&lt;h4&gt;  display style</h4>
                <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</p>
              </figcaption>
            </figure>
          </section>
        </section>
      </section>
      <section> 
        <h2 class="h2cust">&lt;h2&gt;  display style</h2>
        <p class="pcust">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
        Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <section class="row">
          <section class="col-sm-6">
            <figure>
              <img class="img-responsive" src="<?php echo $assets_url;?>images/cms-img6.jpg" alt="cms-img6">
              <figcaption>      
                <h5 class="h5cust">&lt;h5&gt;  display style</h5>
                <ol type="i">
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                </ol>
              </figcaption>
            </figure> 
          </section>
          <section class="col-sm-6">
            <figure>
              <img class="img-responsive" src="<?php echo $assets_url;?>images/cms-img7.jpg" alt="cms-img7">
              <figcaption>      
                <h5 class="h5cust">&lt;h5&gt;  display style</h5>
                <ol type="i">
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                  <li>Listing 1</li>
                </ol>
              </figcaption>
            </figure>
          </section>
        </section>
      </section>
    </section>
    <aside class="col-sm-3">        
      <figure>
        <img class="marg30 img-responsive" src="<?php echo $assets_url;?>images/promo1.jpg" alt="promo1">
      </figure>
        
      <figure>
        <img class="marg30 img-responsive" src="<?php echo $assets_url;?>images/promo2.jpg" alt="promo2">
      </figure>       
    </aside>
  </section>
</section>  