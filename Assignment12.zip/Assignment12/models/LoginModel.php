<?php

class LoginModel extends basemodel {

    
    public function authenticate($uname, $password) {
        
        $this->uname = trim(stripslashes(htmlspecialchars($uname)));
        $this->password = md5($password);

        $sql = "SELECT id, username, firstname FROM user where username='" . $this->uname . "' AND password = '" . $this->password . "'";

        $result = $this->_db->query($sql);
        $resultData = $result->fetch_assoc();

        if ($result->num_rows > 0) {

            $this->createSession($resultData);

            return true;
        } else {

            return false;
        }
    }

    /**
     * @author Tatvasoft
     * set user information in session.
     * 
     * @params User Information
     */
    public function createSession($userData) {
        $_SESSION['uname'] = $userData['username'];
        $_SESSION['fname'] = $userData['firstname'];
        $_SESSION['id'] = $userData['id'];
        $_SESSION['logged']=true; 
    }

}
