<?php

class ProfileModel extends basemodel {
    /* Table which is mapped to current model */

    private $_table = 'user';

    public function getUserDetails($id) {
        $sql = "SELECT username, firstname, lastname, password, email, mobile_number, phone_number, gender, billing_add_id, shipping_add_id FROM " . $this->_table . " WHERE id = '" . $id . "';";

        $result = $this->_db->query($sql);


        if ($result->num_rows > 0) {

            return $result->fetch_assoc();
        } else {

            return false;
        }
    }

    public function getUserAddress($id) {
        $bill_id = $this->getUserDetails($id)['billing_add_id'];
        $ship_id = $this->getUserDetails($id)['shipping_add_id'];

        $billsql = "SELECT street, city, state_id, country_id, state.name AS state, country.name AS country, user.billing_add_id FROM user INNER JOIN address ON user.billing_add_id = address.id INNER JOIN state ON address.state_id = state.id INNER JOIN country ON state.country_id = country.id WHERE billing_add_id = '$bill_id'";
        $billresult = $this->_db->query($billsql);
        $billrow = $billresult->fetch_assoc();  

        $shipsql = "SELECT street, city, state_id, country_id, state.name AS state, country.name AS country, user.shipping_add_id FROM user INNER JOIN address ON user.shipping_add_id = address.id INNER JOIN state ON address.state_id = state.id INNER JOIN country ON state.country_id = country.id WHERE shipping_add_id = '$ship_id'";
        $shipresult = $this->_db->query($shipsql);
        $shiprow = $shipresult->fetch_assoc();  

        if ($billresult->num_rows > 0 && $shipresult->num_rows > 0) {

            return array($billrow, $shiprow);
        } else {

            return false;
        }
    }

    public function getCountry(){
        $sql2="SELECT id, name FROM country";
        $result2=$this->_db->query($sql2);
        $result3=$this->_db->query($sql2);

        return array($result2, $result3);
    }

    public function getState1() {
        if($_POST['id'])
        {
            $id = $_POST['id'];
            $sql = "SELECT id, name, country_id FROM state WHERE country_id = '$id'";
            $result = $this->_db->query($sql);
            
            echo "<option selected>Select State</option>";
            $array = $this->getUserAddress($_SESSION['id']); 

            while($row2=mysqli_fetch_object($result))
            {
                if(isset($array[0]['state']) && $row2->id == $array[0]['state_id']){
                    echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
                }
                else{                               
                    echo "<option value='".$row2->id."'>".$row2->name."</option>";
                } 
            }
        }
    }

    public function getState2() {
        if($_POST['id'])
        {
            $id = $_POST['id'];
            $sql = "SELECT id, name, country_id FROM state WHERE country_id = '$id'";
            $result = $this->_db->query($sql);
            
            echo "<option selected>Select State</option>";
            $array = $this->getUserAddress($_SESSION['id']); 

            while($row2=mysqli_fetch_object($result))
            {
                if(isset($array[1]['state']) && $row2->id == $array[1]['state_id']){
                    echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
                }
                else{                               
                    echo "<option value='".$row2->id."'>".$row2->name."</option>";
                } 
            }
        }
    }

    public function checkEmailExist($email) {
        $sql = "SELECT email FROM user WHERE username != '".$_SESSION['uname']."' AND email = '$email'";

        $result = $this->_db->query($sql);

        if ($result->num_rows > 0) {

            return true;
        } else {

            return false;
        }
    }
    
    // public function checkUsernameExist($username) {
    //     $sql = "SELECT id FROM " . $this->_table . " where username='" . $username . "'";

    //     $result = $this->_db->query($sql);

    //     if ($result->num_rows > 0) {

    //         return true;
    //     } else {

    //         return false;
    //     }
    // }
    
    public function validate($data) {
        
        $this->processInput($data);

        // if (!preg_match("/^[a-zA-Z0-9_-]{8,}$/", $this->data['inputUserName'])) {
        //     $this->validationError['username'] = "Enter a valid username";
        // }elseif ($this->checkUsernameExist($this->data['inputUserName'])) {
        //     $this->validationError['username'] = "Username already exists";
        // }

        if (!in_array($this->data['gender'], array('Male', 'Female'))) {
            $this->validationError['gender'] = 'Please select your gender.';
        }

        // if (!preg_match("/^(?=.*[a-z])(?=(?:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/", $this->data['inputPassword']) && !preg_match("/^[a-f0-9]{32}$/i", $this->data['inputPassword'])) {
        //     $this->validationError['password'] = "Enter a valid password";
        // }

        // if (!($this->data['inputPassword2'] == $this->data['inputPassword'])) {
        //     $this->validationError['password2'] = "Enter same as password";
        // }

        if (!preg_match('/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/', $this->data['inputEmail'])) {
            $this->validationError['email'] = "Enter a valid email";
        }elseif ($this->checkEmailExist($this->data['inputEmail'])) {
            $this->validationError['email'] = "Email already exists";
        }

        if (!preg_match("/^[A-Za-z]+$/", $this->data['inputFname'])) {
            $this->validationError['firstname'] = "Only alphabets";
        }

        if (!preg_match("/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/", $this->data['inputMobNo'])) {
            $this->validationError['mobileno'] = "US format, with or without dashes";
        }

        if (!empty($this->data['inputPhone']) && !preg_match("/^\d{10}$/", $this->data['inputPhone'])) {
            $this->validationError['phone'] = "Please enter valid number";
        }       

        // if (!isset($_POST['all']) && !isset($_POST['opt1']) && !isset($_POST['opt2']) && !isset($_POST['opt3']) && !isset($_POST['optoth']))
        // {
        //     $this->validationError['interest'] = "Please select anyone";
        // }else if (isset($_POST['optoth']) && empty($this->othtxt)) {
        //     $this->validationError['interest'] = "Please enter your interest";
        // }                    
        // if ($this->validationError) {

        //     if(isset($_POST['all'])){
        //     $this->validationError['inputAllVal'] = isset($_POST['all']);
        //     }

        //     if(isset($_POST['opt1'])){
        //     $this->validationError['inputOneVal'] = isset($_POST['opt1']);
        //     }

        //     if(isset($_POST['opt2'])){
        //     $this->validationError['inputTwoVal'] = isset($_POST['opt2']);
        //     }

        //     if(isset($_POST['opt3'])){
        //     $this->validationError['inputThreeVal'] = isset($_POST['opt3']);
        //     }

        //     if(isset($_POST['optoth'])){
        //     $this->validationError['inputOtherVal'] = isset($_POST['optoth']);
        //     }
        // }         

        if (empty($this->data['inputStreet'])) {
            $this->validationError['street'] = "Please enter Street";
        } 

        if (empty($this->data['inputStreet2'])) {
            $this->validationError['street2'] = "Please enter Street";
        } 

        if (empty($this->data['inputCity'])) {
            $this->validationError['city'] = "Please enter City";
        } 

        if (empty($this->data['inputCity2'])) {
            $this->validationError['city2'] = "Please enter City";
        } 

        if (empty($this->data['inputCountry'])) {
            $this->validationError['country'] = "Please Select Country";
        } 

        if (empty($this->data['inputState'])) {
            $this->validationError['state'] = "Please Select State";
        } 

        if (!isset($this->data['sameadd'])) {

            if (empty($this->data['inputCountry2'])) {
                $this->validationError['country2'] = "Please Select Country";
            } 

            if (empty($this->data['inputState2'])) {
                $this->validationError['state2'] = "Please Select State";
            } 
        }

        if (empty($this->validationError)) {
            return true;
        } else {
            return false;
        }
    }
    
    public function insert($data) {
        if ($this->validate($data)) {   

            $arr = $this->getUserAddress($_SESSION['id']);

            if(isset($this->data['sameadd'])){
                $State2 = $this->data['inputState'];
            }else{
                $State2 = $this->data['inputState2'];
            }

            if( is_null($arr[0]['billing_add_id'])){

                $sql2="INSERT INTO address(street, city, state_id) VALUES('".$this->data['inputStreet']."','".$this->data['inputCity']."','".$this->data['inputState']."')"; 

                if ($this->_db->query($sql2) ==+ TRUE) {
                    $bill_id=mysqli_insert_id($this->_db);
                    $sql1 = "UPDATE user SET billing_add_id = '$bill_id' WHERE username = '".$_SESSION['uname']."'";
                    $this->_db->query($sql1);
                }
            }
            else{
                $bil_id=$arr[0]['billing_add_id'];
                $sql1 = "UPDATE address SET street = '".$this->data['inputStreet']."', city = '".$this->data['inputCity']."', state_id = '".$this->data['inputState']."' WHERE id = '$bil_id'";
                $this->_db->query($sql1);                
            }
            if(is_null($arr[1]['shipping_add_id'])){

                $sql2="INSERT INTO address(street, city, state_id) VALUES ('".$this->data['inputStreet2']."', '".$this->data['inputCity2']."', '".$State2."')";  

                if ($this->_db->query($sql2) === TRUE) {
                    $ship_id=mysqli_insert_id($this->_db);
                    $sql1 = "UPDATE user SET shipping_add_id = '$ship_id' WHERE username = '".$_SESSION['uname']."'";
                    $this->_db->query($sql1);
                }               
            }
            else{
                $shi_id = $arr[1]['shipping_add_id'];
                $sql1 = "UPDATE address SET street = '".$this->data['inputStreet2']."', city = '".$this->data['inputCity2']."', state_id = '".$State2."' WHERE id = '$shi_id'";
                $this->_db->query($sql1);
                
            }

            $sql = "UPDATE user SET gender = '".$this->data['gender']."', email = '".$this->data['inputEmail']."', firstname = '".$this->data['inputFname']."', mobile_number = '".$this->data['inputMobNo']."', lastname = '".$this->data['inputLname']."', phone_number = '".$this->data['inputPhone']."' WHERE username = '".$_SESSION['uname']."';";

            if ($this->_db->query($sql) === TRUE) {
                return true;
            } else {

                return false;
            }    

        } else {

            return false;
        }    
    }

}

?>