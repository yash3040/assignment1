<?php

class HeaderModel extends basemodel {
    /* Table which is mapped to current model */

    private $_table = 'category';
    public $cat = array();

    public function getParCategories() {
        $query = "SELECT id, name FROM " . $this->_table . " WHERE parent_id = '0'";
        $result = $this->_db->query($query)->fetch_all();
        for ($i = 0; $i < sizeof($result); $i++) { 
            $cat[$i] = $this->getSubCategories($result[$i][0]);
            foreach ($cat[$i] as $key => $inner) {
                $arr[] = $inner[0];
                $sub[$result[$i][1]] = $arr;
            }
            $arr = array();
        }
        return $sub;
    }

    public function getSubCategories($id) {
        $query = "SELECT name FROM " . $this->_table . " WHERE parent_id = '$id' ";
        return $this->_db->query($query)->fetch_all();
    }  

}

?>
