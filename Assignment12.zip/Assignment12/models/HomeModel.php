<?php

class HomeModel extends basemodel {
    /* Table which is mapped to current model */


    public function TrendingItems()
    {
        $sql = "SELECT item.id, item_image_url, name, price, value FROM item INNER JOIN item_images ON item.id = item_images.item_id INNER JOIN item_options ON item.id = item_options.item_id INNER JOIN attributes_options ON item_options.ao_id = attributes_options.id WHERE is_trending = '1' GROUP BY item.id ORDER BY item.id ASC LIMIT 8;";         
        return  $this->_db->query($sql);
    } 
}

?>
