<?php
    $assets_url = ASSETS_URL;
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>eShopper</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="shortcut icon" href="<?php echo $assets_url;?>images/favicon.ico">
        <link rel="stylesheet" type="text/css" href="<?php echo $assets_url;?>/css/main.css">
        <script>
            var assets_url = '<?php echo $assets_url; ?>';     
            var site_url = '<?php echo SITE_URL; ?>';      
        </script>
        <script src="<?php echo $assets_url;?>/js/main.js"></script>
    </head>
    <body>
        
        <header>
            <nav class="navbar navbar-default navdef">
              <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <section class="row">
                    <section class="col-sm-1">
                        <div class="navbar-header">
                          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                          </button>

                          <a class="navbar-brand elogo" href="<?php echo SITE_URL;?>">
                                <svg height="50" width="50">
                                    <image height="50" width="50"  href="<?php echo $assets_url;?>/images/logo.svg" />
                                </svg>
                          </a>      

                        </div>
                    </section> 
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <section class="col-sm-5 col-xs-12 sec">
                        <div class="collapse navbar-collapse abs" id="bs-example-navbar-collapse-1">                         
                          <ul class="nav navbar-nav headul">
                            <li class="htext"><a class="headtext" href="<?php echo SITE_URL;?>">HOME</a></li>                            
                            <?php
                                foreach ($cat as $key => $value) {
                                    echo '<li class="dropdown htext mentxt"><a href="'.SITE_URL.''.$key.'" class="dropdown-toggle headtext" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">'.$key.'</a>';
                                    echo '<ul class="dropdown-menu dmenu">';
                                    echo '<li class="lihov"><a class="topa" href="'.SITE_URL.'product">'.$value[0].'</a></li>';
                                    for($i=1; $i<sizeof($value) ;$i++){
                                        echo '<li class="lihov"><a href="'.SITE_URL.'product">'.$value[$i].'</a></li>';
                                    }    
                                    echo "</ul></li>";
                                }
                            ?>      
                          </ul>                         
                        </div><!-- /.navbar-collapse -->                  
                    </section>                      
                    <section class="col-sm-6 col-xs-12 rightsec">
                        <ul class="nav navbar-nav navbar-right text-center">
                            <?php
                                    if (isset($_SESSION['logged'])) {
                                        echo '<li class="inline posrel"><a class="botpad0 rightbor welc">Welcome, '.$_SESSION["fname"].'</a></li>';
                                        echo '<li class="inline"><a href="'.SITE_URL.'profile" class="botpad0 rightbor">Profile</a></li>';
                                        echo '<li class="inline"><a href="'.SITE_URL.'logout" class="botpad0 login rightbor">Logout</a></li>';
                                    }
                                    else{
                                        echo '<li class="inline"><a href="#" class="botpad0 login" data-toggle="modal" data-target="#loginmodal">Login</a></li>';
                                    }
                                ?>

                                    <li class="dropdown inline licrt">
                                    <a class="dropdown-toggle botpad0" id="menu1" data-toggle="dropdown">
                                    
                                    <div class="cart inline"></div></a>

                                    <!--Cart Dropdown-->
                                    <ul class="dropdown-menu ulddcart" role="menu" aria-labelledby="menu1">
                                      <li role="presentation"><a role="menuitem" tabindex="-1">Recently Added Item(s)</a></li>
                                      <li role="presentation"><a role="menuitem" tabindex="-1">

                                        <div class="table-responsive">          
                                          <table class="table cart_table">
                                            <tbody class="tdbord0 cart_body">
                                                <?php
                                                    if (isset($_SESSION['item'])) {
                                                        $total = 0;
                                                        foreach ($_SESSION['item'] as $key => $value) {
                                                            $total += $value[3] * $value[4];
                                                            echo '<tr>
                                                                    <td><img src="'.$assets_url.'images/'.$value[5].'" class="img-responsive crtimg" alt="cart-img'.$value[0].'"></td>
                                                                    <td class="whitenorm">'.$value[1].' 
                                                                        <p class="text4 crtp">&dollar;'.$value[4].'.00</p>
                                                                        <p class="crtp">Qty: '.$value[3].'</p>
                                                                        <p class="crtp">Size: '.$value[2].'</p>
                                                                    </td>
                                                                    <td>
                                                                        <svg height="14" width="20">
                                                                            <image height="14" width="15" href="'.$assets_url.'images/edit-dark.svg" />
                                                                        </svg>
                                                                    </td>   
                                                                    <input type="hidden" id="popupsize'.$value[0].'" value="'.$value[2].'">                                            
                                                                    <td>
                                                                        <svg height="14" width="20" class="pointer" onclick="popupDelete('.$value[0].')">
                                                                            <image height="14" width="15" href="'.$assets_url.'images/cross-dark.svg" />
                                                                        </svg>
                                                                    </td>
                                                                  </tr>';
                                                        }
                                                        echo '<tr>
                                                                <td><p>Cart Subtotal :</p></td>
                                                                <td><p class="text4">&dollar;'.$total.'.00</p></td>
                                                              </tr> 
                                                              <tr>
                                                                <td></td>
                                                                <td class="text-center"><a href="'.SITE_URL.'cart" class="btn btn-default btnr2">View Cart</a></td>
                                                              </tr>';                                                
                                                    }
                                                ?>           
                                            </tbody>
                                          </table>
                                        </div>

                                      </a></li>
                                     
                                    </ul><!--/Cart Dropdown--> 
                                </li> <!--/Cart-->
                            

                            <li class="inline lisrch">    
                                <input class="search" type="search" placeholder="Search" />
                                <button class="icon" aria-label="Left Align">                       
                                    <svg width="20" height="25">
                                        <image width="20" height="25" href="<?php echo $assets_url;?>/images/search.svg" />
                                    </svg>  
                                </button>                       
                            </li> 
                        </ul>               
                    </section>              
                </section>
              </div><!-- /.container-fluid -->
            </nav>  
        </header>


