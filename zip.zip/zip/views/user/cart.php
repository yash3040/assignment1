<?php
    $assets_url = ASSETS_URL;
?>
<section class="container-fluid banpad">
  <section class="row">
    <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">    
  </section>
</section> 

<section class="container">						
	<h2 class="crt">Shopping Cart</h2>			
	<nav aria-label="breadcrumb">
	  <ol class="breadcrumb brdcrmb">
	    <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
	    <li class="breadcrumb-item active" aria-current="page">Shopping Cart</li>
	  </ol>
	</nav>
</section>	

<section class="container">
	<section class="row">
		<section class="col-sm-12">
			<div class="alert alert-success alert-dismissible alrtsuc" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<svg height="14" width="20">
				  	<image height="14" width="15"  href="<?php echo $assets_url;?>images/success.svg" />
				</svg>
			  U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men was added to your shopping cart.
			</div>
			<div class="alert alert-info alert-dismissible alrtinfo" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<svg height="14" width="20">
				  	<image height="14" width="15"  href="<?php echo $assets_url;?>images/info.svg" />
				</svg>
			  U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men was added to your shopping cart.
			</div>
			<div class="alert alert-warning alert-dismissible alrtwarn" role="alert">
			  	<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			  	<svg height="14" width="20">
				  	<image height="14" width="15"  href="<?php echo $assets_url;?>images/warning.svg" />
				</svg>
			  U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men was added to your shopping cart.
			</div>	
			<div class="alert alert-danger alert-dismissible alrtdngr" role="alert">
			  	<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
			  	<svg height="14" width="20">
				  	<image height="14" width="15"  href="<?php echo $assets_url;?>images/error.svg" />
				</svg>
			  U.S. Polo Assn. Full Sleeve Plain T-Shirt for Men was added to your shopping cart.
			</div>
			<div class="table-responsive cart_div">          
			  <table class="table bordbot cart_table2">
			    <thead>
			      <tr>
			        <th></th>
			        <th>Product Name</th>
			        <th></th>
			        <th>Unit Price</th>
			        <th>Qty</th>
			        <th>Subtotal</th>
			        <th></th>
			      </tr>
			    </thead>
			    <tbody>	
			      <?php
                    if (isset($_SESSION['item'])) {
                        $total = 0;
                        foreach ($_SESSION['item'] as $key => $value) {
                            $subtotal = $value[3] * $value[4];
                            $total += $value[3] * $value[4];
                            echo '<tr>
                                    <td class="imgtd"><img src="'.$assets_url.'images/'.$value[5].'" class="img-responsive crtimg" alt="cart-img'.$value[0].'">
                                    </td>
                                    <td>'.$value[1].'<br> 
	                                    <b>Color</b><br>
							        	Blue<br>
							        	<b>Size</b><br>
							        	'.$value[2].'	
                                    </td>
                                    <input type="hidden" id="inputSize'.$value[0].'" value="'.$value[2].'">
                                    <td>
                                        <svg height="14" width="20">
                                            <image height="14" width="15" href="'.$assets_url.'images/edit-dark.svg" />
                                        </svg>
                                    </td>   
                                    <td class="redtxt">&dollar;'.$value[4].'.00</td>    
                                    <td><input type="text" class="form-control qty" id="inputqty'.$value[0].'" value="'.$value[3].'" onchange="updateSub('.$value[0].')"/>
			        				</td>  			        				
                                    <td class="redtxt">&dollar;'.$subtotal.'.00</td>                                
                                    <td>
                                        <svg height="14" width="20" class="pointer" onclick="popupDelete('.$value[0].')">
                                            <image height="14" width="15" href="'.$assets_url.'images/cross-dark.svg" />
                                        </svg>
                                    </td>
                                  </tr>';
                        }
                    }    
                ?>			      
			    </tbody>
			  </table>
			</div>
			<div class="row toppad">
				<div class="col-sm-6">
			    	<button type="button" class="btn btn-default btnd">Continue Shopping</button>	
			    </div>
			    <div class="col-sm-6">
			    	<div class="pull-right">
					    <button type="button" class="btn btn-default btnd" onclick="clearCart();">Clear Shopping Cart</button>
					    <button type="button" class="btn btn-default btnd" onclick="updateTotal();">Update Shopping Cart</button>
				    </div>
			    </div>	
			</div>
		</section>
	</section>

	<section class="row">
		<section class="col-sm-6 col-xs-12 cartform">
			<h3>Estimate Shipping and Tax</h3>
			<p>Enter your destination to get a shipping estimate.</p>
			<form>
				<div class="form-group">
			      <label for="inputCountry">Country</label>
			      <select id="inputCountry" class="form-control">
			        <option selected>India</option>
			        <option>...</option>
			      </select>
			    </div>
			  	<div class="form-group">
				    <label for="inputState">State/Province</label>
				    <input type="text" class="form-control" id="inputState" placeholder="State/Province">
				</div>
			  <div class="form-group">
			    <label for="inputZip">Zip/Postal Code</label>
			    <input type="text" class="form-control" id="inputZip" placeholder="Zip/Postal Code">
			  </div>
			</form>
		</section>
		<section class="col-sm-6 col-xs-12 cartpanel pull-right">
			<div class="panel panel-default innerpanel">
			  <div class="panel-body">
			  	<div class="row">
				   		<div class="col-sm-10 col-xs-10"><p class="pull-right">Subtotal</p></div>
				   		<div class="col-sm-2 col-xs-2"><p>&dollar;<?php echo isset($total) ? $total : "00" ;?></p></div>
				</div>	   	
				
				<div class="row">
				   		<div class="col-sm-10 col-xs-10"><p class="pull-right"><b>Total</b></p></div>
				   		<div class="col-sm-2 col-xs-2"><p class="text4">&dollar;<?php echo isset($total) ? $total : "00" ;?></p></div>
				</div>

				<div class="row">
					<div class="col-sm-12">
						<div class="pull-right">
				   			<button type="button" class="btn btn-default btnr2">Update Shopping Cart</button>
			   			</div>
			   		</div>
			   	</div>
			  </div>
			  <div class="panel-footer">Checkout With Multiple Addresses</div>
			</div>
		</section>
	</section>
</section>