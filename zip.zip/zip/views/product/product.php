<?php
    $assets_url = ASSETS_URL;
?>
<section class="container-fluid banpad">
  <section class="row">
    <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">    
  </section>
</section>  

<section class="container">           
  <h2 class="crt">Men</h2>      
  <nav aria-label="breadcrumb">
    <ol class="breadcrumb brdcrmb">
      <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
      <li class="breadcrumb-item"><a href="">Men</a></li>
      <li class="breadcrumb-item active" aria-current="page">T-Shirts</li>
    </ol>
  </nav>
</section>  

<section class="container">
  <section row>
    <section class="col-sm-3">
      <div class="fltrdiv">
        <p class="fltr panel-heading">FILTER BY</p>
        <div class="panel-group" role="tablist" aria-multiselectable="true">
          <div class="panel panel-default pnldef">
            <div class="panel-heading pnlhdbg" role="tab" id="category">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  <div class="row">
                    <div class="col-md-10 col-sm-9 col-xs-10">CATEGORIES</div>
                    <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                  </div>                      
                </a>
              </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="category">
              <div class="panel-body bdytop">
                <form>
              <div class="checkbox">
                <label><input type="checkbox" value="">T-Shirts (25275)</label>
              </div>
              <div class="checkbox">
                  <label><input type="checkbox" value="">Shirts (24866)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">Jackets (5326)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">Sweaters (4871)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">Sweatshirts (4533)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">Kurtas (1566)</label>
                </div>
            </form> 
              </div>
            </div>
          </div>
          <div class="panel panel-default pnldef">
            <div class="panel-heading pnlhdbg" role="tab" id="color">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                  <div class="row">
                    <div class="col-md-10 col-sm-9 col-xs-10">COLOUR</div>
                    <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                  </div>
                </a>
              </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="color">
              <div class="panel-body bdytop">
                <div class="table-responsive colrdiv">          
              <table class="table">
                <tbody class="tdbord0">
                  <tr>
                    <td class="tdcol"><input type="button" name="mag" class="mag"></td>
                    <td class="tdcol2">Magenta</td>
                  </tr> 
                  <tr class="disble">
                    <td><input type="button" name="pink" class="pink" disabled></td>
                    <td class="tdcol2">Pink</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="red" class="red"></td>
                    <td class="tdcol2">Red</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="lav" class="lav"></td>
                    <td class="tdcol2">Lavender</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="navy" class="navy"></td>
                    <td class="tdcol2">Navy</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="blue" class="blue"></td>
                    <td class="tdcol2">Blue</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="grey" class="grey"></td>
                    <td class="tdcol2">Grey</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="teal" class="teal"></td>
                    <td class="tdcol2">Teal</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="peach" class="peach"></td>
                    <td class="tdcol2">Peach</td>
                  </tr>
                  <tr>
                    <td><input type="button" name="orange" class="orng"></td>
                    <td class="tdcol2">Orange</td>
                  </tr>
                  <tr>
                    <td></td>
                    <td><a href="" class="text4">Reset</a></td>
                  </tr>           
                </tbody>
              </table>
            </div>
              </div>
            </div>
          </div>
          <div class="panel panel-default pnldef">
            <div class="panel-heading pnlhdbg" role="tab" id="price">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                  <div class="row">
                    <div class="col-md-10 col-sm-9 col-xs-10">PRICE</div>
                    <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                  </div>
                </a>
              </h4>
            </div>
            <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="price">
              <div class="panel-body bdytop">
                <p class="text-center">31 items</p>
                <img src="<?php echo $assets_url;?>images/price.jpg" class="prcimg">
                <div class="row">
                  <div class="col-xs-7">
                    Rs. 174
                  </div>
                  <div class="col-xs-5">
                    <div class="pull-right"> Rs. 8,999</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="panel panel-default pnldef">
            <div class="panel-heading pnlhdbg" role="tab" id="size">
              <h4 class="panel-title">
                <a role="button" data-toggle="collapse" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                  <div class="row">
                    <div class="col-md-10 col-sm-9 col-xs-10">SIZE</div>
                    <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                  </div>
                </a>
              </h4>
            </div>
            <div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="size">
              <div class="panel-body bdytop">
                <form>
              <div class="checkbox">
                <label><input type="checkbox" value="">XXS (81)</label>
              </div>
              <div class="checkbox">
                  <label><input type="checkbox" value="">XS (1446)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">S (24706)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">M (29467)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">L (29516)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">XL (27823)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">XXL (16841)</label>
                </div>
                <div class="checkbox">
                  <label><input type="checkbox" value="">XXXL (43)</label>
                </div>
            </form> 
              </div>
            </div>
          </div>
        </div>
      </div>  

      <div class="promo">
        <img src="<?php echo $assets_url;?>images/promo2.jpg" alt="promo2">          
      </div><br><br>
    </section>

    <section class="col-sm-9">

      <div class="row">
        <div class="col-sm-12">
          <p class="men">Men T-Shirts</p>
        </div>
      </div>

      <div class="row">
        <div class="col-sm-12">
          <div class="pull-right">
            Sort By
                <select id="sort">
                  <option selected>Position</option>
                  <option>Name</option>
                  <option>Price</option>
                </select><br>
          </div>              
        </div>
      </div><br>
      
        <?php
          $total = mysqli_num_rows($result) / 3;    
          $tempMod = ($total - (int)$total) * 3;
            
          if (mysqli_num_rows($result) < 4) {
            if ($tempMod == 0) {
              echo '<section class="row">';
              for ($i=0; $i < 3 ; $i++) { 
                $row = mysqli_fetch_object($result);
                  echo '<section class="col-sm-4">
                          <div class="thumbnail">
                            <div class="imgcont">   
                             <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                             <div class="hvrbut">
                              <a href="'.SITE_URL.'cart/index/'.$row->id.'" class="but btn btn-default">ADD TO CART</a>
                             </div>
                            </div>
                            <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                             <div class="caption">
                              <p class="text3">'.$row->name.'</p>
                              <p class="text4">$'.$row->price.'</p>                   
                             </div>
                            </a>
                          </div>
                        </section>';    
              }
              echo '</section>';
            }
            else{
              echo '<section class="row">';
              for ($i=0; $i < $tempMod; $i++) { 
                $row = mysqli_fetch_object($result);
                  echo '<section class="col-sm-4">
                          <div class="thumbnail">
                            <div class="imgcont">   
                             <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                             <div class="hvrbut">
                              <a href="'.SITE_URL.'cart/index/'.$row->id.'" class="but btn btn-default">ADD TO CART</a>
                             </div>
                            </div>
                            <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                             <div class="caption">
                              <p class="text3">'.$row->name.'</p>
                              <p class="text4">$'.$row->price.'</p>                   
                             </div>
                            </a>
                          </div>
                        </section>';    
              }
              echo '</section>';
            } 
          }
          else{
            for ($i=0; $i < $total--; $i++) { 
              echo '<section class="row">';
              for ($j=0; $j < 3 ; $j++) { 
                $row = mysqli_fetch_object($result);
                  echo '<section class="col-sm-4">
                          <div class="thumbnail">
                            <div class="imgcont">   
                             <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                             <div class="hvrbut">
                              <a href="'.SITE_URL.'cart/index/'.$row->id.'" class="but btn btn-default">ADD TO CART</a>
                             </div>
                            </div>
                            <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                             <div class="caption">
                              <p class="text3">'.$row->name.'</p>
                              <p class="text4">$'.$row->price.'</p>                   
                             </div>
                            </a>
                          </div>
                        </section>';    
              }
              echo '</section>';
            }
            if ($tempMod == 0) {
              echo '<section class="row">';
              for ($i=0; $i < 3 ; $i++) { 
                $row = mysqli_fetch_object($result);
                  echo '<section class="col-sm-4">
                          <div class="thumbnail">
                            <div class="imgcont">   
                             <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                             <div class="hvrbut">
                              <a href="'.SITE_URL.'cart/index/'.$row->id.'" class="but btn btn-default">ADD TO CART</a>
                             </div>
                            </div>
                            <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                             <div class="caption">
                              <p class="text3">'.$row->name.'</p>
                              <p class="text4">$'.$row->price.'</p>                   
                             </div>
                            </a>
                          </div>
                        </section>';    
              }
              echo '</section>';
            }
            else{
              echo '<section class="row">';
              for ($i=0; $i < $tempMod; $i++) { 
                $row = mysqli_fetch_object($result);
                  echo '<section class="col-sm-4">
                          <div class="thumbnail">
                            <div class="imgcont">   
                             <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                             <div class="hvrbut">
                              <a href="'.SITE_URL.'cart/index/'.$row->id.'" class="but btn btn-default">ADD TO CART</a>
                             </div>
                            </div>
                            <a href="'.SITE_URL.'product_detail/index/'.$row->id.'" class="nodeco">
                             <div class="caption">
                              <p class="text3">'.$row->name.'</p>
                              <p class="text4">$'.$row->price.'</p>                   
                             </div>
                            </a>
                          </div>
                        </section>';    
              }
              echo '</section>';
            } 
          }
        ?>
      <br><br>

      <center><button type="button" class="btn btn-default btnd">More Products</button></center></br></br>
    </section>
  </section>
</section>