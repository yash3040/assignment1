<?php

class Contact extends BaseController
{
	
	public function index()
	{	
		$validationErrors = array();
		
		if(isset($_POST['contact'])) {
			
			$this->load_model("ContactModel");
			
			if($this->contactmodel->ConMail($_POST['contact'])) {
				echo "<script>alert('Your Message has been Submitted');window.location.href='".SITE_URL."contact'</script>";		
			} else{
				$validationErrors = $this->contactmodel->getErrors();		
			}
		
		}	
		
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        
        $this->load_view('header', $cat);  
		$this->load_view('user/contact', array('validationErrors'=>$validationErrors));
		
		$this->load_model("FooterModel");

        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
	}
}
