<?php

class Logout extends BaseController {

    public function index() {
        session_unset();
        session_destroy();
        $this->redirect();
    }

}
