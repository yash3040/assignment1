<?php

class Product_Detail extends BaseController {
    

    public function index($id) {
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();

        $this->load_model("ProductModel");
        $details['item'] = $this->productmodel->productDetails($id);
        $details['itemid'] = $id;
        $details['review'] = $this->productmodel->getReview($id);
        $this->load_view('header', $cat);    
        $this->load_view('product/product_detail', $details);
        
        $this->load_model("FooterModel");

        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
    }

    public function addToWish()
    {   
        if(checkIfLogin()){
            $id = $_POST['id'];
            $this->load_model("ProductModel");
            $result = $this->productmodel->addToWishlist($id);
            if($result == true){
                echo 1;
            }
            else if($result == false){
                echo 2;
            }
        }else{
            echo 3;
        }    
    }

    public function addCart()
    {   
        if(checkIfLogin()){
            $id = $_POST['id'];
            $qty = $_POST['qty'];
            $size = $_POST['size'];
            $this->load_model("ProductModel");
            $result = $this->productmodel->addToCart($id, $qty, $size);
            if($result == true){
                echo 1;
            }
            else{
                echo "error";
            }
        }else{
            echo 3;
        }    
    }

    public function deletePopup()
    {   
        $id = $_POST['id'];
        $size = $_POST['size'];
        $this->load_model("ProductModel");
        $result = $this->productmodel->deleteFromPopup($id, $size);
        if($result == true){
            echo 1;
        }
        else{
            echo "error";
        }  
    }

    public function review()
    {   
        if(checkIfLogin()){
            $id = $_POST['id'];
            $star = $_POST['star'];
            $text = $_POST['text'];
            if (empty($star) || empty($text)) {
                echo 4;
            }else{
                $this->load_model("ProductModel");
                $result = $this->productmodel->addReview($id, $star, $text);
                if($result == true){
                    echo 1;
                }
                else if($result == false){
                    echo 2;
                }
                else{
                    echo "error";
                }
            }
        }else{
            echo 3;
        }    
    }

}
