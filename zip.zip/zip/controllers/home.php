<?php

class Home extends BaseController {
    

    public function index() {
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();

        $this->load_model('HomeModel');
        $result['result'] = $this->homemodel->TrendingItems(); 

        $this->load_view('header', $cat);    
        $this->load_view('home', $result);  

        $this->load_model("FooterModel");

        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
    }
}
