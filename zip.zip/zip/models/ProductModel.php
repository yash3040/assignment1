<?php

class ProductModel extends basemodel {
    /* Table which is mapped to current model */


    public function ProductList()
    {
        $sql = "SELECT item.id, item_image_url, item.name, price FROM item_images INNER JOIN item ON item.id = item_images.item_id INNER JOIN category ON item.category_id = category.id WHERE category.name = 'T-shirts' GROUP BY item.id ORDER BY item.id ASC;";         
        return  $this->_db->query($sql);
    }  

    public function productDetails($id)
    {
        $sql = "SELECT item.name, item.sku, item.price, item.short_desc, item.description, item.delivery_desc, item.shipping_desc, item.sizeguide_desc, value, review_text, review_date, user.firstname FROM item INNER JOIN item_options ON item.id = item_options.item_id INNER JOIN attributes_options ON item_options.ao_id = attributes_options.id INNER JOIN item_review ON item.id = item_review.id INNER JOIN user ON item_review.user_id = user.id WHERE item.id = '".$id."' AND ao_id < '9';"; 

        $sql2 = "SELECT GROUP_CONCAT(item_image_url) AS image_url FROM item_images WHERE item_id = '".$id."' GROUP BY is_primary ORDER BY id;";

        return  array($this->_db->query($sql)->fetch_assoc(), $this->_db->query($sql), $this->_db->query($sql2)->fetch_all());
    } 

    public function addToWishlist($id)
    {
        $sql = "SELECT id FROM wishlist WHERE item_id = '".$id."' AND user_id = '".$_SESSION['id']."'";         
        if($this->_db->query($sql)->num_rows > 0){
            return false;
        }else{
            $sql = "INSERT INTO wishlist(item_id, user_id) VALUES('".$id."', '".$_SESSION['id']."')";
            if($this->_db->query($sql)){
                return true;
            }else{
                return "error";
            }    
        }
    }

    public function addToCart($id, $qty, $size)
    {   
        $sql = "SELECT item_image_url, name, price FROM item_images INNER JOIN item ON item.id = item_images.item_id WHERE item_id = '".$id."' AND is_primary = '1';";

        $result = $this->_db->query($sql)->fetch_all();

        if (isset($_SESSION['item'])) {

            foreach ($_SESSION['item'] as $key => $value) {
                if($id === $value[0] && $size === $value[2]){
                    $flag = $key;
                }
            }

            if (isset($flag)) {
                $_SESSION['item'][$flag][3] = $_SESSION['item'][$flag][3]+$qty;
            }else{
                $_SESSION['item'][] = array($id, $result[0][1], $size, $qty, $result[0][2], $result[0][0]);
            }
        }else{
            $_SESSION['item'][] = array($id, $result[0][1], $size, $qty, $result[0][2], $result[0][0]);
        }
        

        if($result){
            return true;
        }else{
            return false;    
        }
    }

    public function deleteFromPopup($id, $size)
    {   
        if (isset($_SESSION['item'])) {

            foreach ($_SESSION['item'] as $key => $value) {
                if($id === $value[0] && $size === $value[2]){
                    $flag = $key;
                }
            }

            if (isset($flag)) {
                if (count($_SESSION['item']) == 1) {
                    unset($_SESSION['item']);
                    $deleted = true;
                }else{                    
                    unset($_SESSION['item'][$flag]);
                    $deleted = true;
                }
            }else{
                $deleted = false;
            }
        }else{
            $deleted = false;
        }
        

        if($deleted){
            return $deleted;
        }else{
            return $deleted;    
        }
    }

    public function addReview($id, $star, $text)
    {
        $sql = "SELECT id FROM item_review WHERE item_id = '".$id."' AND user_id = '".$_SESSION['id']."'";         
        if($this->_db->query($sql)->num_rows > 0){
            return false;
        }else{
            $sql = "INSERT INTO item_review(item_id, user_id, ratings, review_text) VALUES('".$id."', '".$_SESSION['id']."', '".$star."', '".$text."')";
            if($this->_db->query($sql)){
                return true;
            }else{
                return "error";
            }    
        }
    }

    public function getReview($id)
    {        
        $sql = "SELECT user_id, review_text, review_date FROM item_review WHERE item_id = '".$id."' ORDER BY review_date DESC LIMIT 1";
        $result = $this->_db->query($sql)->fetch_assoc();

        $getuser = "SELECT firstname FROM user WHERE id = '".$result['user_id']."'";
        $user = $this->_db->query($getuser)->fetch_assoc();

        if(isset($user)){
            return array($result, $user);
        }else{
            return false;
        }   
    }

}

?>
