<?php

class HomeModel extends basemodel {

    /**
    * @author Yash
    * Get all the trending items from database.
    * @param limit to fetch more products.
    *
    * @return array consisting trending items.
    */

    public function TrendingItems($limit)
    {	
        $sql = "SELECT i.id, ii.item_image_url, i.name, i.price, ao.value, io.id AS `variation_id`, ao.id AS `ao.id`, ao2.value AS `color`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                RIGHT JOIN item_images ii ON i.id = ii.item_id 
                WHERE i.is_trending = '1'
                GROUP BY i.id 
                ORDER BY i.id ASC 
                LIMIT ".$limit.";";   

        return  $this->_db->query($sql);
    } 


    /**
    * @author Yash
    * Get search results from database to show in search dropdown.
    * @param string to search for.
    *
    * @return array consisting of categories and items if any found.
    */

    public function searchProds($str)
    {
        $sql = "SELECT i.id, i.name AS `item_name` 
                FROM item i 
                WHERE (i.name LIKE '%".$str."%' ESCAPE '/');";   

        $sql1 = "SELECT c.id, c.name AS `cat_name` 
                 FROM category c 
                 WHERE (c.name LIKE '%".$str."%' ESCAPE '/') AND c.parent_id != '0';";        

        return  array($this->_db->query($sql1), $this->_db->query($sql));
    }
}
?>