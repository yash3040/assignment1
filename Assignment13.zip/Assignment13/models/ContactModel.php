<?php

class ContactModel extends basemodel {

    /* Table which is mapped to current model */
    private $_table = 'user';


    /**
    * @author Yash
    * Validates contact from data.
    * 
    * @param contact form data. 
    * @return validation errors if any occured.
    */
  
    public function ConValid($data) 
    {        
        $this->processInput($data);

        if (!preg_match("/^[A-Za-z]+$/", $this->data['inputConName'])) {
            $this->validationError['name'] = "Only alphabets";
        }
        if (!preg_match('/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/', $this->data['inputConEmail'])) {
            $this->validationError['email'] = "Enter a valid email";
        }
        if (empty($this->data['inputSubject'])) {
            $this->validationError['subject'] = "Please enter subject";
        }   
        if (empty($this->data['inputMessage'])) {
            $this->validationError['message'] = "Please enter message";
        }     

        if (empty($this->validationError)) {
            return true;
        }else {
            return false;
        }
    }


    /**
    * @author Yash
    * Mail the data to admin.
    * 
    * @param contact form data. 
    * @return true/false if mail is sent or not.
    */

    function ContactMail($admin_mail, $name, $mail, $sub, $msg)
    {
        $to = $admin_mail;
        $subject = $sub;
        $message = "<html><body><p>Hi I am ".$name.",</p><p>".$msg."</p></body></html>";
        $message = wordwrap($message,70);
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: $mail" . "\r\n";

        if(mail($to,$subject,$message,$headers)){
            return true;
        }else{
            return false;
        }
    }


    /**
    * @author Yash
    * Get admin and call the above mail function.
    * 
    * @param contact form data. 
    * @return true/false if mail is sent or not.
    */
    
    public function ConMail($data) 
    {   
        $sql = "SELECT email 
                FROM ".$this->_table." 
                WHERE username = 'eshop__admin'";

        $result = $this->_db->query($sql);
        $row = $result->fetch_assoc();
        if($this->ConValid($data)){
            if ($this->ContactMail($row['email'], $this->data['inputConName'], $this->data['inputConEmail'], $this->data['inputSubject'], $this->data['inputMessage'])){
                return true;
            } else {
                return false;
            }            
        }else {
            return false;
        }  
    }
}
?>