<?php

class LoginModel extends basemodel {

    /* Table which is mapped to current model */
    private $_table = 'user';

    /**
    * @author Yash
    * check Authentication while login .
    * 
    * @param username/email and password 
    * @return true if valid user and false if invalid user .
    */
    
    public function authenticate($email, $password) 
    {
        $this->email = trim(stripslashes(htmlspecialchars(strip_tags($email))));
        $this->password = md5($password);

        $sql = "SELECT id, firstname, username 
                FROM ".$this->_table." 
                WHERE (email='" . $this->email . "' OR username='" . $this->email . "') AND password = '" . $this->password . "'";

        $result = $this->_db->query($sql);
        $resultData = $result->fetch_assoc();

        if ($result->num_rows > 0) {

            //to create session
            $this->createSession($resultData);

            return true;
        }else {
            return false;
        }
    }


    /**
     * @author Yash
     * Set user information in session.
     * 
     * @param User Information
     */

    public function createSession($userData) 
    {
        $_SESSION['uname'] = $userData['username'];
        $_SESSION['fname'] = $userData['firstname'];
        $_SESSION['id'] = $userData['id'];
        $_SESSION['logged']=true; 
    }
}
?>