<?php

class CartModel extends basemodel {

    /**
    * @author Yash
    * Updtaes subtotal in cart page.
    * 
    * @param item details. 
    * @return true/false if quantity is updated or not.
    */

    public function updateSubtotal($id, $qty, $size)
    {   
        $sql = "SELECT item_image_url, name, price 
                FROM item_images 
                INNER JOIN item ON item.id = item_images.item_id 
                WHERE item_id = '".$id."' AND is_primary = '1';";

        $result = $this->_db->query($sql)->fetch_all();

        if (isset($_SESSION['item'])) {

            foreach ($_SESSION['item'] as $key => $value) {
                if($id === $value[0] && $size === $value[2]){
                    $flag = $key;
                }
            }

            if (isset($flag)) {
                $_SESSION['item'][$flag][3] = $qty;
            }else{
                $_SESSION['item'][] = array($id, $result[0][1], $size, $qty, $result[0][2], $result[0][0]);
            }
        }else{
            $_SESSION['item'][] = array($id, $result[0][1], $size, $qty, $result[0][2], $result[0][0]);
        }
        

        if($result){
            return true;
        }else{
            return false;    
        }
    }
}
?>