<?php

class HeaderModel extends basemodel {

    /* Table which is mapped to current model */
    private $_table = 'category';

    //array to store fetched categories from database.
    public $cat = array();


    /**
    * @author Yash
    * Get all the parent categories from database.
    * Call below function to get sub categories of each parent category.
    *
    * @return array consisting of parent categories mapped with sub categories.
    */

    public function getParCategories() 
    {
        $query = "SELECT id, name 
                  FROM " . $this->_table . " 
                  WHERE parent_id = '0'";

        $result = $this->_db->query($query)->fetch_all();
        for ($i = 0; $i < sizeof($result); $i++) { 

            //to get sub categories
            $cat[$i] = $this->getSubCategories($result[$i][0]);
            foreach ($cat[$i] as $key => $inner) {
                $arr[] = $inner[0];
                $sub[$result[$i][1]] = $arr;
            }
            $arr = array();
        }
        return $sub;
    }


    /**
    * @author Yash
    * Get sub categories from database.
    * 
    * @param parent category id. 
    * @return array of sub categories.
    */

    public function getSubCategories($id) 
    {
        $query = "SELECT name 
                  FROM " . $this->_table . " 
                  WHERE parent_id = '$id' ";
                  
        return $this->_db->query($query)->fetch_all();
    }  
}
?>