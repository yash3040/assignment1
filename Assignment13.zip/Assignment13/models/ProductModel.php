<?php

class ProductModel extends basemodel {

    /**
    * @author Yash
    * Get products from database to show in listing page.
    * 
    * @param limit to show products. 
    * @return object of the query.
    */

    public function ProductList($limit)
    {
        $sql = "SELECT i.id, ii.item_image_url, i.name, i.price, ao.value, io.id AS `variation_id`, ao.id AS `ao.id`, ao2.value AS `color`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                LEFT JOIN item_images ii ON i.id = ii.item_id 
                LEFT JOIN category c ON i.category_id = c.id 
                GROUP BY variation_id 
                ORDER BY i.id ASC
                LIMIT ".$limit.";";    

        return  $this->_db->query($sql);
    }  


    /**
    * @author Yash
    * Get products from database by category to show in listing page.
    * 
    * @param category of which products will be shown. 
    * @return object of the query.
    */

    public function ProductListByCat($cat)
    {
        $sql = "SELECT i.id, ii.item_image_url, i.name, i.price, ao.value, io.id AS `variation_id`, ao.id AS `ao.id`, ao2.value AS `color`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                LEFT JOIN item_images ii ON i.id = ii.item_id 
                LEFT JOIN category c ON i.category_id = c.id 
                WHERE c.name = '".$cat."'
                GROUP BY variation_id 
                ORDER BY i.id ASC;"; 

        return  $this->_db->query($sql);
    }  


    /**
    * @author Yash
    * Get products details and images from database to show in details page.
    * 
    * @param id of products. 
    * @return array of objects of the queries.
    */

    public function productDetails($id)
    {
        $sql = "SELECT i.name, i.sku, i.price, i.short_desc, i.description, i.delivery_desc, i.shipping_desc, 
                i.sizeguide_desc, value, review_text, review_date, u.firstname, c.name AS `c_name` , io.id AS `variation_id`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN item_images ii ON i.id = ii.item_id 
                LEFT JOIN category c ON i.category_id = c.id 
                LEFT JOIN item_review ir ON i.id = ir.item_id
                LEFT JOIN user u ON ir.user_id = u.id
                WHERE i.id = '".$id."'
                GROUP BY variation_id 
                ORDER BY i.id ASC;";

        $sql2 = "SELECT GROUP_CONCAT(item_image_url) AS image_url 
                 FROM item_images 
                 WHERE item_id = '".$id."' 
                 GROUP BY is_primary 
                 ORDER BY id;";

        return  array($this->_db->query($sql)->fetch_assoc(), $this->_db->query($sql), $this->_db->query($sql2)->fetch_all());
    } 


    /**
    * @author Yash
    * Add to wishlist in database table.
    * 
    * @param id of product. 
    * @return true/error if added in database or not.
    */

    public function addToWishlist($id)
    {
        $sql = "SELECT id 
                FROM wishlist 
                WHERE item_id = '".$id."' AND user_id = '".$_SESSION['id']."'";  

        if($this->_db->query($sql)->num_rows > 0){
            return false;
        }else{
            $sql = "INSERT INTO wishlist(item_id, user_id) 
                    VALUES('".$id."', '".$_SESSION['id']."')";

            if($this->_db->query($sql)){
                return true;
            }else{
                return "error";
            }    
        }
    }


    /**
    * @author Yash
    * Add to cart in session variable item.
    * 
    * @param id, quantity, size of product. 
    * @return true/false if added in session or not.
    */

    public function addToCart($id, $qty, $size)
    {   
        $sql = "SELECT item_image_url, name, price, value 
                FROM item_images 
                INNER JOIN item ON item.id = item_images.item_id 
                INNER JOIN attributes_options ON item.color_id = attributes_options.id 
                WHERE item.id = '".$id."' AND is_primary = '1';";

        $result = $this->_db->query($sql)->fetch_all();

        if (isset($_SESSION['item'])) {

            foreach ($_SESSION['item'] as $key => $value) {
                if($id === $value[0] && $size === $value[2]){
                    $flag = $key;
                }
            }

            if (isset($flag)) {
                $_SESSION['item'][$flag][3] = $_SESSION['item'][$flag][3]+$qty;
            }else{
                $_SESSION['item'][] = array($id, $result[0][1], $size, $qty, $result[0][2], $result[0][0], $result[0][3]);
            }
        }else{
            $_SESSION['item'][] = array($id, $result[0][1], $size, $qty, $result[0][2], $result[0][0], $result[0][3]);
        }
        

        if($result){
            return true;
        }else{
            return false;    
        }
    }


    /**
    * @author Yash
    * Delete from cart from session variable item.
    * 
    * @param id, size of product. 
    * @return true/false if deleted from session or not.
    */

    public function deleteFromPopup($id, $size)
    {   
        if (isset($_SESSION['item'])) {

            foreach ($_SESSION['item'] as $key => $value) {
                if($id === $value[0] && $size === $value[2]){
                    $flag = $key;
                }
            }

            if (isset($flag)) {
                if (count($_SESSION['item']) == 1) {
                    unset($_SESSION['item']);
                    $deleted = true;
                }else{                    
                    unset($_SESSION['item'][$flag]);
                    $deleted = true;
                }
            }else{
                $deleted = false;
            }
        }else{
            $deleted = false;
        }
        

        if($deleted){
            return $deleted;
        }else{
            return $deleted;    
        }
    }


    /**
    * @author Yash
    * Add to review in database table if already not exists.
    * 
    * @param id, rating-value, review-text of product. 
    * @return true/false if added in database or not.
    */

    public function addReview($id, $star, $text)
    {
        $sql = "SELECT id 
                FROM item_review 
                WHERE item_id = '".$id."' AND user_id = '".$_SESSION['id']."'";         

        if($this->_db->query($sql)->num_rows > 0){
            return false;
        }else{
            $sql = "INSERT INTO item_review(item_id, user_id, ratings, review_text) 
                    VALUES('".$id."', '".$_SESSION['id']."', '".$star."', '".$text."')";

            if($this->_db->query($sql)){
                return true;
            }else{
                return "error";
            }    
        }
    }


    /**
    * @author Yash
    * Get latest review of product from database.
    * 
    * @param id of product. 
    * @return array of query result with firstname of the user who has reviewed the product.
    */

    public function getReview($id)
    {        
        $sql = "SELECT user_id, review_text, review_date 
                FROM item_review 
                WHERE item_id = '".$id."' 
                ORDER BY review_date DESC 
                LIMIT 1";

        $result = $this->_db->query($sql)->fetch_assoc();

        $getuser = "SELECT firstname 
                    FROM user 
                    WHERE id = '".$result['user_id']."'";

        $user = $this->_db->query($getuser)->fetch_assoc();

        if(isset($user)){
            return array($result, $user);
        }else{
            return false;
        }   
    }


    /**
    * @author Yash
    * Get count of products for each category from database.
    * 
    * @return array of category name, id, count of products.
    */

    public function getCat()
    {
        $sql = "SELECT c.id, c.name, COUNT(ao_id) 
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN category c ON i.category_id = c.id 
                GROUP BY c.id 
                ORDER BY c.id;";

        $result = $this->_db->query($sql)->fetch_all();

        for ($i=0; $i <sizeof($result) ; $i++) {             
            $array[$result[$i][0]] = array($result[$i][1], $result[$i][2]);
        }
        return $array;
    }


    /**
    * @author Yash
    * Get count of products for each size from database.
    * 
    * @return array of size name, id, count of products.
    */

    public function getSize()
    {
        $sql = "SELECT id, value 
                FROM attributes_options 
                WHERE attribute_id = '1'
                ORDER BY id ASC;";

        $result = $this->_db->query($sql)->fetch_all();

        $count = "SELECT COUNT(ao_id) 
                  FROM item_options 
                  GROUP BY ao_id 
                  ORDER BY ao_id ASC;";

        $result1 = $this->_db->query($count)->fetch_all();

        for ($i=0; $i <sizeof($result) ; $i++) {             
            $arrayName[$result[$i][0]] = array($result1[$i][0], $result[$i][1]);
        }
        return $arrayName;
    }


    /**
    * @author Yash
    * Get min, max price of product and count of products for a range of price from database.
    * 
    * @return array of min price, max price, count of products.
    */

    public function getPrice()
    {
        $sql = "SELECT MIN(price) AS `min`, MAX(price) AS `max` 
                FROM item;";

        $result = $this->_db->query($sql)->fetch_assoc();

        $count = "SELECT COUNT(io.id) AS `items`
                  FROM item_options io 
                  LEFT JOIN item i ON io.item_id = i.id 
                  LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                  LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                  LEFT JOIN item_images ii ON i.id = ii.item_id 
                  WHERE is_primary = '1' AND price >= ".$result['min']." AND price <= ".$result['max'].";";

        $result1 = $this->_db->query($count)->fetch_assoc();

        return array($result, $result1);
    }


    /**
    * @author Yash
    * Get count of products for each color from database.
    * 
    * @return array of color name, id, count of products.
    */

    public function getColor()
    {
        $sql = "SELECT ao.id, ao.value, COUNT(io.item_id) 
                 FROM item_options io 
                 LEFT JOIN item i ON io.item_id = i.id 
                 RIGHT JOIN attributes_options ao ON i.color_id = ao.id 
                 WHERE ao.attribute_id = 2
                 GROUP BY ao.value 
                 ORDER BY ao.id ASC;";
        $result = $this->_db->query($sql)->fetch_all();     
        return $result;
    }


    /**
    * @author Yash
    * Get filtered products based on different params from database.
    * 
    * @param sizes, categories, price range, colors.
    * @return array of filtered product.
    */

    public function filter($sizestr, $catstr, $pricestr, $colorstr)
    {   
        $sql = "SELECT i.id, ii.item_image_url, i.name, i.price, ao.value, io.id AS `variation_id`, ao.id AS `ao.id`, ao2.value AS `color`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                LEFT JOIN item_images ii ON i.id = ii.item_id
                LEFT JOIN category c ON i.category_id = c.id 
                WHERE ii.is_primary = '1'";

        //if categories are included for filtering.        
        if ($catstr !== "") {
            $sql .= " AND (".$catstr.")";            
        }        

        //if sizes are included for filtering.
        if ($sizestr !== "") {
            $sql .= " AND (".$sizestr.")";            
        } 

        //if price range is set for filtering.
        if ($pricestr !== "") {
            $sql .= " AND (".$pricestr.")";            
        }

        //if colors are included for filtering.
        if ($colorstr !== "") {
            $sql .= " AND (".$colorstr.")";            
        }

        $result = $this->_db->query($sql)->fetch_all();
        return $result;
    }


    /**
    * @author Yash
    * Get searched products based on search.
    * 
    * @param string to search for.
    * @return array of searched products.
    */

    public function searchProducts($str)
    {
        $sql = "SELECT i.id, ii.item_image_url, i.name, i.price, ao.value, io.id AS `variation_id`, ao.id AS `ao.id`, ao2.value AS `color`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                LEFT JOIN item_images ii ON i.id = ii.item_id 
                LEFT JOIN category c ON i.category_id = c.id 
                WHERE (i.name LIKE '%".$str."%' ESCAPE '/') 
                GROUP BY variation_id 
                ORDER BY i.id ASC;";        

        $result = $this->_db->query($sql);   
        return $result;
    }


    /**
    * @author Yash
    * Get sorted products.
    * 
    * @param string to sort by.
    * @return array of sorted products.
    */

    public function sort($value)
    {   
        $sql = "SELECT i.id, ii.item_image_url, i.name, i.price, ao.value, io.id AS `variation_id`, ao.id AS `ao.id`, ao2.value AS `color`
                FROM item_options io 
                LEFT JOIN item i ON io.item_id = i.id 
                LEFT JOIN attributes_options ao ON io.ao_id = ao.id 
                LEFT JOIN attributes_options ao2 ON i.color_id = ao2.id 
                LEFT JOIN item_images ii ON i.id = ii.item_id
                LEFT JOIN category c ON i.category_id = c.id 
                GROUP BY variation_id
                ORDER BY ".$value." ASC;";

        $result = $this->_db->query($sql)->fetch_all();
        return $result;
    }
}
?>