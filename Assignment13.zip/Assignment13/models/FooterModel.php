<?php

class FooterModel extends basemodel {

    /* Table which is mapped to current model */
    private $_table = 'newsletter_subscriber';


    /**
    * @author Yash
    * Subscribes new users and mail about this to the user and admin.
    * 
    * @param user and admin emails. 
    * @return true/false if mails are sent or not.
    */
    
    public function NewsSubscriber($data) 
    {        
        $email = $data;

        $sql="SELECT id 
              FROM ".$this->_table." 
              WHERE email = '$email'";

        $result=$this->_db->query($sql);
        $flag = true;
        if($result->num_rows==0){

            $sql = "INSERT INTO ".$this->_table." (email) 
                    VALUES ('$email')";
        
            if ($this->_db->query($sql) == TRUE) {

                $get_admin = "SELECT email 
                              FROM user 
                              WHERE username = 'eshop__admin'";

                $result1 = $this->_db->query($get_admin);
                $row = mysqli_fetch_array($result1);
                $admin = $row["email"];

                $to = $email;
                $subject = "New Subscriber";
                $message = "Thank You for Subscription.";
                $headers = "From: no-reply@eShop.com" . "\r\n";

                if (mail($to,$subject,$message,$headers)) {
                    $flag = true;
                }else{
                    $flag = false;
                }

                $to1 = $admin;
                $subject1 = "New Subscriber";
                $message1 = "";
                $headers1 = "From: $email" . "\r\n";

                if (mail($to1,$subject1,$message1,$headers1)) {
                    $flag = true;
                }else{
                    $flag = false;
                }

                if($flag){
                    echo "<script>alert('Your have been Subscribed');window.location.href='".$_SERVER["HTTP_REFERER"]."'</script>"; 
                    return $flag;       
                }else{
                    echo "<script>alert('Something Went Wrong.Please Try Again.');window.location.href='".$_SERVER["HTTP_REFERER"]."'</script>";
                }                
            }else{
                echo "<script>alert('Something Went Wrong. Please Try Again.');window.location.href='".$_SERVER["HTTP_REFERER"]."'</script>"; 
            }  
        }else{
            echo "<script>alert('You are already Subscribed');window.location.href='".$_SERVER["HTTP_REFERER"]."'</script>";  
        }
        return $flag; 
    }
}
?>