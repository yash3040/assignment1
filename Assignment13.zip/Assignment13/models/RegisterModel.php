<?php

class RegisterModel extends basemodel {

    /* Table which is mapped to current model */
    private $_table = 'user';

    
    /**
    * @author Yash
    * To check email is uinque.
    * 
    * @param user email
    * @return true/false if unique or not.
    */

    public function checkEmailExist($email) 
    {
        if (!preg_match('/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/', $email)) {
            return "Invalid";
        }else{
            $sql = "SELECT id 
                    FROM " . $this->_table . " 
                    WHERE email='" . $email . "'";

            $result = $this->_db->query($sql);

            if ($result->num_rows > 0) {
                return true;
            }else {
                return false;
            }
        }    
    }


    /**
    * @author Yash
    * To check username is uinque.
    * 
    * @param user username
    * @return true/false if unique or not.
    */
    
    public function checkUsernameExist($username) 
    {
        if (!preg_match("/^[a-zA-Z0-9_-]{8,}$/", $username)) {
            return "Invalid";
        }else{
            $sql = "SELECT id 
                    FROM " . $this->_table . " 
                    WHERE username='" . $username . "'";

            $result = $this->_db->query($sql);

            if ($result->num_rows > 0) {
                return true;
            }else {
                return false;
            }
        }    
    }


    /**
    * @author Yash
    * To check user is agreed to rems and conditions.
    * 
    * @param is agreed checkbox data.
    * @return validation error if any occured.
    */
   
    public function isAgreed($data) 
    {
        if (!isset($data['is_agree'])) {
            $this->validationError['is_agree'] = 'Please agree terms and Condition Before Procedure further';
        }

        if (empty($this->validationError)) {
            return true;
        }else {
            return false;
        }
    }


    /**
    * @author Yash
    * To validate user data.
    * 
    * @param user data.
    * @return validation errors if any occured.
    */
    
    public function validate($data) 
    {        
        $this->processInput($data);

        if (!preg_match("/^[a-zA-Z0-9_-]{8,}$/", $this->data['inputUserName'])) {
            $this->validationError['username'] = "Enter a valid username";
        }elseif ($this->checkUsernameExist($this->data['inputUserName'])) {
            $this->validationError['username'] = "Username already exists";
        }

        if (isset($this->data['gender'])) {
            if (!in_array($this->data['gender'], array('Male', 'Female'))) {
                $this->validationError['gender'] = 'Please select your gender.';
            }
        }

        if (!preg_match("/^(?=.*[a-z])(?=(?:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/", $this->data['inputPassword']) && !preg_match("/^[a-f0-9]{32}$/i", $this->data['inputPassword'])) {
            $this->validationError['password'] = "Enter a valid password";
        }

        if (!($this->data['inputPassword2'] == $this->data['inputPassword'])) {
            $this->validationError['password2'] = "Enter same as password";
        }

        if (!preg_match('/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/', $this->data['inputEmail'])) {
            $this->validationError['email'] = "Enter a valid email";
        }elseif ($this->checkEmailExist($this->data['inputEmail'])) {
            $this->validationError['email'] = "Email already exists";
        }

        if (!preg_match("/^[A-Za-z]+$/", $this->data['inputFname'])) {
            $this->validationError['firstname'] = "Only alphabets";
        }

        if (!preg_match("/^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/", $this->data['inputMobNo'])) {
            $this->validationError['mobileno'] = "US format, with or without dashes";
        }

        if (!empty($this->data['inputPhone']) && !preg_match("/^\d{10}$/", $this->data['inputPhone'])) {
            $this->validationError['phone'] = "Please enter valid number";
        }

        if (!isset($_POST['all']) && !isset($_POST['opt1']) && !isset($_POST['opt2']) && !isset($_POST['opt3']) && !isset($_POST['optoth']))
        {
            $this->validationError['interest'] = "Please select anyone";
        }else if (isset($_POST['optoth']) && empty($this->othtxt)) {
            $this->validationError['interest'] = "Please enter your interest";
        }                    
        if ($this->validationError) {

            if(isset($_POST['all'])){
            $this->validationError['inputAllVal'] = isset($_POST['all']);
            }

            if(isset($_POST['opt1'])){
            $this->validationError['inputOneVal'] = isset($_POST['opt1']);
            }

            if(isset($_POST['opt2'])){
            $this->validationError['inputTwoVal'] = isset($_POST['opt2']);
            }

            if(isset($_POST['opt3'])){
            $this->validationError['inputThreeVal'] = isset($_POST['opt3']);
            }

            if(isset($_POST['optoth'])){
            $this->validationError['inputOtherVal'] = isset($_POST['optoth']);
            }
        }         

        if (empty($this->validationError)) {
            return true;
        } else {
            return false;
        }
    }


    /**
    * @author Yash
    * Welcome Mail to user.
    * 
    * @param user data. 
    * @return true/false if mail is sent or not.
    */

    public function NewUserMail($email, $fname, $lname)
    {
        $to = $email;
        $subject = "Welcome to eShop";
        $txt = "Hello, ".$fname." ".$lname."\nWelcome to eShop. The world's biggest online store for clothing and accessories";
        $headers = "From: no-reply@eshop.com" . "\r\n";

        if(mail($to,$subject,$txt,$headers)){
            return true;
        }
        else{
            return false;
        }
    }


    /**
    * @author Yash
    * To insert user data in database and send welcome mail.
    * 
    * @param user data
    * @return true/false if data inserted and mail sent or not.
    */
    
    public function insert($data) 
    {
        if ($this->validate($data)) {

            if ($this->isAgreed($data)) {     

                $sql = "INSERT INTO " . $this->_table . " (username, firstname,lastname, email, gender, password,mobile_number, phone_number,
                        is_active)
                  		VALUES ('" . $this->data['inputUserName'] . "', '" . $this->data['inputFname'] . "','" . $this->data['inputLname'] . "', '" . $this->data['inputEmail'] . "', '" . $this->data['gender'] . "', '" . md5($this->data['inputPassword']) . "','" . $this->data['inputMobNo'] . "','" . $this->data['inputPhone'] . "', '1')";

                if ($this->_db->query($sql) === TRUE) {
                    $this->NewUserMail($this->data['inputEmail'], $this->data['inputFname'], $this->data['inputLname']);
                    return true;
                }else {
                    return false;
                }                
            }else {
                return false;
            }
        }else {
            return false;
        }    
    }
}
?>