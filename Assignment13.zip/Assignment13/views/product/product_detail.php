<?php
    $assets_url = ASSETS_URL;
?>
<!--content-->

<!--banner-->
<section class="container-fluid banpad">
    <section class="row">
        <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">    
    </section>
</section><!--/.banner-->  

<!--breadcrumbs-->
<section class="container">           
    <h2 class="crt"><?php echo $item[0]['c_name'];?></h2>     
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb brdcrmb">
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>product">Men</a></li>
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>product/listing/<?php echo $item[0]['c_name'];?>"><?php echo $item[0]['c_name'];?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo $item[0]['name'];?></li>
        </ol>
    </nav>
</section><!--/.breadcrumbs-->  

<!--main-content-->
<section class="container">
    <!--wishlist-success-alert-->
    <div class="alert alert-success alert-dismissible alrtsuc collapse" id="alrtsuc" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <svg height="14" width="20">
            <image height="14" width="15"  href="<?php echo $assets_url;?>images/success.svg" />
        </svg>
        <?php echo $item[0]['name'];?> is added to your wishlist.
    </div><!--/.wishlist-success-alert-->
    <!--wishlist-error-alert-->
    <div class="alert alert-warning alert-dismissible alrtwarn collapse" id="alrtwarn" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <svg height="14" width="20">
            <image height="14" width="15"  href="<?php echo $assets_url;?>images/warning.svg" />
        </svg>
        <?php echo $item[0]['name'];?> is already in your wishlist.
    </div><!--/.wishlist-error-alert-->

    <!--zoom-effect-modal-->
    <div class="modal fade" id="enlargeImageModal" tabindex="-1" role="dialog" aria-labelledby="enlargeImageModal" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content" id="modal-content">
                <div class="modal-header" id="zoom-modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body">
                    <img src="" class="enlargeImageModalSource">
                </div>
            </div>
        </div>
    </div><!--/.zoom-effect-modal-->
    <section class="row">
        <!--images-section-->
        <section class="col-sm-5">
            <img src="<?php echo $assets_url;?>images/<?php echo str_replace(".jpg", "-big.jpg", $item[2][0][0]);?>" id="largeImage" class="img-responsive">
            <div class="row thumb">
                <div class="col-sm-12">
                    <div class="row">
                        <div class="col-xs-1 leftarr">
                            <a class="left" href="#myCarousel" data-slide="prev"><img src="<?php echo $assets_url;?>images/im.png" class="leftcurosal"></a>
                        </div>
                        <div class="col-xs-10" id="thumbs">
                            <div class="carousel detail slide" id="myCarousel">
                                <div class="carousel-inner">
                                    <?php
                                        echo '<div class="item active">
                                                <div class="col-xs-3">
                                                    <a><img src="'.$assets_url.'images/'.str_replace(".jpg", "-big.jpg", $item[2][0][0]).'" class="img-responsive"></a>
                                                </div>
                                              </div>';
                                        if (isset($item[2][1])) {
                                            $imgs = explode(",", $item[2][1][0]);
                                            foreach ($imgs as $key) {
                                            $img_url = str_replace(".jpg", "-big.jpg", $key);    
                                            echo '<div class="item">
                                                    <div class="col-xs-3">
                                                        <a><img src="'.$assets_url.'images/'.$img_url.'" class="img-responsive"></a>
                                                    </div>
                                                  </div>';               
                                            }
                                        }
                                    ?>
                                </div>                  
                            </div>
                        </div>          
                        <div class="col-xs-1 rightarr">
                            <a class="right" href="#myCarousel" data-slide="next"><img src="<?php echo $assets_url;?>images/im.png" class="rightcuosal"></a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--/.images-section-->
        
        <!--details-section-->
        <section class="col-sm-7">          
            <p class="dtlpghd" id="prdtnm"><?php echo $item[0]['name'];?></p>

            <p><?php echo $item[0]['short_desc'];?></p>

            <p>SKU: 
                <span class="mag209"><?php echo $item[0]['sku'];?></span>
            </p>

            <p>Availibility: 
                <span class="badge stck">In Stock</span> 
                <span class="badge notstck">Not Available</span>
            </p>

            <p class="text4big">&dollar;<?php echo $item[0]['price'];?>.00</p>

            <form>
                <div class="form-group">
                    <label for="inputSize<?php echo $itemid; ?>"><span class="error">*</span>Size</label>
                    <span class="error pull-right">* Required Fields</span>
                    <select id="inputSize<?php echo $itemid; ?>" class="form-control">
                        <?php 
                            foreach ($item[1] as $key) {
                                echo "<option value = '".$key['value']."'>".$key['value']."</option>";
                            }                
                        ?>
                    </select>
                </div>
            </form>
            <form class="form-inline">
                <div class="form-group">
                    <label for="inputqty<?php echo $itemid; ?>">Qty</label>    
                    <select id="inputqty<?php echo $itemid; ?>" class="form-control">
                        <option selected value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>s
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select>
                </div>
                <input type="hidden" name="price" id="price<?php echo $itemid; ?>" value="<?php echo $item[0]['price']; ?>">
                <button type="button" class="btn btn-default addcrt" <?php echo 'onclick="cnfrm('.$itemid.')"';?>>
                    <div class="cartsprt inline" aria-hidden="true"></div> <div class="inline">ADD TO CART</div>
                </button>
            </form><br>

            <input type="hidden" name="itemid" id="itemid<?php echo $itemid; ?>" value="<?php echo $itemid; ?>">
            <a class="addwish" name="addtowish" id="addtowish" data-toggle="collapse">Add to Wishlist</a>

            <div>
                <!-- Nav tabs -->
                <ul class="nav nav-pills" role="tablist">
                    <li role="presentation" class="active"><a href="#delivery" aria-controls="delivery" role="tab" data-toggle="tab">Delivery</a></li>
                    <li role="presentation"><a href="#shipping" aria-controls="shipping" role="tab" data-toggle="tab">Shipping</a></li>
                    <li role="presentation"><a href="#sizeguide" aria-controls="sizeguide" role="tab" data-toggle="tab">Sizeguide</a></li>
                </ul>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div role="tabpanel" class="tab-pane in active" id="delivery"><?php echo $item[0]['delivery_desc'];?></div>
                    <div role="tabpanel" class="tab-pane" id="shipping"><?php echo $item[0]['shipping_desc'];?></div>
                    <div role="tabpanel" class="tab-pane" id="sizeguide">
                        <?php echo $item[0]['sizeguide_desc'];?>
                    </div>
                </div>
            </div>
        </section><!--/.details-section-->
    </section><br><br>

    <div>
        <!-- Nav tabs -->
        <ul class="nav nav-pills" role="tablist">
            <li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Product Description</a></li>
            <li role="presentation"><a href="#review" aria-controls="review" role="tab" data-toggle="tab">Product's Review</a></li>
            <li role="presentation"><a href="#cms" aria-controls="cms" role="tab" data-toggle="tab">CMS Tab</a></li>
        </ul><!--/.Nav tabs -->

        <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane in active" id="description">
                <label>Sample Lorem Ipsum Text</label>
                <p><?php echo $item[0]['description'];?></p>  
            </div>
            <div role="tabpanel" class="tab-pane" id="review">
                <div class="rev"><a href="#wrtrev" data-toggle="collapse">Write a review</a></div>
                <div class="collapse" id="wrtrev">
                    <div class="starRating">
                        <input id="rating5" type="radio" name="rating" value="5">
                        <label for="rating5">5</label>
                        <input id="rating4" type="radio" name="rating" value="4">
                        <label for="rating4">4</label>
                        <input id="rating3" type="radio" name="rating" value="3">
                        <label for="rating3">3</label>
                        <input id="rating2" type="radio" name="rating" value="2">
                        <label for="rating2">2</label>
                        <input id="rating1" type="radio" name="rating" value="1">
                        <label for="rating1">1</label>
                    </div>
                    <textarea class="form-control" id="inputreview" rows="5" placeholder="Write a review."></textarea><br>
                    <button type="submit" name="ratingsubmit" id="ratingsubmit" class="btn btn-default btnr2">Submit</button>
                </div><br>
                <label id="currentlabel">
                    <?php 
                        $date1 = getdate();
                        $str = $date1['mday']." ".$date1['month']." ".$date1['year'];
                        $time1 = strtotime($str);
                        $date2 = date('d/m/Y',$time1);
                        echo $_SESSION['fname'].", ".$date2." writes:";
                    ?>          
                </label>
                <p id="currentp"></p>
                <?php
                    if (isset($review[0]['review_text'])) {
                        echo '<label id="reviewlabel">';
                        $time = strtotime($review[0]['review_date']);
                        $date = date('d/m/Y',$time);
                        echo $review[1]['firstname'].", ".$date." writes:";       
                        echo "</label>";
                        echo '<p id="reviewp">'.$review[0]['review_text'].'</p>';
                    }else{
                        echo "<label id='noreview'>No reviews Yet.</label>";
                    } 
                ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="cms">CMS Tab</div>
        </div><!--/.Tab panes -->
    </div>
</section><br><br><!--/.main-content-->

<!--script-->
<script>      
    //for carousel of images.
    $(document).ready(function() {
        if (document.documentElement.clientWidth > 767) {
            $('.detail .item').each(function() {
                var next = $(this).next();
                if (!next.length) {
                    next = $(this).siblings(':first');
                }
                next.children(':first-child').clone().appendTo($(this));

                for (var i = 0; i < 2; i++) {
                    next = next.next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }

                    next.children(':first-child').clone().appendTo($(this));
                }
            });

            $('#thumbs img').click(function() {
                $('#largeImage').attr('src', $(this).attr('src'));
                $('#description').html($(this).attr('alt'));
            });
        } else {
            $(".item div").toggleClass("col-xs-3");
            $(".item div").toggleClass("col-xs-4");
            $('.detail .item').each(function() {
                var next = $(this).next();
                if (!next.length) {
                    next = $(this).siblings(':first');
                }
                next.children(':first-child').clone().appendTo($(this));

                for (var i = 0; i < 1; i++) {
                    next = next.next();
                    if (!next.length) {
                        next = $(this).siblings(':first');
                    }

                    next.children(':first-child').clone().appendTo($(this));
                }
            });
            $('#thumbs img').click(function() {
                $('#largeImage').attr('src', $(this).attr('src'));
                $('#description').html($(this).attr('alt'));
            });
        }

        $(window).resize(function() {
            window.location = window.location;
        });
    })
</script><!--/.script--><!--/.content-->