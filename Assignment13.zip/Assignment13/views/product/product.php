<?php
    $assets_url = ASSETS_URL;
?>
<!--content-->

<!--banner-->
<section class="container-fluid banpad">
    <section class="row">
        <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">    
    </section>
</section><!--/.banner-->  

<!--breadcrumbs-->
<section class="container">           
    <h2 class="crt"><?php echo isset($name) ? "Men" : "Products";?></h2>      
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb brdcrmb">
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>product"><?php echo isset($name) ? "Men" : "Products";?></a></li>
            <?php echo isset($name) ? '<li class="breadcrumb-item active" aria-current="page">'.$name.'</li>' : '';?>
        </ol>
    </nav>
</section><!--/.breadcrumbs-->  

<!--main-content-->
<section class="container listouter">
    <section class="row listinner">
        <!--filter-->
        <section class="col-sm-3">
            <div class="fltrdiv">
                <p class="fltr panel-heading">FILTER BY</p>
                <div class="panel-group" role="tablist" aria-multiselectable="true">
                    <div class="panel panel-default pnldef">
                        <div class="panel-heading pnlhdbg" role="tab" id="category">
                            <h4 class="panel-title">
                                <a role="button" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                    <div class="row">
                                        <div class="col-md-10 col-sm-9 col-xs-10">CATEGORIES</div>
                                        <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                                    </div>                      
                                </a>
                            </h4>
                        </div>
                        <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="category">
                            <div class="panel-body bdytop">
                                <form id="catform">
                                  <?php
                                    if(isset($name)){
                                      foreach ($cat as $key => $value) {
                                        echo '<div class="checkbox">
                                                <label><input type="checkbox" class="catbox" value="'.$key.'"';
                                        echo ($name == $value[0]) ? "checked" : "disabled" ;
                                        echo '>'.$value[0].' ('.$value[1].')</label>
                                              </div>';       
                                      }
                                    }else{
                                      foreach ($cat as $key => $value) {
                                        echo '<div class="checkbox">
                                                <label><input type="checkbox" class="catbox" value="'.$key.'">'.$value[0].' ('.$value[1].')</label>
                                              </div>';       
                                      }
                                    }
                                  ?>
                                </form> 
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default pnldef">
                        <div class="panel-heading pnlhdbg" role="tab" id="color">
                            <h4 class="panel-title">
                                <a role="button" data-toggle="collapse" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
                                    <div class="row">
                                        <div class="col-md-10 col-sm-9 col-xs-10">COLOUR</div>
                                        <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                                    </div>
                                </a>
                            </h4>
                        </div>
                        <div id="collapseTwo" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="color">
                            <div class="panel-body bdytop">
                                <div class="table-responsive colrdiv">          
                                    <table class="table">
                                        <tbody class="tdbord0">
                                          <?php
                                            foreach ($color as $key => $value) {
                                              echo '<tr>
                                                      <td class="tdcol">
                                                        <div class="'.$value[1].'"></div>
                                                      </td>
                                                      <td class="tdcol2">
                                                        <label class="'.$key.'"><input type="checkbox" class="colorbox" number="'.$key.'" value="'.$value[0].'" hidden>'.$value[1].' ('.$value[2].')</label>
                                                      </td>
                                                    </tr> ';
                                            }
                                          ?>
                                            <tr>
                                                <td></td>
                                                <td><a class="text4 reset1" title="Reset all the filters">Reset</a></td>
                                            </tr>           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default pnldef">
                        <div class="panel-heading pnlhdbg" role="tab" id="price">
                            <h4 class="panel-title">
                                <a role="button" data-toggle="collapse" href="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
                                    <div class="row">
                                        <div class="col-md-10 col-sm-9 col-xs-10">PRICE</div>
                                        <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                                    </div>
                                </a>
                            </h4>
                        </div>
                        <div id="collapseThree" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="price">
                            <div class="panel-body bdytop">
                                <p class="text-center"><?php echo $price[1]['items'];?> items</p>
                                <input type="text" id="priceslider" name="priceslider" value="" data-min="<?php echo $price[0]['min'];?>" data-max="<?php echo $price[0]['max'];?>"/>
                                <div class="row">
                                    <div class="col-xs-7">&dollar;<?php echo $price[0]['min'];?>
                                    </div>
                                    <div class="col-xs-5">
                                        <div class="pull-right"> &dollar;<?php echo $price[0]['max'];?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default pnldef">
                        <div class="panel-heading pnlhdbg" role="tab" id="size">
                            <h4 class="panel-title">
                                <a role="button" data-toggle="collapse" href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">
                                    <div class="row">
                                        <div class="col-md-10 col-sm-9 col-xs-10">SIZE</div>
                                        <div class="col-md-2 col-sm-3 col-xs-2"><div class="closesprite"></div></div>
                                    </div>
                                </a>
                            </h4>
                        </div>
                        <div id="collapseFour" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="size">
                            <div class="panel-body bdytop">
                                <form id="sizeform">
                                  <?php
                                    foreach ($size as $key => $value) {
                                      echo '<div class="checkbox">
                                              <label><input type="checkbox" class="sizebox" value="'.$key.'">'.$value[1].' ('.$value[0].')</label>
                                            </div>';       
                                    }
                                  ?>
                                </form> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>  

            <div class="promo">
                <img src="<?php echo $assets_url;?>images/promo2.jpg" alt="promo2">          
            </div><br><br>
        </section><!--/.filter-->
        
        <!--listing-->
        <section class="col-sm-9">

            <div class="row">
                <div class="col-sm-12">
                  <?php 
                    if (isset($name)) {
                        echo '<p class="men">Men '.$name.'</p>';
                    }else if (isset($string)) {
                        echo '<p class="men">Search Results for "'.$string.'"</p>';
                    }else{
                        echo '<p class="men">Products</p>';
                    }
                  ?>
                </div>
            </div>

            <?php 
            if (isset($none)) {?>
                <div class="text-center"><p class="text4">No products having <?php echo $string;?> in their names.</p></div>
            <?php
            }else{?>
            

            <div class="row">
                <div class="col-sm-12">
                    <div class="pull-right">
                        Sort By
                        <select id="sort">
                            <option value="0" selected>--Please Select--</option>
                            <option value="name">Name</option>
                            <option value="price">Price</option>
                        </select><br>       
                    </div>              
                </div>
            </div><br>
            <div class="outerdiv">
                <div class="listdiv">
                    <!--loading-image-->
                    <img class="load" src="<?php echo $assets_url.'images/loading.svg';?>">
                    <!--/.loading-image-->
                    <?php
                      while($row = mysqli_fetch_object($result)){
                        echo '<section class="col-sm-4 same-height">
                                <div class="thumbnail itembox">
                                  <div class="imgcont">   
                                    <a href="'.SITE_URL.'product/details/'.$row->id.'" class="nodeco">
                                     <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                                     <div class="hvrbut">
                                    </a>
                                    <button class="but btn btn-default" onclick="cnfrm('.$row->variation_id.')">ADD TO CART</button>
                                    <input type="hidden" id="inputSize'.$row->variation_id.'" value="'.$row->value.'">
                                    <input type="hidden" id="inputqty'.$row->variation_id.'" value="1">
                                    <input type="hidden" id="price'.$row->variation_id.'" value="'.$row->price.'">
                                    <input type="hidden" id="itemid'.$row->variation_id.'" value="'.$row->id.'">
                                   </div>
                                  </div>
                                  <a href="'.SITE_URL.'product/details/'.$row->id.'" class="nodeco">
                                   <div class="caption">
                                    <p class="text3">'.$row->name.'</p>
                                    <p class="text4">$'.$row->price.'</p>                   
                                   </div>
                                  </a>
                                </div>
                              </section>';  
                      }             
                    ?>
                </div>
            </div>
            <br><br>

            <?php
              if (!isset($name) && !isset($no)) {
                  echo '<div class="col-sm-12 text-center"><button type="button" class="btn btn-default btnd" id="morelist">More Products</button></div>';
              }
            ?>
        </section><!--/.listing-->
        <?php
        }
        ?>
    </section>
</section><br><br><!--/.main-content--><!--/.content-->