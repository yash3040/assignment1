<?php
    $assets_url = ASSETS_URL;
?>
<!-- Footer -->
<footer class="footback">
    <section class="container">
        <div class="row">
            <div class="col-sm-12 subscribe">
                 <p>Thank you for your subscription</p>
            </div>
        </div>
        <section class="row">
            <section class="col-sm-12">
                <center>
                    <form class="form-inline" id="NewsletterForm" action="" method="post" onsubmit="return newsvalid();">
                        <div class="form-group"> 
                            <label for="inputNewsEmail" class="subscribe">Subscribe for Newsletter</label>  
                            <input type="email" class="form-control formbot" id="inputNewsEmail" name="inputNewsEmail" placeholder="Enter your email address">      
                            <button type="submit" id="news_submit" name="news_submit" class="btn btn-default btnr2">SIGN UP</button>
                            <p class="addwish" id="newsmailp"></p> 
                        </div>
                    </form>
                    <div class="menu-outer">
                        <div class="table">
                            <ul id="horizontal-list">
                                <li class="forhov"><a href="<?php echo SITE_URL;?>">Home</a></li>
                                <li class="forhov"><a href="<?php echo SITE_URL.'about_us';?>">About Us</a></li>
                                <?php
                                    if (!isset($_SESSION['id'])) {                
                                        echo '<li class="forhov"><a href="'.SITE_URL.'register">Register</a></li>';
                                    }
                                ?>
                                <li class="forhov"><a href="<?php echo SITE_URL.'contact';?>">Contact Us</a></li>
                            </ul>
                        </div>
                        <p class="textlast">
                            &copy; 2017 eShopper online store.All rights reserved.
                        </p>
                    </div>
                </center>
            </section>
        </section>
    </section>
</footer><!--/.footer--> 

<!--Move to top button-->
<a href="" class="topbut">
    <svg width="50" height="50">
        <image width="30" height="30" href="<?php echo $assets_url;?>/images/up-arrow-white.svg" />
    </svg>  
</a>

<!--Login Modal-->
<div class="popup-outer">
    <div class="modal fade <?php echo (isset($login_error_msg) ? 'in' :''); ?>" id="Login-popup" tabindex="-1" role="dialog" aria-hidden="true" style="display:<?php echo (isset($login_error_msg) ? 'block' :''); ?>">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h2 class="text-center">eShopper Login</h2>
                </div>
                <div class="modal-body">
                    <div class="alert alert-dismissible alert-danger login_alert" role="alert" style="display:none">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                        </button>                        
                        <span class="login_msg"></span>
                    </div>
                    <form class="loginform" action="" method="post" name="loginform" id="login_form">
                        <div class="form-group <?php echo (isset($login_error_msg) ? 'validation-error' : ''); ?>">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" placeholder="Enter your Username" name="login[email]">
                        </div>
                        <div class="form-group <?php echo (isset($login_error_msg) ? 'validation-error' : ''); ?>">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control" placeholder="Enter your Password" name="login[password]">
                        </div>
                        
                        <div class="form-group clearfix login-options">
                            <button type="submit" class="btn btn-default btnr2" id="login_button">Login</button>
                            <p>Not a Member? <a href="<?php echo SITE_URL . 'register';?>" title="Register">Register</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div><!-- /.modal -->

<!--script-->
<script>
    //homepage banner transition effects.
    var jssor_1_SlideoTransitions = [
        {$Duration:200,x:-1,y:1,$Delay:50,$Cols:10,$Rows:5,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Left:$Jease$.$InQuart,$Top:$Jease$.$InQuart,$Opacity:$Jease$.$Linear},$Opacity:2},
        {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationZigZag,$Easing:$Jease$.$OutQuad,$Opacity:2},
        {$Duration:500,x:1,y:-1,$Delay:40,$Cols:10,$Rows:5,$SlideOut:true,$ChessMode:{$Column:3,$Row:12},$Easing:{$Left:$Jease$.$InCubic,$Top:$Jease$.$InCubic,$Opacity:$Jease$.$OutQuad},$Opacity:2},
        {$Duration:1600,y:-1,$Delay:40,$Cols:24,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:$Jease$.$OutJump,$Round:{$Top:1.5}},
        {$Duration:600,$Delay:20,$Cols:8,$Rows:4,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Assembly:2050,$Opacity:2},
        {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:$Jease$.$OutQuad,$Opacity:2,$Assembly:2049},
        {$Duration:1000,x:-0.2,$Delay:20,$Cols:16,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:{$Left:$Jease$.$InOutExpo,$Opacity:$Jease$.$InOutQuad},$Assembly:260,$Opacity:2,$Outside:true,$Round:{$Top:0.5}},
        {$Duration:600,$Delay:40,$Rows:10,$Clip:8,$Move:true,$Formation:$JssorSlideshowFormations$.$FormationCircle,$Easing:$Jease$.$InBounce,$Assembly:264},
        {$Duration:800,x:1,$Delay:40,$Cols:6,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:{$Left:$Jease$.$InOutQuart,$Opacity:$Jease$.$Linear},$Opacity:2,$ZIndex:-10,$Brother:{$Duration:800,x:1,$Delay:40,$Cols:6,$Formation:$JssorSlideshowFormations$.$FormationStraight,$Easing:{$Left:$Jease$.$InOutQuart,$Opacity:$Jease$.$Linear},$Opacity:2,$ZIndex:-10,$Shift:-60}},                  
        {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Formation:$JssorSlideshowFormations$.$FormationSwirl,$Easing:$Jease$.$OutQuad,$Opacity:2},
        {$Duration:400,$Delay:50,$Rows:7,$Clip:4,$Formation:$JssorSlideshowFormations$.$FormationStraight},
        {$Duration:500,$Delay:12,$Cols:10,$Rows:5,$Clip:15,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Clip:$Jease$.$InSine},$Opacity:2,$Assembly:2050},
        {$Duration:500,x:-1,$Delay:40,$Cols:10,$Rows:5,$SlideOut:true,$Easing:{$Left:$Jease$.$InCubic,$Opacity:$Jease$.$OutQuad},$Opacity:2},
        {$Duration:500,$Delay:40,$Cols:10,$Rows:5,$Clip:15,$SlideOut:true,$Easing:$Jease$.$OutQuad,$Opacity:2},
        {$Duration:600,y:-1,$Cols:12,$Formation:$JssorSlideshowFormations$.$FormationStraight,$ChessMode:{$Column:12},$Easing:$Jease$.$InCubic,$Opacity:2},
        {$Duration:600,$Delay:40,$Cols:16,$Clip:1,$Move:true,$Formation:$JssorSlideshowFormations$.$FormationCircle,$Easing:$Jease$.$InBounce,$Assembly:264},
        {$Duration:200,x:-1,y:1,$Delay:50,$Cols:10,$Rows:5,$Formation:$JssorSlideshowFormations$.$FormationStraightStairs,$Easing:{$Left:$Jease$.$InQuart,$Top:$Jease$.$InQuart,$Opacity:$Jease$.$Linear},$Opacity:2},    
    ];

    //homepage banner initialization.
    var jssor_1_options = {
        $AutoPlay: 1,
        $SlideDuration: 800,
        $SlideEasing: $Jease$.$OutQuint,
        $Cols: 1,
        $Align: 0,
        $CaptionSliderOptions: {
          $Class: $JssorCaptionSlideo$,
          $Transitions: jssor_1_SlideoTransitions
        },
        $ArrowNavigatorOptions: {
          $Class: $JssorArrowNavigator$
        },
        $SlideshowOptions: {
          $Class: $JssorSlideshowRunner$,
          $Transitions: jssor_1_SlideoTransitions,
          $TransitionsOrder: 0,
        }
    };

    var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

    /*#region responsive code begin*/
    var MAX_WIDTH = 3000;

    function ScaleSlider() {
        var containerElement = jssor_1_slider.$Elmt.parentNode;
        var containerWidth = containerElement.clientWidth;

        if (containerWidth) {
            var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);
            jssor_1_slider.$ScaleWidth(expectedWidth);
        }
        else {
           window.setTimeout(ScaleSlider, 30);
        }
    }

    ScaleSlider();

    $(window).bind("load", ScaleSlider);
    $(window).bind("resize", ScaleSlider);
    $(window).bind("orientationchange", ScaleSlider);
</script><!--/.script-->

</body>

</html>