<?php
    $assets_url = SITE_URL . '/public/';
?>
<!--content-->

<!--banner-->
<section class="container-fluid banpad">
    <section class="row">
        <img src="<?php echo $assets_url;?>images/inner-banner.jpg" class="abtban img-responsive">   
    </section>
</section><!--/.banner-->  

<!--breadcrumbs-->
<section class="container">                     
    <h2 class="crt">Update Profile</h2>         
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb brdcrmb">
            <li class="breadcrumb-item"><a href="<?php echo SITE_URL;?>">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Profile</li>
        </ol>
    </nav>
</section><!--/.breadcrumbs-->  

<!--main-content-->
<form id="prflform" action="" method="post" onsubmit="return !!(valid() & prfl());">
    <section class="container bordbot">         
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputUserName">Username</label>
                    <input type="text" class="form-control" id="inputUserName" name="profile[inputUserName]" value="<?php echo $user['username'];?>" title="minimum 8 charcters and alphanumeric and - _ allowed" readonly>
                    <p id="unamep" class="addwish"><?php echo (isset($validationErrors['username'])) ? $validationErrors['username'] : ''; ?></p>
                </div>
            </div>

            <div class="col-sm-6">
                <b>Gender</b></br>
                <label class="radio-inline">
                    <input type="radio" name="profile[gender]" id="male" value="Male" <?php if($user['gender'] == 'Male'){echo 'checked';}?> >Male
                </label>
                <label class="radio-inline">
                    <input type="radio" name="profile[gender]" id="female" value="Female" <?php if($user['gender'] == 'Female'){echo 'checked';}?> >Female
                </label>
                <p class="addwish" id="gndrp"><?php echo (isset($validationErrors['gender'])) ? $validationErrors['gender'] : ''; ?></p>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputPassword">Password</label>
                    <input type="password" class="form-control" id="inputPassword" name="profile[inputPassword]" value="<?php echo $user['password'];?>" title="at least one number,special,lowercase character and 2 uppercase characters" readonly>
                    <p class="addwish" id="passp"><?php echo (isset($validationErrors['password'])) ? $validationErrors['password'] : ''; ?></p>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputPassword2">Confirm Password</label>
                    <input type="password" class="form-control" id="inputPassword2" name="profile[inputPassword2]" value="<?php echo $user['password'];?>" title="same as your password" readonly>
                    <p class="addwish" id="passp2"><?php echo (isset($validationErrors['password2'])) ? $validationErrors['password2'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputEmail">Email</label>
                    <input type="email" class="form-control prflmail" id="inputEmail" name="profile[inputEmail]" value="<?php echo $user['email'];?>" title="standard email">
                    <p class="addwish" id="mailp"><?php echo (isset($validationErrors['email'])) ? $validationErrors['email'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputFname">First Name</label>
                    <input type="text" class="form-control" id="inputFname" name="profile[inputFname]" value="<?php echo $user['firstname'];?>" title="Only alphabets">
                    <p class="addwish" id="fnamep"><?php echo (isset($validationErrors['firstname'])) ? $validationErrors['firstname'] : ''; ?></p>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputMobNo">Mobile No.</label>
                    <input type="text" class="form-control" id="inputMobNo" name="profile[inputMobNo]" value="<?php echo $user['mobile_number'];?>" title="US format, with or without dashes">
                    <p class="addwish" id="mobp"><?php echo (isset($validationErrors['mobileno'])) ? $validationErrors['mobileno'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputLname">Last Name</label>
                    <input type="text" class="form-control" id="inputLname" name="profile[inputLname]" value="<?php echo $user['lastname'];?>" title="Only alphabets">
                    <p class="addwish" id="lnamep"></p>
                </div>
            </div>
            
            <div class="col-sm-6">
                <div class="form-group">
                    <label for="inputPhone">Phone</label>
                    <input type="text" class="form-control" id="inputPhone" name="profile[inputPhone]" value="<?php echo $user['phone_number'];?>" title="Only 10 digits">
                    <p class="addwish" id="phonep"><?php echo (isset($validationErrors['phone'])) ? $validationErrors['phone'] : ''; ?></p>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-sm-12">
                <b>Interests</b>
                <div class="checkbox">
                    <label><input type="checkbox" value="" id="all" name="profile[all]" onclick="allcheck()">Select All</label>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" value="" id="opt1" name="profile[opt1]" onclick="indicheck()">Option 1</label>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" value="" id="opt2" name="profile[opt2]" onclick="indicheck()" checked>Option 2</label>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" value="" id="opt3" name="profile[opt3]" onclick="indicheck()">Option 3</label>
                </div>
                <div class="checkbox">
                    <label><input type="checkbox" value="" id="optoth" name="profile[optoth]" onclick="indicheck()">Other
                        <input type="text" value="" id="checktxt" name="profile[checktxt]" readonly>
                    </label>
                    <p class="addwish" id="checkp"><?php if(isset($validationErrors['interest'])){echo $validationErrors['interest'];} ?></p>
                </div>
            </div>
        </div>
        
        <section class="row">
            <div class="col-sm-6">
                <button class="btn btn-default btnd" type="button" data-toggle="collapse" data-target="#billcollapse">
                  Edit Billing Address
                </button>
                <div class="collapse<?php if(isset($address[0]['street']) || isset($validationErrors)){echo ' in';}else{echo '';}?>" id="billcollapse">
                    <div class="well">
                        <div class="form-group">
                            <label for="inputStreet">Street</label>                             
                            <input type="text" class="form-control" id="inputStreet" name="profile[inputStreet]" value="<?php echo $address[0]['street'];?>" placeholder="Please enter your Street">
                            <p class="addwish" id="strtp"><?php if(isset($validationErrors['street'])){echo $validationErrors['street'];} ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputCity">City</label>
                            <input type="text" class="form-control" id="inputCity" name="profile[inputCity]" value="<?php echo $address[0]['city'];?>" placeholder="Please enter your City">
                            <p class="addwish" id="ctyp"><?php if(isset($validationErrors['city'])){echo $validationErrors['city'];} ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputCountry">Country</label>
                            <select id="inputCountry" name="profile[inputCountry]" class="form-control">
                                <?php 
                                    echo '<option value="">Select Country</option>';
                                    while($row2=mysqli_fetch_object($country[0])){
                                
                                        if(isset($address[0]['country']) && $row2->id == $address[0]['country_id']){
                                            echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
                                        }
                                        else{                               
                                            echo "<option value='".$row2->id."'>".$row2->name."</option>";
                                        }
                                    }
                                ?>      
                            </select>
                            <p class="addwish" id="cntryp"><?php if(isset($validationErrors['country'])){echo $validationErrors['country'];} ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputState">State</label>
                            <select id="inputState" name="profile[inputState]" class="form-control">                            
                            </select>
                            <p class="addwish" id="sttp"><?php if(isset($validationErrors['state'])){echo $validationErrors['state'];} ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6">
                <button class="btn btn-default btnd" type="button" data-toggle="collapse" data-target="#shipcollapse">
                  Edit Shipping Address
                </button>
                <label class="chekbill"><input type="checkbox" id="sameadd" name="profile[sameadd]" onclick="cpyadd()" <?php if(isset($address[0]['street']) && $address[0]['street'] == $address[1]['street'] && $address[0]['city'] == $address[1]['city']){echo "checked";}else{echo "";}?>>Same as Billing Address</label>
                <div class="collapse<?php if(isset($address[1]['street']) || isset($validationErrors)){echo ' in';}else{echo '';}?>" id="shipcollapse">
                    <div class="well">
                        <div class="form-group">
                            <label for="inputStreet2">Street</label>
                            <input type="text" class="form-control" id="inputStreet2" name="profile[inputStreet2]" value="<?php echo $address[1]['street'];?>" placeholder="Please enter your Street" <?php if(isset($address[0]['street']) && $address[0]['street'] == $address[1]['street'] && $address[0]['city'] == $address[1]['city']){echo "readonly";}else{echo "";}?>>
                            <p class="addwish" id="strt2p"><?php if(isset($validationErrors['street2'])){echo $validationErrors['street2'];} ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputCity2">City</label>
                            <input type="text" class="form-control" id="inputCity2" name="profile[inputCity2]" value="<?php echo $address[1]['city'];?>" placeholder="Please enter your City" <?php if(isset($address[0]['street']) && $address[0]['street'] == $address[1]['street'] && $address[0]['city'] == $address[1]['city']){echo "readonly";}else{echo "";}?>>
                            <p class="addwish" id="cty2p"><?php if(isset($validationErrors['city2'])){echo $validationErrors['city2'];} ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputCountry2">Country</label>
                            <select id="inputCountry2" name="profile[inputCountry2]" class="form-control" <?php if(isset($address[0]['street']) && $address[0]['street'] == $address[1]['street'] && $address[0]['city'] == $address[1]['city']){echo "disabled";}else{echo "";}?>>
                                <?php 
                                    echo '<option value="">Select Country</option>';
                                    while($row2=mysqli_fetch_object($country[1])){
                                
                                       if(isset($address[1]['country']) && $row2->id == $address[1]['country_id']){
                                            echo "<option value='".$row2->id."' selected>".$row2->name."</option>";
                                        }                                   
                                        else{                               
                                            echo "<option value='".$row2->id."'>".$row2->name."</option>";
                                        }
                                    }
                                ?>
                            </select>
                            <p class="addwish" id="cntry2p"><?php if(isset($validationErrors['country2'])){echo $validationErrors['country2'];} ?></p>
                        </div>
                        <div class="form-group">
                            <label for="inputState2">State</label>
                            <select id="inputState2" name="profile[inputState2]" class="form-control" <?php if(isset($address[0]['street']) && $address[0]['street'] == $address[1]['street'] && $address[0]['city'] == $address[1]['city']){echo "disabled";}else{echo "";}?>></select>
                            <p class="addwish" id="stt2p"><?php if(isset($validationErrors['state2'])){echo $validationErrors['state2'];} ?></p>
                        </div>
                    </div>
                </div>                  
            </div>
        </section>
    </section>  

    <section class="container toppad">
        <section class="row botpad">
            <div class="col-sm-12">
                <div class="pull-right">
                    <button type="submit" id="update" name="profile[update]" class="btn btn-default btnr2">Update</button>       
                </div>
            </div>
        </section>
    </section>
</form><!--/.main-content--><!--/.content-->