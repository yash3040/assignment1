<?php

class Home extends BaseController {    

	/**
	* @author Yash
	* Default method of Home controller and load header,main content,footer view.
	* With implementing newsletter functionality in footer.  
	*/

	public function index() 
	{
	 	$this->load_model("HeaderModel");
	  	$cat['cat'] = $this->headermodel->getParCategories();
	  	$cat['title'] = "eShopper - Homepage";

	  	$this->load_model('HomeModel');        
	  	$result['result'] = $this->homemodel->TrendingItems(4);        

	  	$this->load_view('header', $cat);    
	  	$this->load_view('home', $result);  

	  	$this->load_model("FooterModel");

	      //For newsletter functionality.
	  	if (isset($_POST['news_submit'])) {
	  		$mail = $_POST['inputNewsEmail'];
	  		$flag = $this->footermodel->NewsSubscriber($mail);          
	  		$this->load_view('footer', $flag);
	  	}else{              
	  		$this->load_view('footer');
	  	}  
	}


	/**
	* @author Yash
	* Function to display more trending products.  
	*/

	public function moreTrendProds() 
	{

	  	$this->load_model('HomeModel');

	  	if (isset($_POST['limit'])) {
	  		$assets_url = ASSETS_URL;
	  		$result = $this->homemodel->TrendingItems($_POST['limit']); 
	  		$rows = mysqli_num_rows($result);
	  		if ($_POST['limit'] > $rows) {
  		    	echo '<script>$("#moretrends").hide();</script>';
  		    }
	    	while($row = mysqli_fetch_object($result)){
  				echo '<section class="col-sm-3 same-height">
		  				<div class="thumbnail itembox">
			  				<div class="imgcont">   
				  				<a href="'.SITE_URL.'product/details/'.$row->id.'" class="nodeco">
				  					<img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
				  				</a>
				  				<div class="hvrbut">
					  				<button class="but btn btn-default" onclick="cnfrm('.$row->variation_id.')">ADD TO CART</button>
					  				<input type="hidden" id="inputSize'.$row->variation_id.'" value="'.$row->value.'">
					  				<input type="hidden" id="inputqty'.$row->variation_id.'" value="1">
					  				<input type="hidden" id="price'.$row->variation_id.'" value="'.$row->price.'">
					  				<input type="hidden" id="itemid'.$row->variation_id.'" value="'.$row->id.'">
				  				</div>
			  				</div>
			  				<a href="'.SITE_URL.'product/details/'.$row->id.'" class="nodeco">
				  				<div class="caption">
					  				<p class="text3">'.$row->name.'</p>
					  				<p class="text4">$'.$row->price.'</p>                   
				  				</div>
			  				</a>
		  				</div>
  					  </section>';    
	  		}           		       
	  	}
	}


	/**
	* @author Yash
	* Function to display search results.  
	*/

	public function searchSuggestion()
	{
	  	$assets_url = ASSETS_URL;
	  	$string = $_POST['string'];

	  	if (strlen($string) == 0) {
	  		echo '<li><a>Enter Something to search</a></li>';
	  	}else{
	  		$string = trim($string);
	  		$string = stripslashes($string);
	  		$string = htmlspecialchars($string);
	  		$string = str_replace("_", "/_", $string);
	  		$string = str_replace("%", "/%", $string);

	  		$this->load_model("HomeModel");
	  		$result = $this->homemodel->searchProds($string);

	  		if($result[0]->num_rows > 0 || $result[1]->num_rows > 0){
	  			if($result[0]->num_rows > 0){
					//Showing categories
	  				echo '<li><a class="text4">Categories</a></li>';  
	  				while($row = mysqli_fetch_object($result[0])){
	  					$lower = str_replace(' ', '_', strtolower($row->cat_name));
	  					echo '<li><a class="srcha" href="'.SITE_URL.'product/listing/'.$lower.'">'.$row->cat_name.'</a></li>';  
	  				}
	  			}
	  			if($result[1]->num_rows > 0){
					//Showing products
	  				echo '<li><a class="text4">Products</a></li>';  
	  				while($row = mysqli_fetch_object($result[1])){
	  					echo '<li><a class="srcha" href="'.SITE_URL.'product/details/'.$row->id.'">'.$row->item_name.'</a></li>';  
	  				}
	  			}        
	  		}else{
	  			echo '<li><a>No Matches</a></li>';  
	  		} 
	  	}     
	}
}
?>