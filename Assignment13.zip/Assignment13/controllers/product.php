<?php

class Product extends BaseController {

    /**
    * @author Yash
    * Default method of Product controller and load header,default listing page,footer view.
    * With implementing newsletter functionality in footer. 
    * @param product details. 
    */

    public function index() 
    {
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        $cat['title'] = "eShopper - Products";

        $this->load_model('ProductModel');
        $result['result'] = $this->productmodel->ProductList(3); 
        $result['size'] = $this->productmodel->getSize();   
        $result['cat'] = $this->productmodel->getCat();   
        $result['price'] = $this->productmodel->getPrice();   
        $result['color'] = $this->productmodel->getColor();

        $this->load_view('header', $cat);    
        $this->load_view('product/product', $result);
        
        $this->load_model("FooterModel");

        //For newsletter functionality.
        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
    }


    /**
    * @author Yash
    * Function of Product controller and load header,listing page category wise,footer view.
    * With implementing newsletter functionality in footer. 
    * @param product details. 
    */

    public function listing($subcat) 
    {
        $subcat = ucwords(str_replace("_", " ", $subcat));
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();

        $this->load_model('ProductModel');
        $result['result'] = $this->productmodel->ProductListByCat($subcat); 
        $result['size'] = $this->productmodel->getSize();   
        $result['cat'] = $this->productmodel->getCat();   
        $result['price'] = $this->productmodel->getPrice();   
        $result['color'] = $this->productmodel->getColor();
        $result['name'] = $subcat;
        $cat['title'] = "eShopper - ".$subcat;

        $this->load_view('header', $cat);    
        $this->load_view('product/product', $result);
        
        $this->load_model("FooterModel");

        //For newsletter functionality.
        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
    }


    /**
    * @author Yash
    * Function of Product controller and load header,product detail page,footer view.
    * With implementing newsletter functionality in footer. 
    * @param product details. 
    */

    public function details($id) 
    {
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        $cat['title'] = "eShopper - Product Details";

        $this->load_model("ProductModel");
        $details['item'] = $this->productmodel->productDetails($id);
        $details['itemid'] = $id;
        $details['review'] = $this->productmodel->getReview($id);
        $this->load_view('header', $cat);    
        $this->load_view('product/product_detail', $details);
        
        $this->load_model("FooterModel");

        //For newsletter functionality.
        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
    }


    /**
    * @author Yash
    * Function to add product in wishlist in details page. 
    * @param from and to ajax. 
    */

    public function addToWish()
    {   
        if(checkIfLogin()){
            $id = $_POST['id'];
            $this->load_model("ProductModel");
            $result = $this->productmodel->addToWishlist($id);
            if($result == true){
                echo 1;
            }else if($result == false){
                echo 2;
            }
        }else{
            echo 3;
        }    
    }


    /**
    * @author Yash
    * Function to add product in cart. 
    * @param from and to ajax. 
    */

    public function addCart()
    {   
        if(checkIfLogin()){
            $id = $_POST['id'];
            $qty = $_POST['qty'];
            $size = $_POST['size'];
            $this->load_model("ProductModel");
            $result = $this->productmodel->addToCart($id, $qty, $size);
            if($result == true){
                echo 1;
            }else{
                echo "error";
            }
        }else{
            echo 3;
        }    
    }


    /**
    * @author Yash
    * Function to delete product from cart. 
    * @param from and to ajax. 
    */

    public function deletePopup()
    {   
        $id = $_POST['id'];
        $size = $_POST['size'];
        $this->load_model("ProductModel");
        $result = $this->productmodel->deleteFromPopup($id, $size);
        if($result == true){
            echo 1;
        }else{
            echo "error";
        }  
    }


    /**
    * @author Yash
    * Function to review product in details page. 
    * @param from and to ajax. 
    */

    public function review()
    {   
        if(checkIfLogin()){
            $id = $_POST['id'];
            $star = $_POST['star'];
            $text = $_POST['text'];
            if (empty($star) || empty($text)) {
                echo 4;
            }else{
                $this->load_model("ProductModel");
                $result = $this->productmodel->addReview($id, $star, $text);
                if($result == true){
                    echo 1;
                }else if($result == false){
                    echo 2;
                }else{
                    echo "error";
                }
            }
        }else{
            echo 3;
        }    
    }


    /**
    * @author Yash
    * Function to show more products in listing page. 
    * @param from and to ajax. 
    */

    public function moreList() 
    {
        $this->load_model('ProductModel');
        
        if (isset($_POST['limit'])) {
            $assets_url = ASSETS_URL;
            $result = $this->productmodel->ProductList($_POST['limit']); 
            $rows = mysqli_num_rows($result);
            if ($_POST['limit'] > $rows) {
                echo '<script>$("#morelist").hide();</script>';
            }
            while($row = mysqli_fetch_object($result)){
              echo '<section class="col-sm-4 same-height">
                      <div class="thumbnail itembox">
                        <div class="imgcont">   
                          <a href="'.SITE_URL.'product/details/'.$row->id.'" class="nodeco">
                           <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$row->item_image_url.'" alt="product'.$row->id.'">                    
                           <div class="hvrbut">
                          </a>
                          <button class="but btn btn-default" onclick="cnfrm('.$row->variation_id.')">ADD TO CART</button>
                          <input type="hidden" id="inputSize'.$row->variation_id.'" value="'.$row->value.'">
                          <input type="hidden" id="inputqty'.$row->variation_id.'" value="1">
                          <input type="hidden" id="price'.$row->variation_id.'" value="'.$row->price.'">
                          <input type="hidden" id="itemid'.$row->variation_id.'" value="'.$row->id.'">>
                         </div>
                        </div>
                        <a href="'.SITE_URL.'product/details/'.$row->id.'" class="nodeco">
                         <div class="caption">
                          <p class="text3">'.$row->name.'</p>
                          <p class="text4">$'.$row->price.'</p>                   
                         </div>
                        </a>
                      </div>
                    </section>';  
            }                      
        }
    }


    /**
    * @author Yash
    * Function to show filtered products in listing page. 
    * @param from and to ajax. 
    */

    public function filter()
    {   
        $this->load_model("ProductModel");
        $assets_url = ASSETS_URL;
        $sizeStr = $_POST['sizeArr'];
        $catStr = $_POST['catArr'];
        $priceStr = $_POST['priceArr'];
        $colorStr = $_POST['colorArr'];
        $catstring = "";
        $sizestring = "";
        $pricestring = "";
        $colorstring = "";

        if (!empty($catStr)) {

            $catArr = explode(",", $catStr);
            $count2 = sizeof($catArr);

            for ($i=0; $i < $count2; $i++) { 
                $catArr[$i] = "c.id = ".$catArr[$i];
            }

            $count2--;

            for ($i=0; $i < $count2; $i++) { 
                $catArr[$i] = $catArr[$i]." OR ";
            }

            $catstring = implode("", $catArr);
        }

        if (!empty($sizeStr)) {

            $sizeArr = explode(",", $sizeStr);
            $count = sizeof($sizeArr);

            for ($i=0; $i < $count; $i++) { 
                $sizeArr[$i] = "ao.id = ".$sizeArr[$i];
            }

            $count--;

            for ($i=0; $i < $count; $i++) { 
                $sizeArr[$i] = $sizeArr[$i]." OR ";
            }

            $sizestring = implode("", $sizeArr);
        }

        if (!empty($priceStr)) {

            $priceArr = explode(",", $priceStr);
            $count3 = sizeof($priceArr);

            for ($i=1; $i < $count3; $i++) { 
                $priceArr[$i] = "price <=".$priceArr[$i];
            }

            $count3--;

            for ($i=0; $i < $count3; $i++) { 
                $priceArr[$i] = "price >= ".$priceArr[$i]." AND ";
            }

            $pricestring = implode("", $priceArr);
        }

        if (!empty($colorStr)) {

            $colorArr = explode(",", $colorStr);
            $countc = sizeof($colorArr);

            for ($i=0; $i < $countc; $i++) { 
                $colorArr[$i] = "ao2.id = ".$colorArr[$i];
            }

            $countc--;

            for ($i=0; $i < $countc; $i++) { 
                $colorArr[$i] = $colorArr[$i]." OR ";
            }

            $colorstring = implode("", $colorArr);
        }

        $data = $this->productmodel->filter($sizestring, $catstring, $pricestring, $colorstring);

        if (empty($data)) {
            echo "<center class='text4'>No products in this combination</center>";
        }else{
            foreach ($data as $key => $value) {
                echo '<section class="col-sm-4 same-height">
                        <div class="thumbnail itembox">
                          <div class="imgcont">   
                            <a href="'.SITE_URL.'product/details/'.$value[0].'" class="nodeco">
                             <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$value[1].'" alt="product'.$value[0].'">                    
                             <div class="hvrbut">
                            </a>
                            <button class="but btn btn-default" onclick="cnfrm('.$value[5].')">ADD TO CART</button>
                            <input type="hidden" id="inputSize'.$value[5].'" value="'.$value[4].'">
                            <input type="hidden" id="inputqty'.$value[5].'" value="1">
                            <input type="hidden" id="price'.$value[5].'" value="'.$value[3].'">
                            <input type="hidden" id="itemid'.$value[5].'" value="'.$value[0].'">
                           </div>
                          </div>
                          <a href="'.SITE_URL.'product/details/'.$value[0].'" class="nodeco">
                           <div class="caption">
                            <p class="text3">'.$value[2].'</p>
                            <p class="text4">$'.$value[3].'</p>                   
                           </div>
                          </a>
                        </div>
                      </section>';   
            }
        }
    }


    /**
    * @author Yash
    * Function to show search results in listing page. 
    * @param from and to ajax. 
    */

    public function searchResults($string)
    {             
        $assets_url = ASSETS_URL;
        $string = trim($string);
        $string = stripslashes($string);
        $string = htmlspecialchars($string);
        $string = str_replace("_", "/_", $string);
        $string = str_replace("%", "/%", $string);

        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        $cat['title'] = "eShopper - Search Results";

        $this->load_model('ProductModel');   
        $result['result'] = $this->productmodel->searchProducts($string);
        if($result['result']->num_rows == 0){
            $result['none'] = "none";
        }
        $result['size'] = $this->productmodel->getSize();   
        $result['cat'] = $this->productmodel->getCat();   
        $result['price'] = $this->productmodel->getPrice();   
        $result['color'] = $this->productmodel->getColor();
        $result['no'] = "no";
        $result['string'] = $string;

        $this->load_view('header', $cat);    
        $this->load_view('product/product', $result);
        
        $this->load_model("FooterModel");

        // For newsletter functionality.
        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }        
    }


    /**
    * @author Yash
    * Function to show sort results in listing page. 
    * @param from and to ajax. 
    */

    public function sort()
    {   
        $this->load_model("ProductModel");
        $assets_url = ASSETS_URL;
        $value = $_POST['value'];        

        $data = $this->productmodel->sort($value);

        foreach ($data as $key => $value) {
            echo '<section class="col-sm-4 same-height">
                    <div class="thumbnail itembox">
                      <div class="imgcont">   
                        <a href="'.SITE_URL.'product/details/'.$value[0].'" class="nodeco">
                         <img class="imghvr img-responsive" src="'.$assets_url.'images/'.$value[1].'" alt="product'.$value[0].'">                    
                         <div class="hvrbut">
                        </a>
                        <button class="but btn btn-default" onclick="cnfrm('.$value[5].')">ADD TO CART</button>
                        <input type="hidden" id="inputSize'.$value[5].'" value="'.$value[4].'">
                        <input type="hidden" id="inputqty'.$value[5].'" value="1">
                        <input type="hidden" id="price'.$value[5].'" value="'.$value[3].'">
                        <input type="hidden" id="itemid'.$value[5].'" value="'.$value[0].'">
                       </div>
                      </div>
                      <a href="'.SITE_URL.'product/details/'.$value[0].'" class="nodeco">
                       <div class="caption">
                        <p class="text3">'.$value[2].'</p>
                        <p class="text4">$'.$value[3].'</p>                   
                       </div>
                      </a>
                    </div>
                  </section>';   
        }
    }
}
?>