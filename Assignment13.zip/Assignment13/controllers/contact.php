<?php

class Contact extends BaseController{
	
	/**
	* @author Yash
	* Default method of Contact controller and load header,main content,footer view.
	* With implementing newsletter functionality in footer.  
	* @param contact form data.
	* @return validation errors.
	*/

	public function index()
	{	
		$validationErrors = array();
		
		if(isset($_POST['contact'])) {
			
			$this->load_model("ContactModel");
			
			if($this->contactmodel->ConMail($_POST['contact'])) {
				echo "<script>alert('Your Message has been Submitted');window.location.href='".SITE_URL."contact'</script>";		
			}else{
				$validationErrors = $this->contactmodel->getErrors();		
			}		
		}	
		
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        $cat['title'] = "eShopper - Contact Us";
        
        $this->load_view('header', $cat);  
		$this->load_view('user/contact', array('validationErrors'=>$validationErrors));
		
		$this->load_model("FooterModel");

		//For newsletter functionality.
        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $flag = $this->footermodel->NewsSubscriber($mail);          
            $this->load_view('footer', $flag);
        }else{              
            $this->load_view('footer');
        }  
	}
}
?>