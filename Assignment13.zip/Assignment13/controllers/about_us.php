<?php

class About_Us extends BaseController {
    
    /**
    * @author Yash
    * Default method of About_Us controller and load header,main content,footer view.
    * With implementing newsletter functionality in footer.  
    */

    public function index()
    {
        $this->load_model("HeaderModel");
        $cat['cat'] = $this->headermodel->getParCategories();
        $cat['title'] = "eShopper - About Us";
        
        $this->load_view('header', $cat);    
        $this->load_view('about_us');          

        $this->load_model("FooterModel");
        
        //For newsletter functionality.
        if (isset($_POST['news_submit'])) {
            $mail = $_POST['inputNewsEmail'];
            $this->footermodel->NewsSubscriber($mail);              
            $this->load_view('footer');
        }else{                  
            $this->load_view('footer');
        }
    }
}
?>