<?php

class Cart extends BaseController {
    
    /**
    * @author Yash
    * Default method of Cart controller and load header,main content,footer view.
    * With implementing newsletter functionality in footer.  
    */    

    public function index() 
    {
        if(checkIfLogin()){
            $this->load_model("HeaderModel");
            $cat['cat'] = $this->headermodel->getParCategories();
            $cat['title'] = "eShopper - Shopping Cart";

            $this->load_view('header', $cat);    
            $this->load_view('user/cart');
            
            $this->load_model("FooterModel");

            //For newsletter functionality.
            if (isset($_POST['news_submit'])) {
                $mail = $_POST['inputNewsEmail'];
                $flag = $this->footermodel->NewsSubscriber($mail);          
                $this->load_view('footer', $flag);
            }else{              
                $this->load_view('footer');
            }   
        }else{
            echo "<script>alert('Please Login First');window.location.href='".SITE_URL."'</script>"; 
        } 
    }
    

    /**
    * @author Yash
    * Function to update cart. 
    * @param from and to ajax. 
    */

    public function updateCart()
    {
        if(checkIfLogin()){
            $id = $_POST['id'];
            $qty = $_POST['qty'];
            $size = $_POST['size'];
            $this->load_model("CartModel");
            $result = $this->cartmodel->updateSubtotal($id, $qty, $size);
            if($result == true){
                echo 1;
            }else{
                echo "error";
            }
        }else{
            echo 3;
        } 
    }

    /**
    * @author Yash
    * Function to clear cart.  
    */

    public function clear()
    {
        if (isset($_SESSION['item'])) {
            unset($_SESSION['item']);
            echo 1;
        }else{
            echo 2;
        }
    }
}
?>