<?php

class Profile extends BaseController{
	
	/**
	* @author Yash
	* Default method of Profile Controller
	* @param userdata 
	* @return validation errors and update user details.
	*/

	public function index()
	{	
		if(checkIfLogin()){
			$validationErrors = array();		

			$this->load_model("ProfileModel");	
			$data['user'] = $this->profilemodel->getUserDetails($_SESSION['id']);
			$data['address'] = $this->profilemodel->getUserAddress($_SESSION['id']);
			$data['country'] = $this->profilemodel->getCountry();
				
			if (isset($_POST['profile'])) {
				
				if($this->profilemodel->insert($_POST['profile'])) {

					$this->redirect('profile');
				
				} else {
					// insert fail due to some validation errors
					$validationErrors = $this->profilemodel->getErrors();	
					$data['validationErrors'] = $validationErrors; 
				}
			}			
			
	        $this->load_model("HeaderModel");
	        $cat['cat'] = $this->headermodel->getParCategories();
        	$cat['title'] = "eShopper - Profile";
	        
	        $this->load_view('header', $cat);  
			$this->load_view('user/profile', $data);
			
			$this->load_model("FooterModel");

			//For newsletter functionality.
	        if (isset($_POST['news_submit'])) {
	            $mail = $_POST['inputNewsEmail'];
	            $flag = $this->footermodel->NewsSubscriber($mail);          
	            $this->load_view('footer', $flag);
	        }else{              
	            $this->load_view('footer');
	        }  
	    }else{
	    	echo "<script>alert('Please Login First');window.location.href='".SITE_URL."'</script>"; 
	    }    
	}


	/**
	* @author Yash
	* Function to show states for billing address in profile page. 
	* @param from and to ajax. 
	*/

	public function state1()
	{		
		$this->load_model("ProfileModel");	
		$this->profilemodel->getState1();
	}


	/**
	* @author Yash
	* Function to show states for shipping address in profile page. 
	* @param from and to ajax. 
	*/

	public function state2()
	{		
		$this->load_model("ProfileModel");	
		$this->profilemodel->getState2();
	}


	/**
	* @author Yash
	* Function to check email is unique in profile page. 
	* @param from and to ajax. 
	*/

	public function uniqueEmail()
	{
		$email = $_POST['email'];		
		if (strlen($email) > 0) {
			$this->load_model("ProfileModel");
			$res = $this->profilemodel->checkEmailExist($email);
			if($res == "true"){
				echo "Exists";
			}else if ($res == "Invalid") {
				echo "Invalid";
			}else{
				echo "Unique";
			}
		}else{
			echo "Empty";
		}
	}
}
?>