<?php

class Register extends BaseController{
	
	/**
	* @author Yash
	* Default method of Register Controller
	* @param userdata 
	* @return validation user and do login process 
	*/

	public function index()
	{	
		if (!checkIfLogin()) {
			$validationErrors = array();
			
			if(isset($_POST['register'])) {
				
				$this->load_model("RegisterModel");
				
				if($this->registermodel->insert($_POST['register'])) {

					$this->load_model("LoginModel");
					
					if($this->loginmodel->authenticate($this->registermodel->data['inputUserName'], $this->registermodel->data['inputPassword'])) {
						$this->redirect('home/index');
					} 
				
				}else {
					// insert fail due to some validation errors
					$validationErrors = $this->registermodel->getErrors();	
				}		
			}	
			
	        $this->load_model("HeaderModel");
	        $cat['cat'] = $this->headermodel->getParCategories();
        	$cat['title'] = "eShopper - Register";
	        
	        $this->load_view('header', $cat);  
			$this->load_view('user/register', array('validationErrors'=>$validationErrors));
			
			$this->load_model("FooterModel");

			//For newsletter functionality.
	        if (isset($_POST['news_submit'])) {
	            $mail = $_POST['inputNewsEmail'];
	            $flag = $this->footermodel->NewsSubscriber($mail);          
	            $this->load_view('footer', $flag);
	        }else{              
	            $this->load_view('footer');
	        }  
		}else{
			echo "<script>alert('You are already logged in.Logout to register as a new user.');window.location.href='".SITE_URL."'</script>"; 
		}
	}


	/**
	* @author Yash
	* Function to check username is unique in register page. 
	* @param from and to ajax. 
	*/

	public function uniqueUname()
	{
		$uname = $_POST['uname'];
		if (strlen($uname) > 0) {
			$this->load_model("RegisterModel");
			$res = $this->registermodel->checkUsernameExist($uname);
			if ($res == "true") {
				echo "Exists";
			}else if($res == "Invalid"){
				echo "Invalid";
			}else{
				echo "Unique";
			}
		}else{
			echo "Empty";
		}
	}


	/**
	* @author Yash
	* Function to check email is unique in register page. 
	* @param from and to ajax. 
	*/

	public function uniqueMail()
	{
		$mail = $_POST['mail'];		
		if (strlen($mail) > 0) {
			$this->load_model("RegisterModel");
			$res = $this->registermodel->checkEmailExist($mail);
			if($res == "true"){
				echo "Exists";
			}else if ($res == "Invalid") {
				echo "Invalid";
			}else{
				echo "Unique";
			}
		}else{
			echo "Empty";
		}
	}
}
?>