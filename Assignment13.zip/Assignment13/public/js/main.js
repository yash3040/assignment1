document.write(
	'<script type="text/javascript" src="'+assets_url+'js/jquery.min.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/bootstrap.min.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/owl.carousel.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/jssor.slider-26.9.0.min.js"></script>' +	
	'<script type="text/javascript" src="'+assets_url+'js/owl.autoplay.js"></script>' +		
	'<script type="text/javascript" src="'+assets_url+'js/ion.rangeSlider.min.js"></script>' +		
	'<script type="text/javascript" src="'+assets_url+'js/jquery.matchHeight.js"></script>' +		
	'<script type="text/javascript" src="'+assets_url+'js/owl.navigation.js"></script>' +
	'<script type="text/javascript" src="'+assets_url+'js/valid.js"></script>'
);