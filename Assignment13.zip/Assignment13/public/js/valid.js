//different types of regexes.
var $unameregex = /^[a-z0-9_-]{8,}$/i;
var $passregex = /^(?=.*[a-z])(?=(?:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/;
var $passregex2 = /^[a-f0-9]{32}$/i;
var $mailregex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
var $fnameregex = /^[A-Za-z]+$/;
var $mobregex = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
var $phoneregex = /^\d{10}$/;

//common validation function for both register and profile page common content.
function valid() 
{
    var $uname = $('#inputUserName');
    var $pass = $('#inputPassword');
    var $pass2 = $('#inputPassword2');
    var $gndr = $('input[type=radio]');
    var $mail = $('#inputEmail');
    var $fname = $('#inputFname');
    var $mob = $('#inputMobNo');
    var $phone = $('#inputPhone');
    var $opt1 = $('#opt1');
    var $opt2 = $('#opt2');
    var $opt3 = $('#opt3');
    var $optoth = $('#optoth');
    var $checktxt = $('#checktxt');

    //validation for username
    if ($uname.val() == "") {
        $('#unamep').text('Enter a username');
        $uname.focus();
        $flag = 1;
    } else if (!$unameregex.test($uname.val())) {
        $('#unamep').text('Enter a valid Username');
        $uname.focus();
        $flag = 1;
    } else {
        $('#unamep').text("");
    }

    //validation for password and confirm password
    if ($pass.val() == "") {
        $('#passp').text('Enter a password');
        $pass.focus();
        $flag = 1;
    } else if (!$passregex.test($pass.val()) && !$passregex2.test($pass.val())) {
        $('#passp').text('Enter a valid password');
        $pass.focus();
        $flag = 1;
    } else {
        $('#passp').text("");
    }

    if (!($pass.val() == $pass2.val())) {
        $('#passp2').text('Please Enter Same as Password');
        $pass2.focus();
        $flag = 1;
    } else {
        $('#passp2').text("");
    }

    //validation for gender
    if (!$gndr[0].checked && !$gndr[1].checked) {
        $('#gndrp').text('Please select gender.');
        $flag = 1;
    } else {
        $('#gndrp').text("");
    }

    //validation for email
    if ($mail.val() == "") {
        $('#mailp').text('Enter a email');
        $mail.focus();
        $flag = 1;
    } else if (!$mailregex.test($mail.val())) {
        $('#mailp').text('Enter a valid email');
        $mail.focus();
        $flag = 1;
    } else {
        $('#mailp').text("");
    }

    //validation for first name
    if ($fname.val() == "") {
        $('#fnamep').text('Enter First Name');
        $fname.focus();
        $flag = 1;
    } else if (!$fnameregex.test($fname.val())) {
        $('#fnamep').text('Enter a valid name');
        $fname.focus();
        $flag = 1;
    } else {
        $('#fnamep').text("");
    }

    //validation for mobile number in US format
    if ($mob.val() == "") {
        $('#mobp').text('Enter a mobile number');
        $mob.focus();
        $flag = 1;
    } else if (!$mobregex.test($mob.val())) {
        $('#mobp').text('Enter a valid number');
        $mob.focus();
        $flag = 1;
    } else {
        $('#mobp').text("");
    }

    //validation for phone number
    if ($phone.val() == "") {
        $('#phonep').text("");
    } else if (!$phoneregex.test($phone.val())) {
        $('#phonep').text('Enter a valid number');
        $phone.focus();
        $flag = 1;
    } else {
        $('#phonep').text("");
    }

    //for checkboxes
    if (!$opt1.is(':checked')) {
        if (!$opt2.is(':checked')) {
            if (!$opt3.is(':checked')) {
                if (!$optoth.is(':checked')) {
                    $('#checkp').text('Please select any one');
                    $flag = 1;
                } else {
                    $('#checkp').text("");
                }
            } else {
                $('#checkp').text("");
            }
        } else {
            $('#checkp').text("");
        }
    } else {
        $('#checkp').text("");
    }

    //for other textbox
    if ($optoth.is(':checked')) {
        if ($checktxt.val() == "") {
            $('#checkp').text('Enter your interest');
            $flag = 1;
        } else {
            $('#checkp').text("");
        }
    }

    if ($flag == 0) {
        return true;
    } else {

        return false;
    }
}

//For terms and conditions in register page.
function termfunc() 
{
    var $term = $('#term');

    if (!$term.is(':checked')) {
        $('#termsp').text('Please Accept terms and conditions.');
        $flag = 1;
    } else {
        $('#termsp').text("");
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    } else {
        return false;
    }
}

//to reset form in register page.
function clr() 
{
    if (confirm("Are you sure you want to clear the form")) {
        $('#form1')[0].reset();
    }
}

//for address collapse in profile page.
function prfl() 
{
    var $strt = $('#inputStreet');
    var $cty = $('#inputCity');
    var $cntry = $('#inputCountry');
    var $stt = $('#inputState');
    var $strt2 = $('#inputStreet2');
    var $cty2 = $('#inputCity2');
    var $cntry2 = $('#inputCountry2');
    var $stt2 = $('#inputState2');

    if ($strt.val() == "") {
        $('#strtp').text('Please Enter Street');
        $flag = 1;
    } else {
        $('#strtp').text("");
    }

    if ($cty.val() == "") {
        $('#ctyp').text('Please Enter City');
        $flag = 1;
    } else {
        $('#ctyp').text("");
    }

    if ($strt2.val() == "") {
        $('#strt2p').text('Please Enter Street');
        $flag = 1;
    } else {
        $('#strt2p').text("");
    }

    if ($cty2.val() == "") {
        $('#cty2p').text('Please Enter City');
        $flag = 1;
    } else {
        $('#cty2p').text("");
    }

    if ($cntry.val() == "") {
        $('#cntryp').text('Please Select Country');
        $flag = 1;
    } else {
        $('#cntryp').text("");
    }

    if ($cntry2.val() == "") {
        $('#cntry2p').text('Please Select Country');
        $flag = 1;
    } else {
        $('#cntry2p').text("");
    }

    if ($stt.val() == null || $stt.val() == "") {
        $('#sttp').text('Please Select State');
        $flag = 1;
    } else {
        $('#sttp').text("");
    }

    if ($stt2.val() == null || $stt2.val() == "") {
        $('#stt2p').text('Please Select State');
        $flag = 1;
    } else {
        $('#stt2p').text("");
        $flag = 0;
    }

    if ($flag == 0) {   	
    	if($("#billcollapse").hasClass("in")){
    		$("#billcollapse").removeClass("in");
    	}
    	if($("#shipcollapse").hasClass("in")){
    		$("#shipcollapse").removeClass("in");
    	}
        return true;
    } else {
    	$("#billcollapse").addClass("in");
    	$("#shipcollapse").addClass("in");
        return false;
    }
}

//for contact us form.
function contactvalid() 
{
    var $con_name = $('#inputConName');
    var $con_mail = $('#inputConEmail');
    var $subject = $('#inputSubject');
    var $message = $('#inputMessage');

    //validation for name
    if ($con_name.val() == "") {
        $('#namep').text('Enter a Name');
        $con_name.focus();
        $flag = 1;
    } else if (!$fnameregex.test($con_name.val())) {
        $('#namep').text('Enter a valid Name');
        $con_name.focus();
        $flag = 1;
    } else {
        $('#namep').text("");
    }

    //validation for email
    if ($con_mail.val() == "") {
        $('#conmailp').text('Enter a Email');
        $con_mail.focus();
        $flag = 1;
    } else if (!$mailregex.test($con_mail.val())) {
        $('#conmailp').text('Enter a valid Email');
        $con_mail.focus();
        $flag = 1;
    } else {
        $('#conmailp').text("");
    }

    //validation for subject
    if ($subject.val() == "") {
        $('#subp').text('Enter a Subject');
        $subject.focus();
        $flag = 1;
    } else {
        $('#subp').text("");
    }

    //validation for message
    if ($message.val() == "") {
        $('#msgp').text('Enter a Message');
        $message.focus();
        $flag = 1;
    } else {
        $('#msgp').text("");
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    } else {
        return false;
    }
}

//for footer newsletter subscriber.
function newsvalid() 
{
    var $news_email = $('#inputNewsEmail');

    //validation for email
    if (!$mailregex.test($news_email.val())) {
        $news_email.focus();
        $('#newsmailp').text("Enter valid email");
        $flag = 1;
    } else {
        $flag = 0;
    }

    if ($flag == 0) {
        return true;
    } else {
        return false;
    }
}

//For checkboxes
function allcheck() 
{
    var $all = $('#all');
    var $opt1 = $('#opt1');
    var $opt2 = $('#opt2');
    var $opt3 = $('#opt3');

    if ($all.is(':checked')) {
        $opt1.prop('checked', true);
        $opt2.prop('checked', true);
        $opt3.prop('checked', true);
    } else {
        $opt1.prop('checked', false);
        $opt2.prop('checked', false);
        $opt3.prop('checked', false);
    }
}

//For checkboxes
function indicheck() 
{
    var $all = $('#all');
    var $opt1 = $('#opt1');
    var $opt2 = $('#opt2');
    var $opt3 = $('#opt3');
    var $optoth = $('#optoth');
    var $checktxt = $('#checktxt');

    if (!$opt1.is(':checked') || !$opt2.is(':checked') || !$opt3.is(':checked')) {
        $all.prop('checked', false);
    }

    if ($opt1.is(':checked') && $opt2.is(':checked') && $opt3.is(':checked')) {
        $all.prop('checked', true);
    }

    if ($optoth.is(':checked')) {
        $checktxt.prop('readonly', false);
    } else {
        $checktxt.prop('readonly', true);
        $checktxt.val("");
    }
}

//To copy address when checkbox is checked.
function cpyadd() 
{
    var $sameadd = $('#sameadd');
    var $strt = $('#inputStreet');
    var $cty = $('#inputCity');
    var $cntry = $('#inputCountry');
    var $stt = $('#inputState');
    var $strt2 = $('#inputStreet2');
    var $cty2 = $('#inputCity2');
    var $cntry2 = $('#inputCountry2');
    var $stt2 = $('#inputState2');

    if ($sameadd.is(':checked')) {

        $strt2.val($strt.val());
        $cty2.val($cty.val());
        $cntry2.val($cntry.val());

        var $cpystt = $("#inputState > option").clone();
        $stt2.empty();
        $stt2.append($cpystt);
        $stt2.val($stt.val());

        $strt2.prop('readonly', true);
        $cty2.prop('readonly', true);
        $cntry2.prop('disabled', true);
        $stt2.prop('disabled', true);

        $strt.on('input', function() {
            window.setTimeout(function() {
                $strt2.val($strt.val());
            }, 0);
        });

        $cty.on('input', function() {
            window.setTimeout(function() {
                $cty2.val($cty.val());
            }, 0);
        });

        $cntry.on('change.copycntry', function() {
            window.setTimeout(function() {
                $cntry2.val($cntry.val());
            }, 0);
        });

        $stt.on('change.copystt', function() {
            window.setTimeout(function() {
                var $cpystt = $("#inputState > option").clone();
                $stt2.empty();
                $stt2.append($cpystt);
                $stt2.val($stt.val());
            }, 0);
        });
    } else {
        $strt2.prop('readonly', false);
        $cty2.prop('readonly', false);
        $cntry2.prop('disabled', false);
        $stt2.prop('disabled', false);
        $strt.off();
        $cty.off();
        $cntry.off('change.copycntry');
        $stt.off('change.copystt');
    }
}

$(document).ready(function(){

    //Testimonial carousel intialization.
    $('.owl-carousel').owlCarousel({
        items: 1,
        lazyLoad: true,
        loop: true,
        margin: 10,
        autoplay: true,
        autoplayTimeout: 4000,
    });

    //Copy address on profile page load if checkbox is selected.
    var $sameadd = $('#sameadd');
    var $strt = $('#inputStreet');
    var $cty = $('#inputCity');
    var $cntry = $('#inputCountry');
    var $stt = $('#inputState');
    var $strt2 = $('#inputStreet2');
    var $cty2 = $('#inputCity2');
    var $cntry2 = $('#inputCountry2');
    var $stt2 = $('#inputState2');

    if ($sameadd.is(':checked')) {
        $strt.on('input', function() {
            window.setTimeout(function() {
                $strt2.val($strt.val());
            }, 0);
        });

        $cty.on('input', function() {
            window.setTimeout(function() {
                $cty2.val($cty.val());
            }, 0);
        });

        $cntry.on('change.copycntry', function() {
            window.setTimeout(function() {
                $cntry2.val($cntry.val());
            }, 0);
        });

        $stt.on('change.copystt', function() {
            window.setTimeout(function() {
                var $cpystt = $("#inputState > option").clone();
                $stt2.empty();
                $stt2.append($cpystt);
                $stt2.val($stt.val());
            }, 0);
        });
    }

    //ajax to get states for billing address on page load.
    var id = $("#inputCountry").val();
    var dataString = 'id=' + id;
    $("#inputState").find('option').remove();

    $.ajax({
        type: "POST",
        url: "profile/state1",
        data: dataString,
        cache: false,
        success: function(html) {
            $("#inputState").html(html);
        }
    });

    //ajax to get states for shipping address on page load.
    var id = $("#inputCountry2").val();
    var dataString = 'id=' + id;
    $("#inputState2").find('option').remove();

    $.ajax({
        type: "POST",
        url: "profile/state2",
        data: dataString,
        cache: false,
        success: function(html) {

            $("#inputState2").html(html);
        }
    });

    //ajax to get states for billing address on change country.
    $("#inputCountry").change(function() {
        var id = $(this).val();
        var dataString = 'id=' + id;
        $("#inputState").find('option').remove();

        $.ajax({
            type: "POST",
            url: "profile/state1",
            data: dataString,
            cache: false,
            success: function(html) {

                $("#inputState").html(html);
            }
        });
    });

    //ajax to get states for shipping address on change country.
    $("#inputCountry2").change(function() {
        var id = $(this).val();
        var dataString = 'id=' + id;
        $("#inputState2").find('option').remove();

        $.ajax({
            type: "POST",
            url: "profile/state2",
            data: dataString,
            cache: false,
            success: function(html) {

                $("#inputState2").html(html);
            }
        });
    });

    //ajax to add product to wishlist.
    $("#addtowish").click(function() {
        var id = $("[name=itemid]").val();
        var dataString = 'id=' + id;
        $.ajax({
            url: site_url + "product/addToWish",
            type: 'POST',
            data: dataString,
            success: function(response) {
                if (response == 1) {
                    $("#alrtsuc").fadeTo(2000, 500).slideUp(500, function() {
                        $("#alrtsuc").slideUp(500);
                    });
                } else if (response == 2) {
                    $("#alrtwarn").fadeTo(3000, 500).slideUp(500, function() {
                        $("#alrtwarn").slideUp(500);
                    });
                } else {
                    alert("Please Login to add products in wishlist");
                }
            },
            error: function(response) {
                alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
            }

        })
    });

    //ajax to submit product review.
    $("#ratingsubmit").click(function() {
        var id = $("[name=itemid]").val();
        var star = $("[name=rating]:checked").val();
        var text = $("#inputreview").val();
        var dataString = "star=" + star + "&id=" + id + "&text=" + text;
        $.ajax({
            url: site_url + "product/review",
            type: "POST",
            data: dataString,
            success: function(response) {
                if (response == 1) {
                    alert("Your review has been submitted.");
                    $('#currentlabel').show();
                    $('#currentp').show();
                    $('#currentp').html(text);
                    $('#noreview').hide();
                } else if (response == 2) {
                    alert("You have already reviewed this product.");
                } else if (response == 3) {
                    alert("Login to review product.");
                } else if (response == 4) {
                    alert("Ratings and review message are mandatory.");
                } else {
                    alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
                }
            },
            error: function(response) {
                alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
            }
        })
    });

    //for cart dropdown
    $("#menu1").click(function() {
        $(".ulddcart").slideToggle();
    })


    //for move to top button
    $(window).scroll(function() {
        if ($(this).scrollTop() > 100) {
            $('.topbut').fadeIn();
        } else {
            $('.topbut').fadeOut();
        }
    });

    $('.topbut').click(function() {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });

    //For zoom effect modal on product details page.
    $('#largeImage').on('click', function() {
        $('.enlargeImageModalSource').attr('src', $(this).attr('src'));
        $('#enlargeImageModal').modal('show');
    });

    //For hiding fields on page load in product details page.
    $('#currentlabel').hide();
    $('#currentp').hide();

    //ajax to show more trending products on homepage.
    var limit1 = 4;
    $('#moretrends').click(function() {
        limit1 += 2;
        r1 = $('#row').val();
        $('.load').show();
        $.ajax({
            url: site_url + "home/moreTrendProds",
            type: "POST",
            data: "limit=" + limit1,
            success: function(response) {
                $('.innertrend').html(response);
                window.setTimeout(function(){
                    $('.same-height').matchHeight();
                }, 10);
            },
            complete: function() {
                $('.load').hide();
            },
            error: function(response) {
                alert("Something Went wrong.\\nAnd try again.");
            }
        })
    })

    //ajax to show more products in listing page.
    var limit2 = 3;
    $('#morelist').click(function() {
        limit2 += 3;
        r = $('#row').val();
        $('.load').show();
        $.ajax({
            url: site_url + "product/moreList",
            type: "POST",
            data: "limit=" + limit2,
            success: function(response) {
                $('.listdiv').html(response);
                window.setTimeout(function(){
                    $('.same-height').matchHeight();
                }, 10);
            },
            complete: function() {
                $('.load').hide();
            },
            error: function(response) {
                alert("Something Went wrong.\nAnd try again.");
            }
        })
    })

    //Price slider initialization.
    $("#priceslider").ionRangeSlider({
        type: "double",
        hide_min_max: true,
        hide_from_to: false,
        grid: false
    });

    //ajax to show filtered products on listing page.
    $(".catbox, .sizebox, #priceslider, .colorbox").change(function() {
        $('.load').show();
        sizeArray = [];
        catArray = [];
        priceArray = [];
        colorArray = [];

        if ($(".sizebox:checked").val() !== 0) {
            $(".sizebox:checked").each(function() {
                sizeArray.push($(this).val());
            });
        }

        if ($(".catbox:checked").val() !== 0) {
            $(".catbox:checked").each(function() {
                catArray.push($(this).val());
            });
        }

        value = $("#priceslider").prop("value").split(";");
        priceArray.push(value[0]);
        priceArray.push(value[1]);

        if ($(".colorbox:checked").val() !== 0) {
            $(".colorbox:checked").each(function() {
                colorArray.push($(this).val());
            });
        }

        $.ajax({
            url: site_url + "product/filter",
            type: "POST",
            data: "sizeArr=" + sizeArray + "&catArr=" + catArray + "&priceArr=" + priceArray + "&colorArr=" + colorArray,
            success: function(response) {
                if (response) {
                    $('.listdiv').html(response);
                    window.setTimeout(function(){
                        $('.same-height').matchHeight();
                    }, 10);
                    $('#morelist').hide();
                } else {
                    alert("Something Went wrong.\nAnd try again.");
                }
            },
            complete: function() {
                $('.load').hide();
            },
            error: function(response) {
                alert("Something Went wrong.\nAnd try again.");
            }
        })
    });

    //To reset filters on listing page.
    $(".reset1").click(function() {
        location.reload();
    })

    //To distinguish active color filters.
    $(".colorbox").change(function() {
        var numb = $(this).attr("number");
        if ($(this).is(':checked')) {
            $("." + numb).css("font-weight", "bold");
        } else {
            $("." + numb).css("font-weight", "normal");
        }
    })

    //ajax to show login validation.
    $("#login_form").submit(function(e) {
        e.preventDefault();
        var data = new FormData(this);
        $('#login_button').attr('disabled', 'disabled');
        $.ajax({
            type: 'post',
            url: site_url + 'login',
            dataType: 'json',
            data: data,
            processData: false,
            contentType: false,
            success: function(response) {
                $('#login_button').removeAttr('disabled');
                if (response.status == 0) {
                    showLoginValidationError(response.msg)
                } else if (response.status == 1) {
                    showLoingSuccess(response.msg);
                    window.location.href=site_url+"profile";
                } else if (response.status == 2) {
                    $('.login_msg').text(response.msg);
                    location.reload();
                }
            },
            error: function() {
                $('#login_button').removeAttr('disabled');
                alert('Some error occured.Please try again or later.');
            }
        });
    });

    //ajax to show unique username validation in register page.
    $('.reguname').focusout(function() {
        var uname = $(this).val();
        $.ajax({
            url: site_url + "register/uniqueUname",
            type: "POST",
            data: "uname=" + uname,
            success: function(response) {
                if (response == "Unique") {
                    $('#unamep').text('');
                } else if (response == "Empty") {
                    $('#unamep').text('Enter a username');
                } else if (response == "Invalid") {
                    $('#unamep').text('Enter a valid username');
                } else {
                    $('#unamep').text('Username already exists please choose another.');
                }
            },
            error: function(response) {
                alert("Something Went wrong.\nAnd try again.");
            }
        })
    })

    //ajax to show unique email validation in register page.
    $('.regemail').focusout(function() {
        var mail = $(this).val();
        $.ajax({
            url: site_url + "register/uniqueMail",
            type: "POST",
            data: "mail=" + mail,
            success: function(response) {
                if (response == "Unique") {
                    $('#mailp').text('');
                } else if (response == "Empty") {
                    $('#mailp').text('Enter your email');
                } else if (response == "Invalid") {
                    $('#mailp').text('Enter valid email');
                } else {
                    $('#mailp').text('Email already exists please choose another.');
                }
            },
            error: function(response) {
                alert("Something Went wrong.\nAnd try again.");
            }
        })
    })

    //ajax to show unique email validation in profile page.
    $('.prflmail').focusout(function() {
        var email = $(this).val();
        $.ajax({
            url: site_url + "profile/uniqueEmail",
            type: "POST",
            data: "email=" + email,
            success: function(response) {
                if (response == "Unique") {
                    $('#mailp').text('');
                } else if (response == "Empty") {
                    $('#mailp').text('Enter your email');
                } else if (response == "Invalid") {
                    $('#mailp').text('Enter valid email');
                } else {
                    $('#mailp').text('Email already exists please choose another.');
                }
            },
            error: function(response) {
                alert("Something Went wrong.\nAnd try again.");
            }
        })
    })

    //ajax to show search results.
    $('.search').keyup(function() {
        var string = $(this).val();
        $.ajax({
            url: site_url + "home/searchSuggestion",
            type: "POST",
            data: "string=" + string,
            success: function(response) {
                $('.searchdrop').html(response);
            },
            error: function(response) {
                alert("Something Went wrong.\nAnd try again.");
            }
        })
        $('.searchdrop').slideDown();
    });

    //to show searched products on listing page.
    $('.search').keyup(function(e) {
        if (e.which == 13) {
            var string = $(this).val();
            if (string == "") {
                $('.searchdrop').html('<li><a>Enter Something to search</a></li>');
            }else if ($('.searchdrop>li>a').text() == "No Matches") {
                $('.searchdrop').html('<li><a>No Matches</a></li>');
            }else {
                window.location.replace(site_url + "product/searchResults/" + string);
            }
        }
    });

    //ajax to show searched products on listing page.
    $('.icon').click(function() {
        var string = $('.search');
        if (!string.hasClass('expanded')) {
            string.addClass('expanded');
            string.focus();
        }else if(string.hasClass('expanded') && string.val() == ""){
            string.removeClass('expanded');
            $('.searchdrop').slideUp();
        }else{
            var string = $('.search').val();
            if (string == "") {
                $('.searchdrop').html('<li><a>Enter Something to search</a></li>');
            }else if ($('.searchdrop>li>a').text() == "No Matches") {
                $('.searchdrop').html('<li><a>No Matches</a></li>');
            }else {
                window.location.replace(site_url + "product/searchResults/" + string);
            }
        }
    });    

    //for same height of product divs.
    $('.same-height').matchHeight();

    //ajax to sort prodcuts.
    $("#sort").change(function() {
        $('.load').show();
        var value = $(this).val();
        if (value !== "0") {
        	$.ajax({
	            url: site_url + "product/sort",
	            type: "POST",
	            data: 'value=' + value,
	            success: function(response) {
	                if (response) {
	                    $('.listdiv').html(response);
	                    window.setTimeout(function(){
	                        $('.same-height').matchHeight();
	                    }, 10);
	                    $('#morelist').hide();
	                } else {
	                    alert("Something Went wrong.\nAnd try again.");
	                }
	            },
	            complete: function() {
	                $('.load').hide();
	            },
	            error: function(response) {
	                alert("Something Went wrong.\nAnd try again.");
	            }
	        })
        }
    });
})

//function to confirm purchase of products.
function cnfrm(id) 
{
    var x = $("#inputqty" + id).val();
    var y = $("#price" + id).val();
    var ttl = x * y;
    if (confirm("Are you sure you want to purchase this product? \nTotal amount is " + ttl)) {
        cart(id);
    } else {
        alert("Cancelled");
    }
}

//ajax to add products in cart.
function cart(var_id) 
{
    var size = $("#inputSize" + var_id).val();
    var qty = $("#inputqty" + var_id).val();
    var id = $("#itemid" + var_id).val();
    var dataString = "qty=" + qty + "&id=" + id + "&size=" + size;
    $.ajax({
        url: site_url + "product/addCart",
        type: "POST",
        data: dataString,
        success: function(response) {
            if (response == 1) {
                alert("Your product has been added to your cart.");
                $('.cart_table').load(site_url + ' .cart_body');
            } else if (response == 3) {
                alert("Login to add products in cart");
            } else {
                alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
            }
        },
        error: function(response) {
            alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
        }
    })
};

//ajax to delete products from cart.
function popupDelete(id) 
{
    var size = $("#popupsize" + id).val();
    var dataString = "id=" + id + "&size=" + size;
    $.ajax({
        url: site_url + "product/deletePopup",
        type: "POST",
        data: dataString,
        success: function(response) {
            if (response == 1) {
                $('.cart_div').load(site_url + 'cart .cart_table2');
                $('.cart_table').load(site_url + ' .cart_body');
            } else {
                alert("Something Went wrong.\nPlease try again.");
            }
        },
        error: function(response) {
            alert("Something Went wrong.\nPlease try again.");
        }
    })
};

//ajax to update subtotal in cart.
function updateSub(id) 
{
    var size = $("#inputSize" + id).val();
    var qty = $("#inputqty" + id).val();
    var dataString = "qty=" + qty + "&id=" + id + "&size=" + size;
    $.ajax({
        url: site_url + "cart/updateCart",
        type: "POST",
        data: dataString,
        success: function(response) {
            if (response == 1) {
                $('.cart_div').load(site_url + 'cart .cart_table2');
                $('.cart_table').load(site_url + ' .cart_body');
            } else if (response == 3) {
                alert("Login to add products in cart");
            } else {
                alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
            }
        },
        error: function(response) {
            alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
        }
    })
};

//ajax to total in cart.
function updateTotal() 
{
    $.ajax({
        url: site_url + "cart",
        success: function(response) {
            $('.cartpanel').load(site_url + 'cart .innerpanel');
        },
        error: function(response) {
            alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
        }
    })
}

//ajax to delete all products from cart.
function clearCart() 
{
    $.ajax({
        url: site_url + "cart/clear",
        success: function(response) {
            if (response == 1) {
                $('.cart_div').load(site_url + 'cart .cart_table2');
                $('.cart_table').load(site_url + ' .cart_body');
                $('.cartpanel').load(site_url + 'cart .innerpanel');
            } else if (response == 2) {
                alert("There is nothing in cart.");
            } else {
                alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
            }
        },
        error: function(response) {
            alert("Something Went wrong.\nPlease login first if you are not logged in.\nAnd try again.");
        }
    })
}

//function to show login validation errors.
function showLoginValidationError(msg) 
{
    $('.login_alert').removeClass('alert-success').addClass('alert-danger');
    $('.login_alert').css('display', 'block');
    $('.login_msg').text(msg);
    $('#login_form .form-group').addClass('validation-error');
}

//function to show login success.
function showLoingSuccess(msg) 
{
    $('.login_alert').removeClass('alert-danger').addClass('alert-success');
    $('.login_alert').css('display', 'block');
    $('.login_msg').text(msg);
    $('#login_form .form-group').removeClass('validation-error');
}