$(document).ready(function(){

	$("#menu1").click(function(){
		$(".ulddcart").slideToggle();
	})  

	$(window).scroll(function () {
        if ($(this).scrollTop() > 100) {
            $('.topbut').fadeIn();
        } else {
            $('.topbut').fadeOut();
        }
    });

    $('.topbut').click(function () {
        $("html, body").animate({
            scrollTop: 0
        }, 600);
        return false;
    });
});