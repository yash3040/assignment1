    var $uname = $('#inputUserName');
    var $pass = $('#inputPassword');
    var $loguname = $('#inputLogUserName');
    var $logpass = $('#inputLogPassword');
    var $gndr = $('[name=gender]');
    var $mail = $('#inputEmail');
    var $fname = $('#inputFname');
    var $mob = $('#inputMobNo');
    var $phone = $('#inputPhone');
    var $all = $('#all');
    var $opt1 = $('#opt1');
    var $opt2 = $('#opt2');
    var $opt3 = $('#opt3');
    var $optoth = $('#optoth');
    var $checktxt = $('#checktxt');
    var $term = $('#term');
    var $strt = $('#inputStreet');
    var $cty = $('#inputCity');
    var $cntry = $('#inputCountry');
    var $stt = $('#inputState');
    var $sameadd = $('#sameadd');
    var $strt2 = $('#inputStreet2');
    var $cty2 = $('#inputCity2');
    var $cntry2 = $('#inputCountry2');
    var $stt2 = $('#inputState2');
    var $unameregex = /^[a-z0-9_-]{8,}$/i;
    var $passregex = /^(?=.*[a-z])(?=(?:[^A-Z]*[A-Z]){2})(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]/;
    var $mailregex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var $fnameregex = /^[A-Za-z]+$/;
    var $mobregex = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    var $phoneregex = /^\d{10}$/;

function valid() {  
    
    //validation for username
    if($uname.val() == "") {
        $('#unamep').text('Enter a username');
        $uname.focus();
    }
    else if(!$unameregex.test($uname.val())) {
        $('#unamep').text('Enter a valid Username');
        $uname.focus();
    }
    else{
        $('#unamep').text("");                  
    }

    //validation for password
    if($pass.val() == ""){
        $('#passp').text('Enter a password');
        $pass.focus();
    }
    else if(!$passregex.test($pass.val())){
        $('#passp').text('Enter a valid password');
        $pass.focus();
    }
    else{
        $('#passp').text("");
    }

    //validation for gender
    if(!$gndr[0].checked && !$gndr[1].checked){
        $('#gndrp').text('Please select gender.');
    }
    else{
        $('#gndrp').text("");
    }

    //validation for email
    if($mail.val() == ""){
        $('#mailp').text('Enter a email');
        $mail.focus();
    }
    else if(!$mailregex.test($mail.val())){
        $('#mailp').text('Enter a valid email');
        $mail.focus();
    }
    else{
        $('#mailp').text("");
    }

    //validation for first name
    if($fname.val() == ""){
        $('#fnamep').text('Enter First Name');
        $fname.focus();
    }
    else if(!$fnameregex.test($fname.val())){
        $('#fnamep').text('Enter a valid name');
        $fname.focus();
    }
    else{
        $('#fnamep').text("");
    }

    //validation for mobile number in US format
    if($mob.val() == ""){
        $('#mobp').text('Enter a mobile number');
        $mob.focus();
    }
    else if(!$mobregex.test($mob.val())){
        $('#mobp').text('Enter a valid number');
        $mob.focus();
    }
    else{
        $('#mobp').text("");
    }

    //validation for phone number
    if($phone.val() == ""){
        $('#phonep').text("");
    }
    else if(!$phoneregex.test($phone.val())){
        $('#phonep').text('Enter a valid number');
        $phone.focus();
    }
    else{
        $('#phonep').text("");
    }

    //for checkboxes
    if(!$opt1.is(':checked')){
        if (!$opt2.is(':checked')) {
            if (!$opt3.is(':checked')) {
                if (!$optoth.is(':checked')) {
                    $('#checkp').text('Please select any one');
                }               
                else{
                    $('#checkp').text("");
                }
            }
            else{
                $('#checkp').text("");
            }
        }
        else{
            $('#checkp').text("");
        }       
    }
    else{
        $('#checkp').text("");
    }

    //for other textbox
    if ($optoth.is(':checked')) {
        if ($checktxt.val() == "") {
            $('#checkp').text('Enter your interest');
        } else {
            $('#checkp').text("");
        }
    }

}       

function termfunc(){
    //For terms and conditions
    if(!$term.is(':checked')){
        $('#termsp').text('Please Accept terms and conditions.');
    }   
    else{
        $('#termsp').text("");
    }
}

//for address collapse
function prfl(){
   
    if ($strt.val() == "") {
        $('#strtp').text('Please Enter Street');
    }
    else{
        $('#strtp').text("");
    }

    if ($cty.val() == "") {
        $('#ctyp').text('Please Enter City');
    }
    else{
        $('#ctyp').text("");
    }

    if ($strt2.val() == "") {
        $('#strt2p').text('Please Enter Street');
    }
    else{
        $('#strt2p').text("");
    }

    if ($cty2.val() == "") {
        $('#cty2p').text('Please Enter City');
    }
    else{
        $('#cty2p').text("");
    }

    if ($cntry.val() == "") {
        $('#cntryp').text('Please Select Country');
    }
    else{
        $('#cntryp').text("");
    }

    if ($cntry2.val() == "") {
        $('#cntry2p').text('Please Select Country');
    }
    else{
        $('#cntry2p').text("");
    }

    if ($stt.val() == "") {
        $('#sttp').text('Please Select State');
    }
    else{
        $('#sttp').text("");
    }

    if ($stt2.val() == "") {
        $('#stt2p').text('Please Select State');
    }
    else{
        $('#stt2p').text("");
    }
}

//For checkboxes
function allcheck() {
    
    if ($all.is(':checked')){
        $opt1.prop('checked', true);
        $opt2.prop('checked', true);
        $opt3.prop('checked', true);
    } 
    else{
        $opt1.prop('checked', false);
        $opt2.prop('checked', false);
        $opt3.prop('checked', false);
    }
}    

function indicheck() {
        
    if(!$opt1.is(':checked') || !$opt2.is(':checked') || !$opt3.is(':checked')){
        $all.prop('checked', false);
    }
   
    if($opt1.is(':checked') && $opt2.is(':checked') && $opt3.is(':checked')){
        $all.prop('checked', true);
    }

    if($optoth.is(':checked')){
        $checktxt.prop('disabled', false);
    }
    else{
        $checktxt.prop('disabled', true);
        $checktxt.val("");
    }
}


function cpyadd() { 


    if($sameadd.is(':checked')){

        $strt2.val($strt.val());
        $cty2.val($cty.val());
        $cntry2.val($cntry.val());

        var $cpystt = $("#inputState > option").clone(); 
        $stt2.empty();
        $stt2.append($cpystt);
        $stt2.val($stt.val());     
        
        $strt2.prop('disabled', true);
        $cty2.prop('disabled', true);
        $cntry2.prop('disabled', true);
        $stt2.prop('disabled', true);  

        $strt.on('input',function() {
            window.setTimeout(function() {
               $strt2.val($strt.val());
            }, 0);
        });  

        $cty.on('input',function() {
            window.setTimeout(function() {
               $cty2.val($cty.val());
            }, 0);
        });

        $cntry.on('input',function() {
            window.setTimeout(function() {
               $cntry2.val($cntry.val());
            }, 0);
        });

        $stt.on('input',function() {
            window.setTimeout(function() {
                var $cpystt = $("#inputState > option").clone(); 
                $stt2.empty();
                $stt2.append($cpystt);
                $stt2.val($stt.val());     
            }, 0);
        });
    }
    else{
        $strt2.prop('disabled', false);
        $cty2.prop('disabled', false);
        $cntry2.prop('disabled', false);
        $stt2.prop('disabled', false);
        $strt.off();
        $cty.off();
        $cntry.off();
        $stt.off();
    }
}

function clr() {
    if (confirm("Are you sure you want to clear the form")) {
        $('#form1')[0].reset();
    }   
}

function loginvalid() {
    
    
    //validation for username
    if($loguname.val() == "") {
        $('#logunamep').text('Enter a username');
        $loguname.focus();
    }
    else if(!$unameregex.test($loguname.val())) {
        $('#logunamep').text('Enter a valid Username');
        $loguname.focus();
    }
    else{
        $('#logunamep').text("");                   
    }

    //validation for password
    if($logpass.val() == ""){
        $('#logpassp').text('Enter a password');
        $logpass.focus();
    }
    else if(!$passregex.test($logpass.val())){
        $('#logpassp').text('Enter a valid password');
        $logpass.focus();
    }
    else{
        $('#logpassp').text("");
    }
}  
    
 
